﻿/*  20-01732
    Angelica D. Medina

    BSCSSD-2B
    April 17, 2022

This program will perform a switch case statement for the gender.
*/


using System;

namespace SwitchCase_Medina
{
    class switchcase_medina
    {
        static void Main(string[] args)
        {
            string name;
            char gender;
            
            Console.Write("Enter your Name:           ");
            name = Console.ReadLine();

            Console.Write("Enter your Gender (M/F):   ");
            gender = Convert.ToChar(Console.ReadLine());

            Console.WriteLine("");

            switch (gender)
            {
                case 'M': case 'm':
                    Console.WriteLine("Hi " + name + "!!!" + "\nYour Gender is Male!");
                    break;
                case 'F': case 'f':
                    Console.WriteLine("Hi " + name + "!!!" + "\nYour Gender is Female!");
                    break;
                default:
                    Console.WriteLine("Invalid Input!!!" + "\nTry Again ...");
                    break;
            }

            Console.ReadKey();
        }
    }
}
