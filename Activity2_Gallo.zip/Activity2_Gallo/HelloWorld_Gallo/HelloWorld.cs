﻿/*
 20-01076
Noel M. Gallo Jr.
SD2B
April 7, 2022
This program will display the phrase "Hello World"
 */
using System;

namespace HelloWorld
{

    class HelloWorld
    {

        public static void Main(string[] args)
        {
            System.Console.WriteLine("Hello, World!");
            System.Console.ReadKey();
        }

    }
}

