﻿using System;

namespace DeclaringConstants_Casaña
{
    class DeclaringConstants
    {
        static void Main(string[] args)
        {
            //Declare the variables
            const double pi = 3.14159;
            Double radius, AreaCircle;

            //Input radius
            Console.Write("Enter Radius: ");
            radius = Convert.ToInt32(Console.ReadLine());

            //Compute for the are of the circle
            AreaCircle = pi * radius * radius;

            //Display the radius and the area of the circle
            Console.Write("Radius: {0:0.0000}, ", radius);
            Console.Write("Area: {0:0.0000}", AreaCircle);
            Console.ReadLine();
        }
    }
}