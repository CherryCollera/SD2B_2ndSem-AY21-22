﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 16, 2022
 *  Display information using switch
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CompareNames
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string name;
            char gender;


            Console.WriteLine("Enter your name: ");
            name = Console.ReadLine();
            Console.WriteLine("Enter your gender");
            gender = Convert.ToChar(Console.ReadLine());


            switch (gender)
            {
                case 'M':
                case 'm':
                    Console.WriteLine("\n Hi " + name + "!" + " Your  gender is male!");
                break;

                case 'f':
                case 'F':
                    Console.WriteLine("\n Hi " + name + "!" + " Your  gender is female!");
                break;

                default:
                    Console.WriteLine("\n Invalid input ... Try again ...");
                break;
            }
            Console.ReadKey();  
        }
    }
}
