﻿
namespace WindowsFormsApp1_Medina_Silva_Takahashi
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_myProfile = new System.Windows.Forms.Label();
            this.lbl_firstName3 = new System.Windows.Forms.Label();
            this.lbl_lastName3 = new System.Windows.Forms.Label();
            this.txt_firstName3 = new System.Windows.Forms.TextBox();
            this.txt_lastName3 = new System.Windows.Forms.TextBox();
            this.btn_getMessage3 = new System.Windows.Forms.Button();
            this.btn_Hide3 = new System.Windows.Forms.Button();
            this.btn_Back3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_myProfile
            // 
            this.lbl_myProfile.AutoSize = true;
            this.lbl_myProfile.Font = new System.Drawing.Font("Lucida Calligraphy", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_myProfile.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lbl_myProfile.Location = new System.Drawing.Point(218, 27);
            this.lbl_myProfile.Name = "lbl_myProfile";
            this.lbl_myProfile.Size = new System.Drawing.Size(240, 37);
            this.lbl_myProfile.TabIndex = 0;
            this.lbl_myProfile.Text = "MY PROFILE";
            // 
            // lbl_firstName3
            // 
            this.lbl_firstName3.AutoSize = true;
            this.lbl_firstName3.Font = new System.Drawing.Font("Lucida Console", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_firstName3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_firstName3.Location = new System.Drawing.Point(90, 87);
            this.lbl_firstName3.Name = "lbl_firstName3";
            this.lbl_firstName3.Size = new System.Drawing.Size(107, 15);
            this.lbl_firstName3.TabIndex = 1;
            this.lbl_firstName3.Text = "First Name";
            // 
            // lbl_lastName3
            // 
            this.lbl_lastName3.AutoSize = true;
            this.lbl_lastName3.Font = new System.Drawing.Font("Lucida Console", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_lastName3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_lastName3.Location = new System.Drawing.Point(90, 116);
            this.lbl_lastName3.Name = "lbl_lastName3";
            this.lbl_lastName3.Size = new System.Drawing.Size(97, 15);
            this.lbl_lastName3.TabIndex = 1;
            this.lbl_lastName3.Text = "Last Name";
            // 
            // txt_firstName3
            // 
            this.txt_firstName3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_firstName3.Location = new System.Drawing.Point(225, 78);
            this.txt_firstName3.Name = "txt_firstName3";
            this.txt_firstName3.Size = new System.Drawing.Size(262, 24);
            this.txt_firstName3.TabIndex = 2;
            // 
            // txt_lastName3
            // 
            this.txt_lastName3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_lastName3.Location = new System.Drawing.Point(225, 107);
            this.txt_lastName3.Name = "txt_lastName3";
            this.txt_lastName3.Size = new System.Drawing.Size(262, 24);
            this.txt_lastName3.TabIndex = 2;
            // 
            // btn_getMessage3
            // 
            this.btn_getMessage3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_getMessage3.Location = new System.Drawing.Point(125, 179);
            this.btn_getMessage3.Name = "btn_getMessage3";
            this.btn_getMessage3.Size = new System.Drawing.Size(154, 38);
            this.btn_getMessage3.TabIndex = 3;
            this.btn_getMessage3.Text = "Get Message";
            this.btn_getMessage3.UseVisualStyleBackColor = true;
            this.btn_getMessage3.Click += new System.EventHandler(this.btn_getMessage3_Click);
            // 
            // btn_Hide3
            // 
            this.btn_Hide3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Hide3.Location = new System.Drawing.Point(313, 179);
            this.btn_Hide3.Name = "btn_Hide3";
            this.btn_Hide3.Size = new System.Drawing.Size(73, 38);
            this.btn_Hide3.TabIndex = 3;
            this.btn_Hide3.Text = "Hide";
            this.btn_Hide3.UseVisualStyleBackColor = true;
            this.btn_Hide3.Click += new System.EventHandler(this.btn_Hide3_Click);
            // 
            // btn_Back3
            // 
            this.btn_Back3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back3.Location = new System.Drawing.Point(414, 179);
            this.btn_Back3.Name = "btn_Back3";
            this.btn_Back3.Size = new System.Drawing.Size(73, 38);
            this.btn_Back3.TabIndex = 3;
            this.btn_Back3.Text = "Back";
            this.btn_Back3.UseVisualStyleBackColor = true;
            this.btn_Back3.Click += new System.EventHandler(this.btn_Back3_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(661, 288);
            this.Controls.Add(this.btn_Back3);
            this.Controls.Add(this.btn_Hide3);
            this.Controls.Add(this.btn_getMessage3);
            this.Controls.Add(this.txt_lastName3);
            this.Controls.Add(this.txt_firstName3);
            this.Controls.Add(this.lbl_lastName3);
            this.Controls.Add(this.lbl_firstName3);
            this.Controls.Add(this.lbl_myProfile);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_myProfile;
        private System.Windows.Forms.Label lbl_firstName3;
        private System.Windows.Forms.Label lbl_lastName3;
        private System.Windows.Forms.TextBox txt_firstName3;
        private System.Windows.Forms.TextBox txt_lastName3;
        private System.Windows.Forms.Button btn_getMessage3;
        private System.Windows.Forms.Button btn_Hide3;
        private System.Windows.Forms.Button btn_Back3;
    }
}