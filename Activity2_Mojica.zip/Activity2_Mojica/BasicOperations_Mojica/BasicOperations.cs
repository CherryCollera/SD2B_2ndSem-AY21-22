﻿/*
 * student Id number : 20-05258
 * student full name : Zedrick A. Mojica
 * Section : BSCS-SD2B
 * Date : 04/04/2022
 * Purpose : compute the sum, difference, product, quotient, and remainder of two numbers
 */
using System;

namespace Activity2_Mojica
{
    class BasicOperations
    {
        static void Main(string[] args)
        {
            int num1, num2;
            System.Console.Write("Enter first number : ");
            num1 = Convert.ToInt32(Console.ReadLine());
            System.Console.Write("Enter second number : ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("");
            System.Console.WriteLine("Sum : {0} ",num1 + num2);
            System.Console.WriteLine("Difference : {0} ", num1 - num2);
            System.Console.WriteLine("Product : {0} ", num1 * num2);
            System.Console.WriteLine("Quotient : {0} ", num1 / num2);
            System.Console.WriteLine("Remainder : {0} ", num1 % num2);
            System.Console.ReadKey();
        }
    }
}