﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataGridView_Paguio
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'database_LazoDataSet.Table1' table. You can move, or remove it, as needed.
            this.table1TableAdapter.Fill(this.database_PaguioDataSet.Table1);

        }

        private void refreshToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.refresh(this.database_LazoDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lastName_AToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.LastName_A(this.database_PaguioDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void lastName_AToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void bSCS_studentsToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.BSCS_students(this.database_PaguioSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void bSCS_students1ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.BSCS_students1(this.database_PaguioDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void bSCS_students1ToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void bscs_students2ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.bscs_students2(this.database_PaguioDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void bsit_studentsToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.bsit_students(this.database_PaguioDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void address_SamalToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.Address_Samal(this.database_PaguioDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void secondYearToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.secondYear(this.database_PaguioDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void starts_A_CToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.starts_A_C(this.database_PaguioDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void section_2BToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.Section_2B(this.database_LazoDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
