﻿/*
20-02604
Jaycee Audrei Mari M. Quitaleg
SD2B
April 06, 2022
This program will determine if the the number that is highest of the three.
 */

using System;

namespace IfElse2
{
    class IfElse2
    {
        static void Main()
        {
            Console.Write("Enter first num: ");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second num: ");
            int num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter third num: ");
            int num3 = Convert.ToInt32(Console.ReadLine());

            if(num1 > num2 && num1 > num3)
            {
                Console.WriteLine("\n{0} is greater than {1} and {2}.", num1, num2, num3);
            }

            else if(num2 > num1 && num2 > num3)
            {
                Console.WriteLine("\n{1} is greater than {0} and {2}.", num1, num2, num3);
            }

            else
            {
                Console.WriteLine("\n{2} is greater than {0} and {1}.", num1, num2, num3);
            }

            Console.ReadLine();
        }
    }
}
