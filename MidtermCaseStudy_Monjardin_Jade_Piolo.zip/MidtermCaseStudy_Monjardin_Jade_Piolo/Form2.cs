﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidtermCaseStudy_Monjardin_Jade_Piolo
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void intBtn_Click(object sender, EventArgs e)
        {
            int num = 25;
            MessageBox.Show(num.ToString());
        }

        private void FltBtn_Click(object sender, EventArgs e)
        {
            float num = 25.78F;
            MessageBox.Show(num.ToString());
        }

        private void dblBtn_Click(object sender, EventArgs e)
        {
            double num = 25.7889;
            MessageBox.Show(num.ToString());
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num1, num2, sum;
            num1 = Convert.ToInt32(textBox1.Text);
            num2 = Convert.ToInt32(textBox1.Text);
            sum = num1 + num2;
            MessageBox.Show("Sum is " + Convert.ToString(sum));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Calculator().Show();
            this.Hide();
        }
    }
}
