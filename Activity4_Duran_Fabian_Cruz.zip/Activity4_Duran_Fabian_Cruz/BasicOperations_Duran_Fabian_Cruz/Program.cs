﻿using System;

namespace BasicOperations_Duran_Fabian_Cruz
{
    class Program
    {
        static void Main(string[] args)
        {
            Input input = new Input();
            input.InputValues();

            Sum sum = new Sum();
            sum.ComputeSum();
            Console.WriteLine("\nThe Sum is\t\t=\t{0}", DeclareVar.sum);

            Difference difference = new Difference();
            difference.ComputeDifference();
            Console.WriteLine("\nThe Difference is\t=\t{0}", DeclareVar.difference);

            Product product = new Product();
            product.ComputeProduct();
            Console.WriteLine("\nThe Product is\t\t=\t{0}", DeclareVar.product);

            Quotient quotient = new Quotient();
            quotient.ComputeQuotient();
            Console.WriteLine("\nThe Quotient is\t\t=\t{0}", DeclareVar.quotient);

            Remainder remainder = new Remainder();
            remainder.ComputeRemainder();
            Console.WriteLine("\nThe Remainder is\t=\t{0}", DeclareVar.remainder);
            Console.ReadLine();
        }
    }
}
