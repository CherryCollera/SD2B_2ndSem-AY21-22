﻿/** ===========================
 Name: Reywen Lee Bautista
 Course & Section: BSCS-SD2B
 Date: April 1, 2022
=============================*/

using System;

namespace IfElse2_Bautista
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;
            Console.Write("Enter first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter third number: ");
            num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2 && num1 > num3) { Console.Write("\n{0} is greater than {1} and {2}", num1, num2, num3); }
            else if (num2 > num3) { Console.Write("\n{1} is greater than {0} and {2}", num1, num2, num3); }
            else { Console.Write("\n{2} is greater than {0} and {1}", num1, num2, num3); }

            Console.ReadKey();
        }
    }
}
