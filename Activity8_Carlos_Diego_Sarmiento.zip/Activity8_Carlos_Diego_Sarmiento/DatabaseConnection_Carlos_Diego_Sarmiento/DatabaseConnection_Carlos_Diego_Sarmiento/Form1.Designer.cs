﻿
namespace DatabaseConnection_Carlos_Diego_Sarmiento
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbl_Note2 = new System.Windows.Forms.Label();
            this.lbl_Note = new System.Windows.Forms.Label();
            this.txt_BookNo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Btn_Save = new System.Windows.Forms.Button();
            this.btn_Edit = new System.Windows.Forms.Button();
            this.Btn_Delete = new System.Windows.Forms.Button();
            this.Btn_View = new System.Windows.Forms.Button();
            this.Btn_Add = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txt_Desc = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_Title = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.book3DataSet = new DatabaseConnection_Carlos_Diego_Sarmiento.book3DataSet();
            this.bookrecordsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bookrecordsTableAdapter = new DatabaseConnection_Carlos_Diego_Sarmiento.book3DataSetTableAdapters.bookrecordsTableAdapter();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.booktitleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.booknoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lbl_note3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.book3DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookrecordsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_Note2
            // 
            this.lbl_Note2.AutoSize = true;
            this.lbl_Note2.Font = new System.Drawing.Font("Helvetica", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Note2.ForeColor = System.Drawing.Color.Red;
            this.lbl_Note2.Location = new System.Drawing.Point(532, 92);
            this.lbl_Note2.Name = "lbl_Note2";
            this.lbl_Note2.Size = new System.Drawing.Size(202, 15);
            this.lbl_Note2.TabIndex = 27;
            this.lbl_Note2.Text = "TO UPDATE RECORDS FIRST";
            // 
            // lbl_Note
            // 
            this.lbl_Note.AutoSize = true;
            this.lbl_Note.Font = new System.Drawing.Font("Helvetica", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Note.ForeColor = System.Drawing.Color.Red;
            this.lbl_Note.Location = new System.Drawing.Point(532, 63);
            this.lbl_Note.Name = "lbl_Note";
            this.lbl_Note.Size = new System.Drawing.Size(248, 15);
            this.lbl_Note.TabIndex = 26;
            this.lbl_Note.Text = "PLEASE CLICK VIEW ALL RECORDS";
            // 
            // txt_BookNo
            // 
            this.txt_BookNo.Font = new System.Drawing.Font("Helvetica", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_BookNo.Location = new System.Drawing.Point(212, 122);
            this.txt_BookNo.Name = "txt_BookNo";
            this.txt_BookNo.Size = new System.Drawing.Size(297, 26);
            this.txt_BookNo.TabIndex = 25;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Helvetica", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(52, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 19);
            this.label3.TabIndex = 24;
            this.label3.Text = "Book No:";
            // 
            // Btn_Save
            // 
            this.Btn_Save.BackColor = System.Drawing.Color.Cornsilk;
            this.Btn_Save.Font = new System.Drawing.Font("Helvetica", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Save.ForeColor = System.Drawing.Color.DarkBlue;
            this.Btn_Save.Location = new System.Drawing.Point(317, 504);
            this.Btn_Save.Name = "Btn_Save";
            this.Btn_Save.Size = new System.Drawing.Size(158, 89);
            this.Btn_Save.TabIndex = 23;
            this.Btn_Save.Text = "SAVE";
            this.Btn_Save.UseVisualStyleBackColor = false;
            this.Btn_Save.Click += new System.EventHandler(this.Btn_Save_Click);
            // 
            // btn_Edit
            // 
            this.btn_Edit.BackColor = System.Drawing.Color.Cornsilk;
            this.btn_Edit.Font = new System.Drawing.Font("Helvetica", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Edit.ForeColor = System.Drawing.Color.DarkBlue;
            this.btn_Edit.Location = new System.Drawing.Point(101, 504);
            this.btn_Edit.Name = "btn_Edit";
            this.btn_Edit.Size = new System.Drawing.Size(158, 89);
            this.btn_Edit.TabIndex = 22;
            this.btn_Edit.Text = "EDIT A RECORD";
            this.btn_Edit.UseVisualStyleBackColor = false;
            this.btn_Edit.Click += new System.EventHandler(this.btn_Edit_Click);
            // 
            // Btn_Delete
            // 
            this.Btn_Delete.BackColor = System.Drawing.Color.Cornsilk;
            this.Btn_Delete.Font = new System.Drawing.Font("Helvetica", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Delete.ForeColor = System.Drawing.Color.DarkBlue;
            this.Btn_Delete.Location = new System.Drawing.Point(576, 395);
            this.Btn_Delete.Name = "Btn_Delete";
            this.Btn_Delete.Size = new System.Drawing.Size(158, 89);
            this.Btn_Delete.TabIndex = 21;
            this.Btn_Delete.Text = "DELETE A RECORD";
            this.Btn_Delete.UseVisualStyleBackColor = false;
            this.Btn_Delete.Click += new System.EventHandler(this.Btn_Delete_Click);
            // 
            // Btn_View
            // 
            this.Btn_View.BackColor = System.Drawing.Color.Cornsilk;
            this.Btn_View.Font = new System.Drawing.Font("Helvetica", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_View.ForeColor = System.Drawing.Color.DarkBlue;
            this.Btn_View.Location = new System.Drawing.Point(576, 291);
            this.Btn_View.Name = "Btn_View";
            this.Btn_View.Size = new System.Drawing.Size(158, 89);
            this.Btn_View.TabIndex = 20;
            this.Btn_View.Text = "VIEW ALL RECORDS";
            this.Btn_View.UseVisualStyleBackColor = false;
            this.Btn_View.Click += new System.EventHandler(this.Btn_View_Click);
            // 
            // Btn_Add
            // 
            this.Btn_Add.BackColor = System.Drawing.Color.Cornsilk;
            this.Btn_Add.Font = new System.Drawing.Font("Helvetica", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Add.ForeColor = System.Drawing.Color.DarkBlue;
            this.Btn_Add.Location = new System.Drawing.Point(576, 182);
            this.Btn_Add.Name = "Btn_Add";
            this.Btn_Add.Size = new System.Drawing.Size(158, 89);
            this.Btn_Add.TabIndex = 19;
            this.Btn_Add.Text = "ADD NEW RECORD";
            this.Btn_Add.UseVisualStyleBackColor = false;
            this.Btn_Add.Click += new System.EventHandler(this.Btn_Add_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.booktitleDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn,
            this.booknoDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.bookrecordsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(55, 182);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(454, 302);
            this.dataGridView1.TabIndex = 18;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // txt_Desc
            // 
            this.txt_Desc.Font = new System.Drawing.Font("Helvetica", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Desc.Location = new System.Drawing.Point(212, 81);
            this.txt_Desc.Name = "txt_Desc";
            this.txt_Desc.Size = new System.Drawing.Size(297, 26);
            this.txt_Desc.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Helvetica", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(52, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 19);
            this.label2.TabIndex = 16;
            this.label2.Text = "Book Description:";
            // 
            // txt_Title
            // 
            this.txt_Title.Font = new System.Drawing.Font("Helvetica", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Title.Location = new System.Drawing.Point(212, 39);
            this.txt_Title.Name = "txt_Title";
            this.txt_Title.Size = new System.Drawing.Size(297, 26);
            this.txt_Title.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Helvetica", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(52, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 19);
            this.label1.TabIndex = 14;
            this.label1.Text = "Book Title:";
            // 
            // book3DataSet
            // 
            this.book3DataSet.DataSetName = "book3DataSet";
            this.book3DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bookrecordsBindingSource
            // 
            this.bookrecordsBindingSource.DataMember = "bookrecords";
            this.bookrecordsBindingSource.DataSource = this.book3DataSet;
            // 
            // bookrecordsTableAdapter
            // 
            this.bookrecordsTableAdapter.ClearBeforeFill = true;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // booktitleDataGridViewTextBoxColumn
            // 
            this.booktitleDataGridViewTextBoxColumn.DataPropertyName = "booktitle";
            this.booktitleDataGridViewTextBoxColumn.HeaderText = "booktitle";
            this.booktitleDataGridViewTextBoxColumn.Name = "booktitleDataGridViewTextBoxColumn";
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "description";
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            // 
            // booknoDataGridViewTextBoxColumn
            // 
            this.booknoDataGridViewTextBoxColumn.DataPropertyName = "bookno";
            this.booknoDataGridViewTextBoxColumn.HeaderText = "bookno";
            this.booknoDataGridViewTextBoxColumn.Name = "booknoDataGridViewTextBoxColumn";
            // 
            // lbl_note3
            // 
            this.lbl_note3.AutoSize = true;
            this.lbl_note3.Font = new System.Drawing.Font("Helvetica", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_note3.ForeColor = System.Drawing.Color.Red;
            this.lbl_note3.Location = new System.Drawing.Point(532, 121);
            this.lbl_note3.Name = "lbl_note3";
            this.lbl_note3.Size = new System.Drawing.Size(248, 15);
            this.lbl_note3.TabIndex = 28;
            this.lbl_note3.Text = "PLEASE CLICK VIEW ALL RECORDS";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.ClientSize = new System.Drawing.Size(832, 631);
            this.Controls.Add(this.lbl_note3);
            this.Controls.Add(this.lbl_Note2);
            this.Controls.Add(this.lbl_Note);
            this.Controls.Add(this.txt_BookNo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Btn_Save);
            this.Controls.Add(this.btn_Edit);
            this.Controls.Add(this.Btn_Delete);
            this.Controls.Add(this.Btn_View);
            this.Controls.Add(this.Btn_Add);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txt_Desc);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_Title);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.book3DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookrecordsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Note2;
        private System.Windows.Forms.Label lbl_Note;
        private System.Windows.Forms.TextBox txt_BookNo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Btn_Save;
        private System.Windows.Forms.Button btn_Edit;
        private System.Windows.Forms.Button Btn_Delete;
        private System.Windows.Forms.Button Btn_View;
        private System.Windows.Forms.Button Btn_Add;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txt_Desc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_Title;
        private System.Windows.Forms.Label label1;
        private book3DataSet book3DataSet;
        private System.Windows.Forms.BindingSource bookrecordsBindingSource;
        private book3DataSetTableAdapters.bookrecordsTableAdapter bookrecordsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn booktitleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn booknoDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label lbl_note3;
    }
}

