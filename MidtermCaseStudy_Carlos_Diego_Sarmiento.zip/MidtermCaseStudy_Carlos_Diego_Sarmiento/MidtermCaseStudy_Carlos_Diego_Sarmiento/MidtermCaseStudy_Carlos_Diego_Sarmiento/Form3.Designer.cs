﻿
namespace MidtermCaseStudy_Carlos_Diego_Sarmiento
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnInteger = new System.Windows.Forms.Button();
            this.BtnFloat = new System.Windows.Forms.Button();
            this.BtnDouble = new System.Windows.Forms.Button();
            this.Lbl_FirstNumber = new System.Windows.Forms.Label();
            this.Lbl_SecondNumber = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.BtnSum = new System.Windows.Forms.Button();
            this.btnCalculator = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnInteger
            // 
            this.BtnInteger.Location = new System.Drawing.Point(26, 57);
            this.BtnInteger.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnInteger.Name = "BtnInteger";
            this.BtnInteger.Size = new System.Drawing.Size(139, 29);
            this.BtnInteger.TabIndex = 0;
            this.BtnInteger.Text = "Integer";
            this.BtnInteger.UseVisualStyleBackColor = true;
            this.BtnInteger.Click += new System.EventHandler(this.BtnInteger_Click);
            // 
            // BtnFloat
            // 
            this.BtnFloat.Location = new System.Drawing.Point(192, 57);
            this.BtnFloat.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnFloat.Name = "BtnFloat";
            this.BtnFloat.Size = new System.Drawing.Size(139, 29);
            this.BtnFloat.TabIndex = 1;
            this.BtnFloat.Text = "Float";
            this.BtnFloat.UseVisualStyleBackColor = true;
            this.BtnFloat.Click += new System.EventHandler(this.BtnFloat_Click);
            // 
            // BtnDouble
            // 
            this.BtnDouble.Location = new System.Drawing.Point(353, 57);
            this.BtnDouble.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnDouble.Name = "BtnDouble";
            this.BtnDouble.Size = new System.Drawing.Size(139, 29);
            this.BtnDouble.TabIndex = 2;
            this.BtnDouble.Text = "Double";
            this.BtnDouble.UseVisualStyleBackColor = true;
            this.BtnDouble.Click += new System.EventHandler(this.BtnDouble_Click);
            // 
            // Lbl_FirstNumber
            // 
            this.Lbl_FirstNumber.AutoSize = true;
            this.Lbl_FirstNumber.Location = new System.Drawing.Point(32, 132);
            this.Lbl_FirstNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Lbl_FirstNumber.Name = "Lbl_FirstNumber";
            this.Lbl_FirstNumber.Size = new System.Drawing.Size(92, 13);
            this.Lbl_FirstNumber.TabIndex = 3;
            this.Lbl_FirstNumber.Text = "Enter first number:";
            // 
            // Lbl_SecondNumber
            // 
            this.Lbl_SecondNumber.AutoSize = true;
            this.Lbl_SecondNumber.Location = new System.Drawing.Point(263, 132);
            this.Lbl_SecondNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Lbl_SecondNumber.Name = "Lbl_SecondNumber";
            this.Lbl_SecondNumber.Size = new System.Drawing.Size(111, 13);
            this.Lbl_SecondNumber.TabIndex = 4;
            this.Lbl_SecondNumber.Text = "Enter second number:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(130, 129);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(109, 20);
            this.textBox1.TabIndex = 5;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(379, 129);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(109, 20);
            this.textBox2.TabIndex = 6;
            // 
            // BtnSum
            // 
            this.BtnSum.Location = new System.Drawing.Point(192, 188);
            this.BtnSum.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnSum.Name = "BtnSum";
            this.BtnSum.Size = new System.Drawing.Size(139, 29);
            this.BtnSum.TabIndex = 7;
            this.BtnSum.Text = "Compute Sum";
            this.BtnSum.UseVisualStyleBackColor = true;
            this.BtnSum.Click += new System.EventHandler(this.BtnSum_Click);
            // 
            // btnCalculator
            // 
            this.btnCalculator.Location = new System.Drawing.Point(11, 224);
            this.btnCalculator.Margin = new System.Windows.Forms.Padding(2);
            this.btnCalculator.Name = "btnCalculator";
            this.btnCalculator.Size = new System.Drawing.Size(139, 29);
            this.btnCalculator.TabIndex = 8;
            this.btnCalculator.Text = "Back to Calculator";
            this.btnCalculator.UseVisualStyleBackColor = true;
            this.btnCalculator.Click += new System.EventHandler(this.btnCalculator_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.BurlyWood;
            this.ClientSize = new System.Drawing.Size(521, 264);
            this.Controls.Add(this.btnCalculator);
            this.Controls.Add(this.BtnSum);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Lbl_SecondNumber);
            this.Controls.Add(this.Lbl_FirstNumber);
            this.Controls.Add(this.BtnDouble);
            this.Controls.Add(this.BtnFloat);
            this.Controls.Add(this.BtnInteger);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnInteger;
        private System.Windows.Forms.Button BtnFloat;
        private System.Windows.Forms.Button BtnDouble;
        private System.Windows.Forms.Label Lbl_FirstNumber;
        private System.Windows.Forms.Label Lbl_SecondNumber;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button BtnSum;
        private System.Windows.Forms.Button btnCalculator;
    }
}