﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Carlos_Diego_Sarmiento
{
    class MyProfile
    {
        public void DisplayProfile()
        {
            System.Console.WriteLine("\n\n\n\t\t   P R O F I L E");
            System.Console.WriteLine("Name\t\t:  Roiel A. Carlos");
            System.Console.WriteLine("Date of Birth\t:  December 3, 2001");
            System.Console.WriteLine("Course\t\t:  BS in Computer Science Major in Software Development");
            System.Console.WriteLine("Year\t\t:  2nd");
            System.Console.WriteLine("Section\t\t:  B");

            System.Console.WriteLine("\n\n\n\t\t   P R O F I L E");
            System.Console.WriteLine("Name\t\t:  Angelo R. Diego");
            System.Console.WriteLine("Date of Birth\t:  December 31, 2001");
            System.Console.WriteLine("Course\t\t:  BS in Computer Science Major in Software Development");
            System.Console.WriteLine("Year\t\t:  2nd");
            System.Console.WriteLine("Section\t\t:  B");

            System.Console.WriteLine("\n\n\n\t\t   P R O F I L E");
            System.Console.WriteLine("Name\t\t:  Marian Gillian G. Sarmiento");
            System.Console.WriteLine("Date of Birth\t:  December 30, 2001");
            System.Console.WriteLine("Course\t\t:  BS in Computer Science Major in Software Development");
            System.Console.WriteLine("Year\t\t:  2nd");
            System.Console.WriteLine("Section\t\t:  B");
        }
    }
}
