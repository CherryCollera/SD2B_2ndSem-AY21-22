﻿
namespace Activity6_Anilao
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.bSCS_studentsToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSCS_studentsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.bSIT_studentsToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSIT_studentsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.address_samalToolStrip = new System.Windows.Forms.ToolStrip();
            this.address_samalToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.second_year_studentsToolStrip = new System.Windows.Forms.ToolStrip();
            this.second_year_studentsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.refreshToolStrip = new System.Windows.Forms.ToolStrip();
            this.refreshToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lastname_start_with_A_and_CToolStrip = new System.Windows.Forms.ToolStrip();
            this.lastname_start_with_A_and_CToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.section_2BToolStrip = new System.Windows.Forms.ToolStrip();
            this.section_2BToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.firstname_start_with_consonant_letterToolStrip = new System.Windows.Forms.ToolStrip();
            this.firstname_start_with_consonant_letterToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.studIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.table1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.myDatabaseDataSet = new Activity6_Anilao.MyDatabaseDataSet();
            this.table1TableAdapter = new Activity6_Anilao.MyDatabaseDataSetTableAdapters.Table1TableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.bSCS_studentsToolStrip.SuspendLayout();
            this.bSIT_studentsToolStrip.SuspendLayout();
            this.address_samalToolStrip.SuspendLayout();
            this.second_year_studentsToolStrip.SuspendLayout();
            this.refreshToolStrip.SuspendLayout();
            this.lastname_start_with_A_and_CToolStrip.SuspendLayout();
            this.section_2BToolStrip.SuspendLayout();
            this.firstname_start_with_consonant_letterToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.table1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studIDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.yearDataGridViewTextBoxColumn,
            this.programDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.table1BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(29, 28);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(744, 335);
            this.dataGridView1.TabIndex = 0;
            // 
            // bSCS_studentsToolStrip
            // 
            this.bSCS_studentsToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSCS_studentsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSCS_studentsToolStripButton});
            this.bSCS_studentsToolStrip.Location = new System.Drawing.Point(29, 384);
            this.bSCS_studentsToolStrip.Name = "bSCS_studentsToolStrip";
            this.bSCS_studentsToolStrip.Size = new System.Drawing.Size(100, 25);
            this.bSCS_studentsToolStrip.TabIndex = 1;
            this.bSCS_studentsToolStrip.Text = "bSCS_studentsToolStrip";
            // 
            // bSCS_studentsToolStripButton
            // 
            this.bSCS_studentsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSCS_studentsToolStripButton.Name = "bSCS_studentsToolStripButton";
            this.bSCS_studentsToolStripButton.Size = new System.Drawing.Size(88, 22);
            this.bSCS_studentsToolStripButton.Text = "BSCS_students";
            this.bSCS_studentsToolStripButton.Click += new System.EventHandler(this.bSCS_studentsToolStripButton_Click);
            // 
            // bSIT_studentsToolStrip
            // 
            this.bSIT_studentsToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSIT_studentsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSIT_studentsToolStripButton});
            this.bSIT_studentsToolStrip.Location = new System.Drawing.Point(146, 384);
            this.bSIT_studentsToolStrip.Name = "bSIT_studentsToolStrip";
            this.bSIT_studentsToolStrip.Size = new System.Drawing.Size(95, 25);
            this.bSIT_studentsToolStrip.TabIndex = 2;
            this.bSIT_studentsToolStrip.Text = "bSIT_studentsToolStrip";
            // 
            // bSIT_studentsToolStripButton
            // 
            this.bSIT_studentsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSIT_studentsToolStripButton.Name = "bSIT_studentsToolStripButton";
            this.bSIT_studentsToolStripButton.Size = new System.Drawing.Size(83, 22);
            this.bSIT_studentsToolStripButton.Text = "BSIT_students";
            this.bSIT_studentsToolStripButton.Click += new System.EventHandler(this.bSIT_studentsToolStripButton_Click);
            // 
            // address_samalToolStrip
            // 
            this.address_samalToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.address_samalToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.address_samalToolStripButton});
            this.address_samalToolStrip.Location = new System.Drawing.Point(259, 384);
            this.address_samalToolStrip.Name = "address_samalToolStrip";
            this.address_samalToolStrip.Size = new System.Drawing.Size(101, 25);
            this.address_samalToolStrip.TabIndex = 3;
            this.address_samalToolStrip.Text = "address_samalToolStrip";
            // 
            // address_samalToolStripButton
            // 
            this.address_samalToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.address_samalToolStripButton.Name = "address_samalToolStripButton";
            this.address_samalToolStripButton.Size = new System.Drawing.Size(89, 22);
            this.address_samalToolStripButton.Text = "Address_samal";
            this.address_samalToolStripButton.Click += new System.EventHandler(this.address_samalToolStripButton_Click);
            // 
            // second_year_studentsToolStrip
            // 
            this.second_year_studentsToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.second_year_studentsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.second_year_studentsToolStripButton});
            this.second_year_studentsToolStrip.Location = new System.Drawing.Point(391, 384);
            this.second_year_studentsToolStrip.Name = "second_year_studentsToolStrip";
            this.second_year_studentsToolStrip.Size = new System.Drawing.Size(139, 25);
            this.second_year_studentsToolStrip.TabIndex = 4;
            this.second_year_studentsToolStrip.Text = "second_year_studentsToolStrip";
            // 
            // second_year_studentsToolStripButton
            // 
            this.second_year_studentsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.second_year_studentsToolStripButton.Name = "second_year_studentsToolStripButton";
            this.second_year_studentsToolStripButton.Size = new System.Drawing.Size(127, 22);
            this.second_year_studentsToolStripButton.Text = "Second_year_students";
            this.second_year_studentsToolStripButton.Click += new System.EventHandler(this.second_year_studentsToolStripButton_Click);
            // 
            // refreshToolStrip
            // 
            this.refreshToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.refreshToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshToolStripButton});
            this.refreshToolStrip.Location = new System.Drawing.Point(680, 416);
            this.refreshToolStrip.Name = "refreshToolStrip";
            this.refreshToolStrip.Size = new System.Drawing.Size(62, 25);
            this.refreshToolStrip.TabIndex = 5;
            this.refreshToolStrip.Text = "refreshToolStrip";
            // 
            // refreshToolStripButton
            // 
            this.refreshToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.refreshToolStripButton.Name = "refreshToolStripButton";
            this.refreshToolStripButton.Size = new System.Drawing.Size(50, 22);
            this.refreshToolStripButton.Text = "Refresh";
            this.refreshToolStripButton.Click += new System.EventHandler(this.refreshToolStripButton_Click);
            // 
            // lastname_start_with_A_and_CToolStrip
            // 
            this.lastname_start_with_A_and_CToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.lastname_start_with_A_and_CToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lastname_start_with_A_and_CToolStripButton});
            this.lastname_start_with_A_and_CToolStrip.Location = new System.Drawing.Point(561, 384);
            this.lastname_start_with_A_and_CToolStrip.Name = "lastname_start_with_A_and_CToolStrip";
            this.lastname_start_with_A_and_CToolStrip.Size = new System.Drawing.Size(181, 25);
            this.lastname_start_with_A_and_CToolStrip.TabIndex = 6;
            this.lastname_start_with_A_and_CToolStrip.Text = "lastname_start_with_A_and_CToolStrip";
            // 
            // lastname_start_with_A_and_CToolStripButton
            // 
            this.lastname_start_with_A_and_CToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lastname_start_with_A_and_CToolStripButton.Name = "lastname_start_with_A_and_CToolStripButton";
            this.lastname_start_with_A_and_CToolStripButton.Size = new System.Drawing.Size(169, 22);
            this.lastname_start_with_A_and_CToolStripButton.Text = "Lastname_start_with_A_and_C";
            this.lastname_start_with_A_and_CToolStripButton.Click += new System.EventHandler(this.lastname_start_with_A_and_CToolStripButton_Click);
            // 
            // section_2BToolStrip
            // 
            this.section_2BToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.section_2BToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.section_2BToolStripButton});
            this.section_2BToolStrip.Location = new System.Drawing.Point(181, 416);
            this.section_2BToolStrip.Name = "section_2BToolStrip";
            this.section_2BToolStrip.Size = new System.Drawing.Size(111, 25);
            this.section_2BToolStrip.TabIndex = 7;
            this.section_2BToolStrip.Text = "section_2BToolStrip";
            // 
            // section_2BToolStripButton
            // 
            this.section_2BToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.section_2BToolStripButton.Name = "section_2BToolStripButton";
            this.section_2BToolStripButton.Size = new System.Drawing.Size(68, 22);
            this.section_2BToolStripButton.Text = "Section_2B";
            this.section_2BToolStripButton.Click += new System.EventHandler(this.section_2BToolStripButton_Click);
            // 
            // firstname_start_with_consonant_letterToolStrip
            // 
            this.firstname_start_with_consonant_letterToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.firstname_start_with_consonant_letterToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.firstname_start_with_consonant_letterToolStripButton});
            this.firstname_start_with_consonant_letterToolStrip.Location = new System.Drawing.Point(355, 416);
            this.firstname_start_with_consonant_letterToolStrip.Name = "firstname_start_with_consonant_letterToolStrip";
            this.firstname_start_with_consonant_letterToolStrip.Size = new System.Drawing.Size(224, 25);
            this.firstname_start_with_consonant_letterToolStrip.TabIndex = 8;
            this.firstname_start_with_consonant_letterToolStrip.Text = "firstname_start_with_consonant_letterToolStrip";
            // 
            // firstname_start_with_consonant_letterToolStripButton
            // 
            this.firstname_start_with_consonant_letterToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.firstname_start_with_consonant_letterToolStripButton.Name = "firstname_start_with_consonant_letterToolStripButton";
            this.firstname_start_with_consonant_letterToolStripButton.Size = new System.Drawing.Size(212, 22);
            this.firstname_start_with_consonant_letterToolStripButton.Text = "Firstname_start_with_consonant_letter";
            this.firstname_start_with_consonant_letterToolStripButton.Click += new System.EventHandler(this.firstname_start_with_consonant_letterToolStripButton_Click);
            // 
            // studIDDataGridViewTextBoxColumn
            // 
            this.studIDDataGridViewTextBoxColumn.DataPropertyName = "StudID";
            this.studIDDataGridViewTextBoxColumn.HeaderText = "StudID";
            this.studIDDataGridViewTextBoxColumn.Name = "studIDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // yearDataGridViewTextBoxColumn
            // 
            this.yearDataGridViewTextBoxColumn.DataPropertyName = "Year";
            this.yearDataGridViewTextBoxColumn.HeaderText = "Year";
            this.yearDataGridViewTextBoxColumn.Name = "yearDataGridViewTextBoxColumn";
            // 
            // programDataGridViewTextBoxColumn
            // 
            this.programDataGridViewTextBoxColumn.DataPropertyName = "Program";
            this.programDataGridViewTextBoxColumn.HeaderText = "Program";
            this.programDataGridViewTextBoxColumn.Name = "programDataGridViewTextBoxColumn";
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            // 
            // table1BindingSource
            // 
            this.table1BindingSource.DataMember = "Table1";
            this.table1BindingSource.DataSource = this.myDatabaseDataSet;
            // 
            // myDatabaseDataSet
            // 
            this.myDatabaseDataSet.DataSetName = "MyDatabaseDataSet";
            this.myDatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // table1TableAdapter
            // 
            this.table1TableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 461);
            this.Controls.Add(this.firstname_start_with_consonant_letterToolStrip);
            this.Controls.Add(this.section_2BToolStrip);
            this.Controls.Add(this.lastname_start_with_A_and_CToolStrip);
            this.Controls.Add(this.refreshToolStrip);
            this.Controls.Add(this.second_year_studentsToolStrip);
            this.Controls.Add(this.address_samalToolStrip);
            this.Controls.Add(this.bSIT_studentsToolStrip);
            this.Controls.Add(this.bSCS_studentsToolStrip);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.bSCS_studentsToolStrip.ResumeLayout(false);
            this.bSCS_studentsToolStrip.PerformLayout();
            this.bSIT_studentsToolStrip.ResumeLayout(false);
            this.bSIT_studentsToolStrip.PerformLayout();
            this.address_samalToolStrip.ResumeLayout(false);
            this.address_samalToolStrip.PerformLayout();
            this.second_year_studentsToolStrip.ResumeLayout(false);
            this.second_year_studentsToolStrip.PerformLayout();
            this.refreshToolStrip.ResumeLayout(false);
            this.refreshToolStrip.PerformLayout();
            this.lastname_start_with_A_and_CToolStrip.ResumeLayout(false);
            this.lastname_start_with_A_and_CToolStrip.PerformLayout();
            this.section_2BToolStrip.ResumeLayout(false);
            this.section_2BToolStrip.PerformLayout();
            this.firstname_start_with_consonant_letterToolStrip.ResumeLayout(false);
            this.firstname_start_with_consonant_letterToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.table1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private MyDatabaseDataSet myDatabaseDataSet;
        private System.Windows.Forms.BindingSource table1BindingSource;
        private MyDatabaseDataSetTableAdapters.Table1TableAdapter table1TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn programDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStrip bSCS_studentsToolStrip;
        private System.Windows.Forms.ToolStripButton bSCS_studentsToolStripButton;
        private System.Windows.Forms.ToolStrip bSIT_studentsToolStrip;
        private System.Windows.Forms.ToolStripButton bSIT_studentsToolStripButton;
        private System.Windows.Forms.ToolStrip address_samalToolStrip;
        private System.Windows.Forms.ToolStripButton address_samalToolStripButton;
        private System.Windows.Forms.ToolStrip second_year_studentsToolStrip;
        private System.Windows.Forms.ToolStripButton second_year_studentsToolStripButton;
        private System.Windows.Forms.ToolStrip refreshToolStrip;
        private System.Windows.Forms.ToolStripButton refreshToolStripButton;
        private System.Windows.Forms.ToolStrip lastname_start_with_A_and_CToolStrip;
        private System.Windows.Forms.ToolStripButton lastname_start_with_A_and_CToolStripButton;
        private System.Windows.Forms.ToolStrip section_2BToolStrip;
        private System.Windows.Forms.ToolStripButton section_2BToolStripButton;
        private System.Windows.Forms.ToolStrip firstname_start_with_consonant_letterToolStrip;
        private System.Windows.Forms.ToolStripButton firstname_start_with_consonant_letterToolStripButton;
    }
}

