﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 16, 2022
 *  Sum all numbers inside the array using do-while and display the sum
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CompareNames
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] dw_nums = new int[] { 5, 6, 7, 8 };
            int sum = 0;
            int i = 0;


            do
            {
                sum += dw_nums[i];
                i++;
            } while (i < 4);


            Console.WriteLine(sum);
            Console.ReadKey();
        }
    }
}
