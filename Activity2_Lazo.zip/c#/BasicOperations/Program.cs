﻿using System;

namespace BasicOperations
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.WriteLine("Enter first number:  ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter second number:  ");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Sum: " + (num1 + num2));
            Console.WriteLine("Difference:  " + (num1 - num2));
            Console.WriteLine("Product:  " + (num1 * num2));
            Console.WriteLine("Quotient  " + (num1 / num2));
            Console.WriteLine("Remainder:  " + (num1 % num2));
        }
    }
}
