﻿using System;

namespace DeclaringConstants
{
    class DeclaringCosntants
    {
        static void Main(string[] args)
        {

            double radius;
            const double pi = 3.14159;

            Console.Write("Enter Radius: ");
            radius = Convert.ToDouble(Console.ReadLine());
            double AreaCircle = pi * radius * radius;
            Console.WriteLine("Radius: " + Math.Round(radius, 2) +
                ", Area: " + AreaCircle);
            Console.ReadLine();
        }
    }
}
