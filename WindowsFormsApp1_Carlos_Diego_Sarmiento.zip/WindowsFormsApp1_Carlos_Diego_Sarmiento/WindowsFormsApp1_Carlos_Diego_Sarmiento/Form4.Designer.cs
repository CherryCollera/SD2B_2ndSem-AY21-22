﻿
namespace WindowsFormsApp1_Carlos_Diego_Sarmiento
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Firstnumber = new System.Windows.Forms.Label();
            this.lbl_Secondnumber = new System.Windows.Forms.Label();
            this.txt_Firstnumber = new System.Windows.Forms.TextBox();
            this.txtSecondnumber = new System.Windows.Forms.TextBox();
            this.btn_Addition = new System.Windows.Forms.Button();
            this.btn_Subtraction = new System.Windows.Forms.Button();
            this.btn_Multiplication = new System.Windows.Forms.Button();
            this.btn_Division = new System.Windows.Forms.Button();
            this.lbl_Answer = new System.Windows.Forms.Label();
            this.txt_Answer = new System.Windows.Forms.TextBox();
            this.btn_Back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Firstnumber
            // 
            this.lbl_Firstnumber.AutoSize = true;
            this.lbl_Firstnumber.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.lbl_Firstnumber.Location = new System.Drawing.Point(53, 31);
            this.lbl_Firstnumber.Name = "lbl_Firstnumber";
            this.lbl_Firstnumber.Size = new System.Drawing.Size(197, 32);
            this.lbl_Firstnumber.TabIndex = 0;
            this.lbl_Firstnumber.Text = "First Number:";
            // 
            // lbl_Secondnumber
            // 
            this.lbl_Secondnumber.AutoSize = true;
            this.lbl_Secondnumber.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.lbl_Secondnumber.Location = new System.Drawing.Point(15, 76);
            this.lbl_Secondnumber.Name = "lbl_Secondnumber";
            this.lbl_Secondnumber.Size = new System.Drawing.Size(235, 32);
            this.lbl_Secondnumber.TabIndex = 1;
            this.lbl_Secondnumber.Text = "Second Number:";
            // 
            // txt_Firstnumber
            // 
            this.txt_Firstnumber.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.txt_Firstnumber.Location = new System.Drawing.Point(279, 31);
            this.txt_Firstnumber.Name = "txt_Firstnumber";
            this.txt_Firstnumber.Size = new System.Drawing.Size(179, 39);
            this.txt_Firstnumber.TabIndex = 2;
            // 
            // txtSecondnumber
            // 
            this.txtSecondnumber.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.txtSecondnumber.Location = new System.Drawing.Point(279, 76);
            this.txtSecondnumber.Name = "txtSecondnumber";
            this.txtSecondnumber.Size = new System.Drawing.Size(179, 39);
            this.txtSecondnumber.TabIndex = 3;
            // 
            // btn_Addition
            // 
            this.btn_Addition.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.btn_Addition.Location = new System.Drawing.Point(59, 126);
            this.btn_Addition.Name = "btn_Addition";
            this.btn_Addition.Size = new System.Drawing.Size(155, 56);
            this.btn_Addition.TabIndex = 4;
            this.btn_Addition.Text = "+";
            this.btn_Addition.UseVisualStyleBackColor = true;
            this.btn_Addition.Click += new System.EventHandler(this.btn_Addition_Click);
            // 
            // btn_Subtraction
            // 
            this.btn_Subtraction.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.btn_Subtraction.Location = new System.Drawing.Point(296, 126);
            this.btn_Subtraction.Name = "btn_Subtraction";
            this.btn_Subtraction.Size = new System.Drawing.Size(162, 56);
            this.btn_Subtraction.TabIndex = 5;
            this.btn_Subtraction.Text = "-";
            this.btn_Subtraction.UseVisualStyleBackColor = true;
            this.btn_Subtraction.Click += new System.EventHandler(this.btn_Subtraction_Click);
            // 
            // btn_Multiplication
            // 
            this.btn_Multiplication.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.btn_Multiplication.Location = new System.Drawing.Point(59, 197);
            this.btn_Multiplication.Name = "btn_Multiplication";
            this.btn_Multiplication.Size = new System.Drawing.Size(155, 60);
            this.btn_Multiplication.TabIndex = 6;
            this.btn_Multiplication.Text = "*";
            this.btn_Multiplication.UseVisualStyleBackColor = true;
            this.btn_Multiplication.Click += new System.EventHandler(this.btn_Multiplication_Click);
            // 
            // btn_Division
            // 
            this.btn_Division.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.btn_Division.Location = new System.Drawing.Point(296, 197);
            this.btn_Division.Name = "btn_Division";
            this.btn_Division.Size = new System.Drawing.Size(162, 57);
            this.btn_Division.TabIndex = 7;
            this.btn_Division.Text = "/";
            this.btn_Division.UseVisualStyleBackColor = true;
            this.btn_Division.Click += new System.EventHandler(this.btn_Division_Click);
            // 
            // lbl_Answer
            // 
            this.lbl_Answer.AutoSize = true;
            this.lbl_Answer.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.lbl_Answer.Location = new System.Drawing.Point(53, 274);
            this.lbl_Answer.Name = "lbl_Answer";
            this.lbl_Answer.Size = new System.Drawing.Size(120, 32);
            this.lbl_Answer.TabIndex = 8;
            this.lbl_Answer.Text = "Answer:";
            // 
            // txt_Answer
            // 
            this.txt_Answer.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.txt_Answer.Location = new System.Drawing.Point(179, 274);
            this.txt_Answer.Name = "txt_Answer";
            this.txt_Answer.ReadOnly = true;
            this.txt_Answer.Size = new System.Drawing.Size(100, 39);
            this.txt_Answer.TabIndex = 9;
            // 
            // btn_Back
            // 
            this.btn_Back.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.btn_Back.Location = new System.Drawing.Point(370, 274);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(88, 39);
            this.btn_Back.TabIndex = 10;
            this.btn_Back.Text = "Back";
            this.btn_Back.UseVisualStyleBackColor = true;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(514, 384);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.txt_Answer);
            this.Controls.Add(this.lbl_Answer);
            this.Controls.Add(this.btn_Division);
            this.Controls.Add(this.btn_Multiplication);
            this.Controls.Add(this.btn_Subtraction);
            this.Controls.Add(this.btn_Addition);
            this.Controls.Add(this.txtSecondnumber);
            this.Controls.Add(this.txt_Firstnumber);
            this.Controls.Add(this.lbl_Secondnumber);
            this.Controls.Add(this.lbl_Firstnumber);
            this.Name = "Form4";
            this.Text = "Form4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Firstnumber;
        private System.Windows.Forms.Label lbl_Secondnumber;
        private System.Windows.Forms.TextBox txt_Firstnumber;
        private System.Windows.Forms.TextBox txtSecondnumber;
        private System.Windows.Forms.Button btn_Addition;
        private System.Windows.Forms.Button btn_Subtraction;
        private System.Windows.Forms.Button btn_Multiplication;
        private System.Windows.Forms.Button btn_Division;
        private System.Windows.Forms.Label lbl_Answer;
        private System.Windows.Forms.TextBox txt_Answer;
        private System.Windows.Forms.Button btn_Back;
    }
}