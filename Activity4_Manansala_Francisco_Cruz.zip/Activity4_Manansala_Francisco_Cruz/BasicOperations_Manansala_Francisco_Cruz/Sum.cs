﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Manansala_Francisco_Cruz
{
    class Sum
    {
        public void ComputeSum()
        {
            DeclareVar.sum = DeclareVar.num1 + DeclareVar.num2;
        }
    }
}
