﻿using System;

namespace CompareNames_Duran
{
    class CompareNames
    {
        static void Main(string[] args)
        {
            String str1 = "Gelo";
            String str2 = "Gels";
            String str3 = "Angelo";
            String str4 = "angelo";
            String str5 = "ANGELO";

            Console.WriteLine("Using the Equals() method:");

            Console.WriteLine("\n Compare {0} to {1} = {2}", str1, str2, String.Equals(str1, str2));
            Console.WriteLine(" Compare {0} to {1} = {2}", str2, str3, String.Equals(str2, str3));
            Console.WriteLine(" Length of {0} is {1}", str4, str4.Length);
            Console.WriteLine(" String {0} Substring (0, 3) will return {1}", str5, str5.Substring(0, 3));

            Console.WriteLine("\nUsing the Compare() method:");

            Console.WriteLine("\n Compare {0} to {1} = {2}", str1, str2, string.Compare(str1, str2));
            Console.WriteLine(" Compare {0} to {1 }= {2}", str1, str3, string.Compare(str1, str3));
            Console.WriteLine(" Compare {0} to {1} = {2}", str3, str1, string.Compare(str3, str1));
            Console.WriteLine(" Compare {0} to {1} = {2}", str4, str5, string.Compare(str4, str5));

            Console.WriteLine("\nUsing the Compareto() method:");

            Console.WriteLine("\n Compare {0} to {1} = {2}", str1, str2, str1.CompareTo(str2));
            Console.WriteLine(" Compare {0} to {1} = {2}", str1, str3, str1.CompareTo(str3));
            Console.WriteLine(" Compare {0} to {1} = {2}", str3, str1, str3.CompareTo(str1));
            Console.ReadKey();
        }
    }
}
