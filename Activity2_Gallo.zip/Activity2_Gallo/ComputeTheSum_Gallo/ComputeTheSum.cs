﻿/*
 20-01076
Noel M. Gallo Jr.
SD2B
April 7, 2022
This program will Compute the sum
 */
using System;

namespace ComputeTheSum
{

    class ComputeTheSum
    {

        public static void Main(string[] args)
        {
            System.Console.Write("Enter 1st number: ");
            int num1 = Convert.ToInt16(Console.ReadLine());
            System.Console.Write("Enter 2nd number: ");
            int num2 = Convert.ToInt16(Console.ReadLine());

            System.Console.WriteLine("\nSum = " + (num1 + num2));
            System.Console.ReadKey();
        }

    }
}
