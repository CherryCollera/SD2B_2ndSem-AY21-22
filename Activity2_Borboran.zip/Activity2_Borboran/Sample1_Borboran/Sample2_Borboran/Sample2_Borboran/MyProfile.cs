﻿/*20-02190
Borboran, Keanu Dave E.
SD2B
March 29, 2022
This program will display my student information */

using System;

namespace Sample2_Borboran
{

    class MyProfile
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name: Borboran, Keanu Dave E.");
            Console.WriteLine("Date of Birth: October 20");
            Console.WriteLine("Course: BS Computer Science major in Software Development");
            Console.WriteLine("Year: II");
            Console.WriteLine("Section: SD2B");
            Console.ReadKey();
        }
    }
}
