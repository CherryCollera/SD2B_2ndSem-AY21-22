﻿/* 		Activity #5
 * 		Grp 9
 * 	Members: Medina, Angelica
	   	 Silva, Alyssa Mae
	   	 Takahashi, Aira
 * BSCS-SD2B
 * 05/04/2022*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1_Medina_Silva_Takahashi
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
