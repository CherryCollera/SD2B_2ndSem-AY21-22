﻿/*20-00613
Marian Gillian G. Sarmiento
SD2B
March 26, 2022
This program will display the phrase "Hello World"*/

using System;

namespace Sample1_HelloWorld
{
    class mariansarmiento
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.ReadKey();
        }
    }
}
