﻿/*
20-02604
Jaycee Audrei Mari M. Quitaleg
SD2B
April 06, 2022
This program will request an input then displays the said input."
 */

using System;

namespace InputMyName
{
    class InputName
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your name (Firstname Lastname): ");
            string Name = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("Hello " + Name + "!!!");
            Console.WriteLine("Welcome to OOP Environment.");
            Console.ReadKey();
        }
    }
}
