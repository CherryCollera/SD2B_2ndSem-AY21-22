﻿/*
20-02604
Jaycee Audrei Mari M. Quitaleg
SD2B
April 08, 2022
This program will use identify what is the equivalent grade of the user and its corresponding remark.
 */

using System;

namespace GradingSystem_Quitaleg
{
    class GradingSystem_Quitaleg
    {
        static void Main(String[] args)
        {
            string inc = "Inc";

            Console.Write("Enter your final grade:\t ");
            string input = Console.ReadLine();

            bool isNumerical = int.TryParse(input, out int grade);

            if (string.Equals(inc, input,StringComparison.CurrentCultureIgnoreCase))
            {
                Console.WriteLine("Grade Equivalent:\t Incomplete");
                Console.WriteLine("Remarks:\t\t Incomplete");
            }

            else if (isNumerical)
            {
                
                if (grade >= 98 && grade <= 100)
                {
                    Console.WriteLine("Grade Equivalent:\t 1.00");
                    Console.WriteLine("Remarks:\t\t Excellent");
                }

                else if (grade >= 95 && grade <= 97)
                {
                    Console.WriteLine("Grade Equivalent:\t 1.25");
                    Console.WriteLine("Remarks:\t\t Very Good");
                }

                else if (grade >= 92 && grade <= 94)
                {
                    Console.WriteLine("Grade Equivalent:\t 1.50");
                    Console.WriteLine("Remarks:\t\t Very Good");
                }

                else if (grade >= 89 && grade <= 91)
                {
                    Console.WriteLine("Grade Equivalent:\t 1.75");
                    Console.WriteLine("Remarks:\t\t Very Good");
                }

                else if (grade >= 86 && grade <= 88)
                {
                    Console.WriteLine("Grade Equivalent:\t 2.00");
                    Console.WriteLine("Remarks:\t\t Good");
                }


                else if (grade >= 83 && grade <= 85)
                {
                    Console.WriteLine("Grade Equivalent:\t 2.25");
                    Console.WriteLine("Remarks:\t\t Good");
                }


                else if (grade >= 80 && grade <= 82)
                {
                    Console.WriteLine("Grade Equivalent:\t 2.50");
                    Console.WriteLine("Remarks:\t\t Fair");
                }

                else if (grade >= 77 && grade <= 79)
                {
                    Console.WriteLine("Grade Equivalent:\t 2.75");
                    Console.WriteLine("Remarks:\t\t Passed");
                }

                else if (grade >= 75 && grade <= 76)
                {
                    Console.WriteLine("Grade Equivalent:\t 3.00");
                    Console.WriteLine("Remarks:\t\t Passed");
                }

                else if (grade >= 72 && grade <= 74)
                {
                    Console.WriteLine("Grade Equivalent:\t 4.00");
                    Console.WriteLine("Remarks:\t\t Conditional");
                }

                else if (grade >= 60 && grade <= 71)
                {
                    Console.WriteLine("Grade Equivalent:\t 5.00");
                    Console.WriteLine("Remarks:\t\t Failed");
                }

                else
                {
                    Console.WriteLine("Error!");
                }
            }
            
            else
            {
                Console.WriteLine("Error!");
            }


            Console.ReadKey();
        }
    }
}
