﻿/*
20-02530
Carl Joseph Mendoza
SD2B
October 23, 2002
The program will input my name and then it will be displayed
 */


using System;

namespace InputMyName_Mendoza
{
    class InputName
    {
        static void Main(string[] args)
        {

            string lname, fname;

            Console.Write("Enter your name" +
                "(Firstname Lastname):\n ");
            fname = Console.ReadLine();
            lname = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("\nHello " + fname + " "+ lname +"!!!" +
                "\nWelcome to OOP Environment.");
            Console.ReadKey();
        }
    }
}