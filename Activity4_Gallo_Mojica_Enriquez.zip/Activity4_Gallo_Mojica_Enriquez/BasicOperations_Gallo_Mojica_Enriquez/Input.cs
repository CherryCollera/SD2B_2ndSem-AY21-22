﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Gallo_Mojica_Enriquez
{
    internal class Input
    {
        public void InputNumber(string text1, string text2)
        {
            Console.Write(text1);
            DeclareVar.num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write(text2);
            DeclareVar.num2 = Convert.ToInt32(Console.ReadLine());
        }
    }
}