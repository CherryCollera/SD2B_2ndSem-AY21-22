﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Act6_Takahashi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'database4DataSet.Table1' table. You can move, or remove it, as needed.
            this.table1TableAdapter.Fill(this.database4DataSet.Table1);

        }

        private void refreshToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.Refresh(this.database4DataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void lastName_starts_with_AToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.LastName_starts_with_A(this.database4DataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void lastName_Starts_With_A1ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.LastName_Starts_With_A1(this.database4DataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void bSCSToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.BSCS(this.database4DataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void bSITToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.BSIT(this.database4DataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void address_SamalToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.Address_Samal(this.database4DataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void second_year_studentsToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.Second_year_students(this.database4DataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
