﻿using System;

namespace ComputeAverage_Mendoza
{
    class Average
    {
        static void Main(string[] args)
        {

            double num1, num2, num3, num4, num5, TotalNum, ave;

            Console.WriteLine("Enter 5 grades:  ");
            num1 = Convert.ToDouble(Console.ReadLine());           
            num2 = Convert.ToDouble(Console.ReadLine());
            num3 = Convert.ToDouble(Console.ReadLine());
            num4 = Convert.ToDouble(Console.ReadLine());
            num5 = Convert.ToDouble(Console.ReadLine());

            TotalNum = num1 + num2 + num3 + num4 + num5;
            ave = TotalNum / 5;
            
            Console.WriteLine("The average is " + ave.ToString("F3", System.Globalization.CultureInfo.InvariantCulture) +".");
            
            Console.ReadLine();
        }
    }
}