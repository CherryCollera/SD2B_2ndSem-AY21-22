﻿using System;

namespace IfElse2_Francisco
{
    class IfElse2
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;
            Console.Write("\nEnter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Third Number: ");
            num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2 && num1 > num3)
            {
                Console.WriteLine(num1 + " is greater than "
                    + num2 + " and " + num3);
                Console.ReadLine();
            }
            else if (num2 > num1 && num2 > num3)
            {
                Console.WriteLine(num2 + " is greater than "
                    + num1 + " and " + num3);
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine(num3 + " is greater than "
                    + num1 + " and " + num2);
                Console.ReadLine();
            }
        }

    }
}