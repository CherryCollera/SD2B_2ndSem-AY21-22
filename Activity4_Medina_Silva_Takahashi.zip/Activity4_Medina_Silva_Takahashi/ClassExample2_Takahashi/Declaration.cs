﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample2_Takahashi
{
    class Declaration
    {
        private static string color;
        public static string Color
        {
            get { return color; }
            set { color = value; }
        }
    }
}
