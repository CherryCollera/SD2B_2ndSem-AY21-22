﻿/*20-00613
Marian Gillian G. Sarmiento
SD2B
March 26, 2022
This program will display my profile*/

using System;

namespace Sample2_MyProfile
{
    class mariansarmiento
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name: Marian Gillian G. Sarmiento" + "\n");
            Console.WriteLine("Date of Birth: December 30" + "\n");
            Console.WriteLine("Course: BS Computer Science" + "\n");
            Console.WriteLine("Year: II" + "\n");
            Console.WriteLine("Section: 2B" + "\n");
            Console.ReadKey();
        }
    }
}
