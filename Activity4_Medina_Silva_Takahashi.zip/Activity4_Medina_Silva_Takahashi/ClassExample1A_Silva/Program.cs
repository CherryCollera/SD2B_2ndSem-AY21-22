﻿/* 	ACTIVITY4_Grp9			
	BSCS SD2B

GrpMembers:	Medina, Angelica D
		    Silva, Alyssa MaeT. 
		    Takahashi, Aira M.

Date:   04-27-2022
 */

using System;

namespace ClassExample1A_Silva
{
    class Program
    {
        static void Main(string[] args)
        {
            //Creating object for 1st class: "Accept1a"
            Accept1a a = new Accept1a();
            //Executing the method from 1st class: "AcceptDetails()"
            a.AcceptDetails();

            //Creating object for 2nd class: "Print1a"
            Print1a p = new Print1a();
            //Executing the method from 2nd class: "PrintDetails()"
            p.PrintDetails( a.firstname,  a.lastname);

            //Creating objects for 3rd class: "MyProfile1a"
            MyProfile1a profile = new MyProfile1a();
            //Executing the method from 3rd class: "DisplayProfile()"
            profile.DisplayProfile();


            Console.ReadLine();
        }
    }
}
