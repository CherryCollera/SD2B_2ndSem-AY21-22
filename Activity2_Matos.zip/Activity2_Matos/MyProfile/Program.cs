﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 15, 2022
 *  Display student information
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Sample2_MyProfile
    {
        internal class Program
            {
                static void Main(string[] args)
                    {
                        // Display name
                        Console.WriteLine("Name:                 Dianna Grace Matos");

                        // Display date of birth
                        Console.WriteLine("Date of Birth:        July 1");

                        // Display course
                        Console.WriteLine("Course:               BSCS Software Development");

                        // Display year
                        Console.WriteLine("Year:                 2");

                        // Display section
                        Console.WriteLine("Section:              SD2B");
                        Console.ReadKey();
                    }
            }
    }
