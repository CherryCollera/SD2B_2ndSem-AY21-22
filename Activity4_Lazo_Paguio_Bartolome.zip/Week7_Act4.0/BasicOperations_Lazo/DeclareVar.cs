class DeclareVar{
    public static int sum,num1, num2,difference,product,quotient,remainder;

}