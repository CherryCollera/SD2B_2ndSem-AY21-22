﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Manansala_Francisco_Cruz
{
    class Product
    {
        public void ComputeProduct()
        {
            DeclareVar.product = DeclareVar.num1 * DeclareVar.num2;
        }
    }
}
