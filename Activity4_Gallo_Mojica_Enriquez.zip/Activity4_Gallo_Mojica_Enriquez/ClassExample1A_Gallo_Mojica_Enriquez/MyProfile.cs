﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Gallo_Mojica_Enriquez
{
    internal class MyProfile
    {
        public void DisplayProfile()
        {
            Console.WriteLine("\n\n\n\t\t\tP R O F I L E");
            Console.WriteLine("Name:\t\t\tBrix");
            Console.WriteLine("Birthday:\t\tSeptember 18, 2001");
            Console.WriteLine("Course:\t\t\tBS in Computer Science Major in Software Development");
            Console.WriteLine("Year:\t\t\t2nd Year");
            Console.Write("Section:\t\tB");
            Console.ReadKey();
        }
    }
}
