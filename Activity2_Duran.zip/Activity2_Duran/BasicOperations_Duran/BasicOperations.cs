﻿/*20-03334
Angelo Duran
SD2B
April 6, 2022
This program will do basic operations*/

using System;

namespace BasicOperations_Duran
{
    class Basicoperations
    {
        static void Main()
        {
            int num1, num2;

            Console.WriteLine("Please Enter 2 numbers. ");
            Console.Write("Enter first number:  ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number:  ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nThe Sum is = {0} ", num1 + num2);
            Console.Write("\nThe Difference is = {0} ", num1 - num2);
            Console.Write("\nThe Product is = {0} ", num1 * num2);
            Console.Write("\nThe Quotient is = {0} ", num1 / num2);
            Console.Write("\nThe Remainder is = {0} ", num1 % num2);
            System.Console.ReadKey();

        }
    }
}