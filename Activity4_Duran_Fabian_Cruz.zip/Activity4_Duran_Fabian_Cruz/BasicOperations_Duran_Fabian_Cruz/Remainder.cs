﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicOperations_Duran_Fabian_Cruz
{
    class Remainder
    {
        public void ComputeRemainder()
        {
            DeclareVar.remainder = DeclareVar.num1 % DeclareVar.num2;
        }
    }
}
