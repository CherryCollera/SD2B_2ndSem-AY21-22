﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;


namespace DatabaseConnection_Manansala_Francisco_Cruz_A
{
    public partial class Form1 : Form
    {
        private OleDbConnection bookConn;
        private OleDbCommand oleDbCmd = new OleDbCommand();
        
        private String connParam = @"Provider=Microsoft.ACE.OLEDB.12.0;
        ;Data Source=C:\Users\acer\source\repos\Activity8_Manansala_Francisco_Cruz A\book3.accdb";
        //@"Provider=Microsoft.ACE.OLEDB.12.0;
        //;Data Source = C:\Users\acer\source\repos\Activity8_Manansala_Francisco_Cruz A\book3.mdb";

        private int bookID;

        public Form1()
        {
            bookConn = new OleDbConnection(connParam);
            
            InitializeComponent();
            refresh();

            btn_Save.Enabled = false;
            dataGridView1.ReadOnly = true;
        }

        private void clearAll()
        {
            txt_Title.Clear();
            txt_Desc.Clear();
            txt_BookNo.Clear();
            bookID = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.bookrecordsTableAdapter.Fill(this.book3DataSet.bookrecords);
            Graphics g = this.CreateGraphics();
            double fw = this.Width; // form width
            double tw = g.MeasureString(this.Text.Trim(), this.Font).Width;
            double rp = (fw - tw) / 3;
            int tt = Convert.ToInt32(rp);
            string st = "                                                                             ";
            st = st.PadRight(tt / 3);
            this.Text = st + this.Text.Trim();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(txt_Title.Text != "" && txt_BookNo.Text != "" && txt_Desc.Text != "")
            {
                bookConn.Open();
                oleDbCmd.Connection = bookConn;
                oleDbCmd.CommandText = "Insert into bookrecords (booktitle, description, bookno) " +
                    "values ('" + this.txt_Title.Text + "' , '" + this.txt_Desc.Text + "' , '" + this.txt_BookNo.Text + "');";
                int temp = oleDbCmd.ExecuteNonQuery();
                if (temp > 0)
                {
                    clearAll();
                    refresh();
                    MessageBox.Show("Record Successfully Added."); 
                    MessageBox.Show("NOTE: Kindly click VIEW ALL RECORDS to see the updated list.");

                }
                else
                {
                    MessageBox.Show("Record Fail Added.");
                }
                bookConn.Close();
            }
            else
            {
                MessageBox.Show("ALERT: Kindly fill out every field.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bookID = 0;

            txt_Title.Clear();
            txt_Desc.Clear();
            txt_BookNo.Clear();

            refresh();
        }

        private void refresh()
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("SELECT * FROM bookrecords", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("UPDATE * FROM bookrecords", connParam);
            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable datatable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(datatable);
            for (int i = 0; i < datatable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(datatable.Rows[i][0],
                datatable.Rows[i][1], datatable.Rows[i][2],
                datatable.Rows[i][3]);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (bookID != 0)
            {
                DialogResult ans;
                ans = MessageBox.Show("Are you sure you want to remove the selected record?"
                    , "REMOVE THE RECORD?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (ans == DialogResult.Yes)
                {
                    bookConn.Open();
                    oleDbCmd.Connection = bookConn;
                    oleDbCmd.CommandText = "DELETE FROM bookrecords WHERE ID = " + bookID + ";";
                    int temp = oleDbCmd.ExecuteNonQuery();
                    bookConn.Close();

                    MessageBox.Show("The selected record has been deleted.");

                    txt_Title.Text = null;
                    txt_Desc.Text = null;
                    txt_BookNo.Text = null;

                    refresh();
                }
                else
                {
                    MessageBox.Show("Cancelled");
                    clearAll();
                }
            }
            else
            {
                MessageBox.Show("ALERT: Kindly select a record to be deleted.");
            }
        }

        private void btn_Edit_Click(object sender, EventArgs e)
        {
            if (txt_Title.Text != "" || txt_Desc.Text != "" || txt_BookNo.Text != "")
            {
                //Save and View All Records button are only enabled
                btn_Save.Enabled = true;
                dataGridView1.ReadOnly = false;
                btn_Add.Enabled = false;
                btn_Delete.Enabled = false;
                dataGridView1.Enabled = false;
                btn_Edit.Enabled = false;
                btn_View.Enabled = false;
                refresh();

                MessageBox.Show("NOTE: Only one record can be edited at a time.");
            }
            else
            {
                MessageBox.Show("ALERT: Kindly select a record to be edited.");
            }
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbCmd.Connection = bookConn;
            oleDbCmd.CommandText = "UPDATE bookrecords SET booktitle = '" + this.txt_Title.Text + "' , " +
                "description = '" + txt_Desc.Text + "' , bookno = '" + txt_BookNo.Text + "' " +
                "WHERE ID = " + bookID + ";";
            int temp = oleDbCmd.ExecuteNonQuery();
            bookConn.Close();

            MessageBox.Show("Changes have been applied.");
            
            btn_Save.Enabled = false;
            btn_Delete.Enabled = true;
            btn_Add.Enabled = true;
            dataGridView1.Enabled = true;
            btn_Edit.Enabled = true;
            btn_View.Enabled = true;

            clearAll();
            refresh();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            bookID = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            txt_Title.Text = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[1].Value);
            txt_Desc.Text = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[2].Value);
            txt_BookNo.Text = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[3].Value);
        }
    }
}
