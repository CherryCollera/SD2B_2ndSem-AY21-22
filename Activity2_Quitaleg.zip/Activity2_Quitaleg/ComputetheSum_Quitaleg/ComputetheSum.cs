﻿/*
20-02604
Jaycee Audrei Mari M. Quitaleg
SD2B
April 06, 2022
This program will compute the sum of two integers and display its sum.
 */

using System;

namespace ComputeSum
{
    class ComputeSum
    {
        static void Main()
        {
            Console.Write("Enter the first number: ");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the second number: ");
            int num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\nThe sum of the two numbers is = {0}", num1 + num2);
            Console.ReadLine();
        }
    }
}
