class Difference{
    public void computeDifference(){
        DeclareVar.difference = DeclareVar.num1 - DeclareVar.num2;
    }
}