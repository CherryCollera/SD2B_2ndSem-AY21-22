﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassExample2_Duran_Fabian_Cruz
{
    class Car
    {
        private string color;

        public Car(string color)
        {
            this.color = color;
        }

        public string Describe()
        { 
        return "This car is " + color;
        }
    }
}
