﻿/* Activity #5
 * Group Members: Carlos, Roiel A.
 *                Diego, Angelo R.
 *                Sarmiento, Marian Gillian G.
 * Program, Year, and Section: BSCS-SD2B
 * Date: 05/04/2022
 This form performs basic mathematic operations and connects to Form3.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1_Carlos_Diego_Sarmiento
{
    public partial class Form4 : Form
    {
        double a, b;

        public Form4()
        {
            InitializeComponent();
        }

        private void btn_Multiplication_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(txt_Firstnumber.Text);
            b = Convert.ToDouble(txtSecondnumber.Text);
            txt_Answer.Text = (a * b).ToString();
        }

        private void btn_Division_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(txt_Firstnumber.Text);
            b = Convert.ToDouble(txtSecondnumber.Text);
            txt_Answer.Text = (a / b).ToString();
        }

        private void btn_Subtraction_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(txt_Firstnumber.Text);
            b = Convert.ToDouble(txtSecondnumber.Text);
            txt_Answer.Text = (a - b).ToString();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.Show();
            this.Hide();
        }

        private void btn_Addition_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(txt_Firstnumber.Text);
            b = Convert.ToDouble(txtSecondnumber.Text);
            txt_Answer.Text = (a + b).ToString();
        }
    }
}
