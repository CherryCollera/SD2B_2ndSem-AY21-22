﻿
namespace DatabaseConnection_Manansala_Francisco_Cruz_A
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txt_Desc = new System.Windows.Forms.TextBox();
            this.txt_Title = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Edit = new System.Windows.Forms.Button();
            this.btn_View = new System.Windows.Forms.Button();
            this.btn_Add = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.booktitleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.booknoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bookrecordsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.book3DataSet = new DatabaseConnection_Manansala_Francisco_Cruz_A.book3DataSet();
            this.bookrecordsTableAdapter = new DatabaseConnection_Manansala_Francisco_Cruz_A.book3DataSetTableAdapters.bookrecordsTableAdapter();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_BookNo = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookrecordsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.book3DataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_Desc
            // 
            this.txt_Desc.Location = new System.Drawing.Point(136, 58);
            this.txt_Desc.Name = "txt_Desc";
            this.txt_Desc.Size = new System.Drawing.Size(302, 20);
            this.txt_Desc.TabIndex = 7;
            // 
            // txt_Title
            // 
            this.txt_Title.Location = new System.Drawing.Point(136, 26);
            this.txt_Title.Name = "txt_Title";
            this.txt_Title.Size = new System.Drawing.Size(302, 20);
            this.txt_Title.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Book Description";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Book Title";
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(509, 366);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(103, 39);
            this.btn_Delete.TabIndex = 19;
            this.btn_Delete.Text = "DELETE";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.button5_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.Location = new System.Drawing.Point(509, 308);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(103, 39);
            this.btn_Save.TabIndex = 18;
            this.btn_Save.Text = "SAVE";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // btn_Edit
            // 
            this.btn_Edit.Location = new System.Drawing.Point(509, 249);
            this.btn_Edit.Name = "btn_Edit";
            this.btn_Edit.Size = new System.Drawing.Size(103, 39);
            this.btn_Edit.TabIndex = 17;
            this.btn_Edit.Text = "EDIT A RECORD";
            this.btn_Edit.UseVisualStyleBackColor = true;
            this.btn_Edit.Click += new System.EventHandler(this.btn_Edit_Click);
            // 
            // btn_View
            // 
            this.btn_View.Location = new System.Drawing.Point(509, 190);
            this.btn_View.Name = "btn_View";
            this.btn_View.Size = new System.Drawing.Size(103, 39);
            this.btn_View.TabIndex = 16;
            this.btn_View.Text = "VIEW ALL RECORDS";
            this.btn_View.UseVisualStyleBackColor = true;
            this.btn_View.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(509, 130);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(103, 39);
            this.btn_Add.TabIndex = 15;
            this.btn_Add.Text = "ADD NEW RECORD";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.booktitleDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn,
            this.booknoDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.bookrecordsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(37, 135);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(443, 275);
            this.dataGridView1.TabIndex = 14;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // booktitleDataGridViewTextBoxColumn
            // 
            this.booktitleDataGridViewTextBoxColumn.DataPropertyName = "booktitle";
            this.booktitleDataGridViewTextBoxColumn.HeaderText = "booktitle";
            this.booktitleDataGridViewTextBoxColumn.Name = "booktitleDataGridViewTextBoxColumn";
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "description";
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            // 
            // booknoDataGridViewTextBoxColumn
            // 
            this.booknoDataGridViewTextBoxColumn.DataPropertyName = "bookno";
            this.booknoDataGridViewTextBoxColumn.HeaderText = "bookno";
            this.booknoDataGridViewTextBoxColumn.Name = "booknoDataGridViewTextBoxColumn";
            // 
            // bookrecordsBindingSource
            // 
            this.bookrecordsBindingSource.DataMember = "bookrecords";
            this.bookrecordsBindingSource.DataSource = this.book3DataSet;
            // 
            // book3DataSet
            // 
            this.book3DataSet.DataSetName = "book3DataSet";
            this.book3DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bookrecordsTableAdapter
            // 
            this.bookrecordsTableAdapter.ClearBeforeFill = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Book Number";
            // 
            // txt_BookNo
            // 
            this.txt_BookNo.Location = new System.Drawing.Point(136, 90);
            this.txt_BookNo.Name = "txt_BookNo";
            this.txt_BookNo.Size = new System.Drawing.Size(302, 20);
            this.txt_BookNo.TabIndex = 21;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(646, 432);
            this.Controls.Add(this.txt_BookNo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.btn_Edit);
            this.Controls.Add(this.btn_View);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txt_Desc);
            this.Controls.Add(this.txt_Title);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Book Monitoring System";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookrecordsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.book3DataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_Desc;
        private System.Windows.Forms.TextBox txt_Title;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_Edit;
        private System.Windows.Forms.Button btn_View;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.DataGridView dataGridView1;
        private book3DataSet book3DataSet;
        private System.Windows.Forms.BindingSource bookrecordsBindingSource;
        private book3DataSetTableAdapters.bookrecordsTableAdapter bookrecordsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn booktitleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn booknoDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_BookNo;
    }
}

