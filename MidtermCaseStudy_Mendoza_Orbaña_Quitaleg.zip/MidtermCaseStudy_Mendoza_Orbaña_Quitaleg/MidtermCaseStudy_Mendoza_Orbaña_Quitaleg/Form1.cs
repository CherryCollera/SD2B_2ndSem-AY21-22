namespace MidtermCaseStudy_Mendoza_Orbaña_Quitaleg
{
    public partial class Form1 : Form
    {
        double total1 = 0;

        double total2 = 0;

        bool plusButtonClicked = false;

        bool minusButtonClicked = false;

        bool divideButtonClicked = false;

        bool multiplyButtonClicked = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + button1.Text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + button2.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + button3.Text;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + button4.Text;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + button5.Text;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + button6.Text;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + button7.Text;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + button8.Text;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + button9.Text;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + button10.Text;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            minusButtonClicked = false;

            plusButtonClicked = true;

            divideButtonClicked = false;

            multiplyButtonClicked = false;

        

        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (plusButtonClicked == true)

            {

                total2 = total1 + double.Parse(txtDisplay.Text);

            }

            else if (minusButtonClicked == true)

            {

                total2 = total1 - double.Parse(txtDisplay.Text);

            }

            else if (multiplyButtonClicked == true)

            {

                total2 = total1 * double.Parse(txtDisplay.Text);

            }

            else if (divideButtonClicked == true)

            {
                total2 = total1 / double.Parse(txtDisplay.Text);

            }

            txtDisplay.Text = total2.ToString(); total1 = 0;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + button16.Text;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            minusButtonClicked = true;

            plusButtonClicked = false;

            divideButtonClicked = false;

            multiplyButtonClicked = false;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            minusButtonClicked = false;

            plusButtonClicked = false;

            divideButtonClicked = false;

            multiplyButtonClicked = true;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            minusButtonClicked = false;

            plusButtonClicked = false;

            divideButtonClicked = true;

            multiplyButtonClicked = false;
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
            this.Hide();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Form3 form = new Form3();
            form.Show();
            this.Hide();

        }
    }
}