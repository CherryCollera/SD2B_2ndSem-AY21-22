﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 15, 2022
 *  Windows Form: Calculator, Message,
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace MidtermCaseStudy_Matos_Dianna_Grace
    {
        internal static class Program
            {
                [STAThread]
                static void Main()
                    {
                        Application.EnableVisualStyles();
                        Application.SetCompatibleTextRenderingDefault(false);
                        Application.Run(new Menu());
                    }
            }
    }
