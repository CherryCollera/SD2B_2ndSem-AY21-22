﻿/*20-02190
Borboran, Keanu Dave E.
SD2B
March 29, 2022
This program will display the phrase "Hello World"*/

using System;

namespace Sample1_Borboran
{
    
    class HelloWorld
    {
        static void Main(string[] args)
        {
            Console.WriteLine("HelloWorld");
            Console.ReadKey();
        }
    }
}