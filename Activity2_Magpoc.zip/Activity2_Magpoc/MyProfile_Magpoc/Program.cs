﻿    
/*
 
Jermaine T. Magpoc
SD-2B
March 20,2022
This Program Will accept input from the user and display your name.


 
 */



using System;

namespace Sample2_MyProfile
{

    public class Program
    {
        static void Main(string[] args)
        {

            System.Console.Write("Enter your name (firstname, lastname) ");
            string name = Console.ReadLine();

            System.Console.WriteLine("");
            System.Console.WriteLine(name + "!!!");
            System.Console.WriteLine("Welcome to OOP environment.");
            Console.ReadLine();


        }
    }
}