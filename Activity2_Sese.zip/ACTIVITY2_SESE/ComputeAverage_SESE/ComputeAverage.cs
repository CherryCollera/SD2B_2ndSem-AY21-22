﻿//This Program will compute the average of the data input
using System;

namespace ComputeAverage_SESE
{
    class ComputeAverage
    {
        static void Main(string[] args)
        {
            int num1, num2, num3, num4, num5, average;
            Console.WriteLine("Enter 5 Grades: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            num2 = Convert.ToInt32(Console.ReadLine());
            num3 = Convert.ToInt32(Console.ReadLine());
            num4 = Convert.ToInt32(Console.ReadLine());
            num5 = Convert.ToInt32(Console.ReadLine());
            average = (num1 + num2 + num3 + num4 + num5) / 5;
            Console.WriteLine("The Average is {0:0.000}.", average);
            Console.ReadLine();
        }
    }
}
