﻿using System;

namespace DeclaringConstants_Manansala
{
    class DeclaringConstants
    {
        static void Main(string[] args)
        {
            const double pi = 3.14159;
            Double radius, AreaCircle;
            Console.Write("Enter Radius: ");
            radius = Convert.ToInt32(Console.ReadLine());
            AreaCircle = pi * radius * radius;
            Console.Write("Radius: {0:0.0000}, ", radius);
            Console.Write("Area: {0:0.0000}", AreaCircle);
            Console.ReadKey();
        }
    }
}
