﻿
namespace Activity6_Francisco
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.bSCS_STUDENTToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSCS_STUDENTToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.studentIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.myDatabaseDataSet = new Activity6_Francisco.MyDatabaseDataSet();
            this.studentTableAdapter = new Activity6_Francisco.MyDatabaseDataSetTableAdapters.StudentTableAdapter();
            this.bSIT_STUDENTToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSIT_STUDENTToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.aDDRESS_SAMALToolStrip = new System.Windows.Forms.ToolStrip();
            this.aDDRESS_SAMALToolStripButton = new System.Windows.Forms.ToolStripButton();
            this._2NDYEAR_STUDENTToolStrip = new System.Windows.Forms.ToolStrip();
            this._2NDYEAR_STUDENTToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.rEFRESHToolStrip = new System.Windows.Forms.ToolStrip();
            this.rEFRESHToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lASTNAME_STARTWITH_AandCToolStrip = new System.Windows.Forms.ToolStrip();
            this.lASTNAME_STARTWITH_AandCToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.sECTION_2BToolStrip = new System.Windows.Forms.ToolStrip();
            this.sECTION_2BToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStrip = new System.Windows.Forms.ToolStrip();
            this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStripButton = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.bSCS_STUDENTToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSet)).BeginInit();
            this.bSIT_STUDENTToolStrip.SuspendLayout();
            this.aDDRESS_SAMALToolStrip.SuspendLayout();
            this._2NDYEAR_STUDENTToolStrip.SuspendLayout();
            this.rEFRESHToolStrip.SuspendLayout();
            this.lASTNAME_STARTWITH_AandCToolStrip.SuspendLayout();
            this.sECTION_2BToolStrip.SuspendLayout();
            this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studentIDDataGridViewTextBoxColumn,
            this.lastnameDataGridViewTextBoxColumn,
            this.firstnameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.programDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn,
            this.yearDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.studentBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 36);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(784, 342);
            this.dataGridView1.TabIndex = 0;
            // 
            // bSCS_STUDENTToolStrip
            // 
            this.bSCS_STUDENTToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSCS_STUDENTToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSCS_STUDENTToolStripButton});
            this.bSCS_STUDENTToolStrip.Location = new System.Drawing.Point(12, 381);
            this.bSCS_STUDENTToolStrip.Name = "bSCS_STUDENTToolStrip";
            this.bSCS_STUDENTToolStrip.Size = new System.Drawing.Size(104, 25);
            this.bSCS_STUDENTToolStrip.TabIndex = 1;
            this.bSCS_STUDENTToolStrip.Text = "bSCS_STUDENTToolStrip";
            // 
            // bSCS_STUDENTToolStripButton
            // 
            this.bSCS_STUDENTToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSCS_STUDENTToolStripButton.Name = "bSCS_STUDENTToolStripButton";
            this.bSCS_STUDENTToolStripButton.Size = new System.Drawing.Size(92, 22);
            this.bSCS_STUDENTToolStripButton.Text = "BSCS_STUDENT";
            this.bSCS_STUDENTToolStripButton.Click += new System.EventHandler(this.bSCS_STUDENTToolStripButton_Click);
            // 
            // studentIDDataGridViewTextBoxColumn
            // 
            this.studentIDDataGridViewTextBoxColumn.DataPropertyName = "StudentID";
            this.studentIDDataGridViewTextBoxColumn.HeaderText = "StudentID";
            this.studentIDDataGridViewTextBoxColumn.Name = "studentIDDataGridViewTextBoxColumn";
            // 
            // lastnameDataGridViewTextBoxColumn
            // 
            this.lastnameDataGridViewTextBoxColumn.DataPropertyName = "Lastname";
            this.lastnameDataGridViewTextBoxColumn.HeaderText = "Lastname";
            this.lastnameDataGridViewTextBoxColumn.Name = "lastnameDataGridViewTextBoxColumn";
            // 
            // firstnameDataGridViewTextBoxColumn
            // 
            this.firstnameDataGridViewTextBoxColumn.DataPropertyName = "Firstname";
            this.firstnameDataGridViewTextBoxColumn.HeaderText = "Firstname";
            this.firstnameDataGridViewTextBoxColumn.Name = "firstnameDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // programDataGridViewTextBoxColumn
            // 
            this.programDataGridViewTextBoxColumn.DataPropertyName = "Program";
            this.programDataGridViewTextBoxColumn.HeaderText = "Program";
            this.programDataGridViewTextBoxColumn.Name = "programDataGridViewTextBoxColumn";
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            // 
            // yearDataGridViewTextBoxColumn
            // 
            this.yearDataGridViewTextBoxColumn.DataPropertyName = "Year";
            this.yearDataGridViewTextBoxColumn.HeaderText = "Year";
            this.yearDataGridViewTextBoxColumn.Name = "yearDataGridViewTextBoxColumn";
            // 
            // studentBindingSource
            // 
            this.studentBindingSource.DataMember = "Student";
            this.studentBindingSource.DataSource = this.myDatabaseDataSet;
            this.studentBindingSource.CurrentChanged += new System.EventHandler(this.studentBindingSource_CurrentChanged);
            // 
            // myDatabaseDataSet
            // 
            this.myDatabaseDataSet.DataSetName = "MyDatabaseDataSet";
            this.myDatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentTableAdapter
            // 
            this.studentTableAdapter.ClearBeforeFill = true;
            // 
            // bSIT_STUDENTToolStrip
            // 
            this.bSIT_STUDENTToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSIT_STUDENTToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSIT_STUDENTToolStripButton});
            this.bSIT_STUDENTToolStrip.Location = new System.Drawing.Point(131, 381);
            this.bSIT_STUDENTToolStrip.Name = "bSIT_STUDENTToolStrip";
            this.bSIT_STUDENTToolStrip.Size = new System.Drawing.Size(99, 25);
            this.bSIT_STUDENTToolStrip.TabIndex = 2;
            this.bSIT_STUDENTToolStrip.Text = "bSIT_STUDENTToolStrip";
            // 
            // bSIT_STUDENTToolStripButton
            // 
            this.bSIT_STUDENTToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSIT_STUDENTToolStripButton.Name = "bSIT_STUDENTToolStripButton";
            this.bSIT_STUDENTToolStripButton.Size = new System.Drawing.Size(87, 22);
            this.bSIT_STUDENTToolStripButton.Text = "BSIT_STUDENT";
            this.bSIT_STUDENTToolStripButton.Click += new System.EventHandler(this.bSIT_STUDENTToolStripButton_Click);
            // 
            // aDDRESS_SAMALToolStrip
            // 
            this.aDDRESS_SAMALToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.aDDRESS_SAMALToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDDRESS_SAMALToolStripButton});
            this.aDDRESS_SAMALToolStrip.Location = new System.Drawing.Point(245, 381);
            this.aDDRESS_SAMALToolStrip.Name = "aDDRESS_SAMALToolStrip";
            this.aDDRESS_SAMALToolStrip.Size = new System.Drawing.Size(116, 25);
            this.aDDRESS_SAMALToolStrip.TabIndex = 3;
            this.aDDRESS_SAMALToolStrip.Text = "aDDRESS_SAMALToolStrip";
            // 
            // aDDRESS_SAMALToolStripButton
            // 
            this.aDDRESS_SAMALToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.aDDRESS_SAMALToolStripButton.Name = "aDDRESS_SAMALToolStripButton";
            this.aDDRESS_SAMALToolStripButton.Size = new System.Drawing.Size(104, 22);
            this.aDDRESS_SAMALToolStripButton.Text = "ADDRESS_SAMAL";
            this.aDDRESS_SAMALToolStripButton.Click += new System.EventHandler(this.aDDRESS_SAMALToolStripButton_Click);
            // 
            // _2NDYEAR_STUDENTToolStrip
            // 
            this._2NDYEAR_STUDENTToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this._2NDYEAR_STUDENTToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._2NDYEAR_STUDENTToolStripButton});
            this._2NDYEAR_STUDENTToolStrip.Location = new System.Drawing.Point(377, 381);
            this._2NDYEAR_STUDENTToolStrip.Name = "_2NDYEAR_STUDENTToolStrip";
            this._2NDYEAR_STUDENTToolStrip.Size = new System.Drawing.Size(133, 25);
            this._2NDYEAR_STUDENTToolStrip.TabIndex = 4;
            this._2NDYEAR_STUDENTToolStrip.Text = "_2NDYEAR_STUDENTToolStrip";
            // 
            // _2NDYEAR_STUDENTToolStripButton
            // 
            this._2NDYEAR_STUDENTToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this._2NDYEAR_STUDENTToolStripButton.Name = "_2NDYEAR_STUDENTToolStripButton";
            this._2NDYEAR_STUDENTToolStripButton.Size = new System.Drawing.Size(121, 22);
            this._2NDYEAR_STUDENTToolStripButton.Text = "_2NDYEAR_STUDENT";
            this._2NDYEAR_STUDENTToolStripButton.Click += new System.EventHandler(this._2NDYEAR_STUDENTToolStripButton_Click);
            // 
            // rEFRESHToolStrip
            // 
            this.rEFRESHToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.rEFRESHToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rEFRESHToolStripButton});
            this.rEFRESHToolStrip.Location = new System.Drawing.Point(527, 381);
            this.rEFRESHToolStrip.Name = "rEFRESHToolStrip";
            this.rEFRESHToolStrip.Size = new System.Drawing.Size(70, 25);
            this.rEFRESHToolStrip.TabIndex = 5;
            this.rEFRESHToolStrip.Text = "rEFRESHToolStrip";
            // 
            // rEFRESHToolStripButton
            // 
            this.rEFRESHToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.rEFRESHToolStripButton.Name = "rEFRESHToolStripButton";
            this.rEFRESHToolStripButton.Size = new System.Drawing.Size(58, 22);
            this.rEFRESHToolStripButton.Text = "REFRESH";
            this.rEFRESHToolStripButton.Click += new System.EventHandler(this.rEFRESHToolStripButton_Click);
            // 
            // lASTNAME_STARTWITH_AandCToolStrip
            // 
            this.lASTNAME_STARTWITH_AandCToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.lASTNAME_STARTWITH_AandCToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lASTNAME_STARTWITH_AandCToolStripButton});
            this.lASTNAME_STARTWITH_AandCToolStrip.Location = new System.Drawing.Point(12, 416);
            this.lASTNAME_STARTWITH_AandCToolStrip.Name = "lASTNAME_STARTWITH_AandCToolStrip";
            this.lASTNAME_STARTWITH_AandCToolStrip.Size = new System.Drawing.Size(189, 25);
            this.lASTNAME_STARTWITH_AandCToolStrip.TabIndex = 6;
            this.lASTNAME_STARTWITH_AandCToolStrip.Text = "lASTNAME_STARTWITH_AandCToolStrip";
            // 
            // lASTNAME_STARTWITH_AandCToolStripButton
            // 
            this.lASTNAME_STARTWITH_AandCToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lASTNAME_STARTWITH_AandCToolStripButton.Name = "lASTNAME_STARTWITH_AandCToolStripButton";
            this.lASTNAME_STARTWITH_AandCToolStripButton.Size = new System.Drawing.Size(177, 22);
            this.lASTNAME_STARTWITH_AandCToolStripButton.Text = "LASTNAME_STARTWITH_AandC";
            this.lASTNAME_STARTWITH_AandCToolStripButton.Click += new System.EventHandler(this.lASTNAME_STARTWITH_AandCToolStripButton_Click);
            // 
            // sECTION_2BToolStrip
            // 
            this.sECTION_2BToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.sECTION_2BToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sECTION_2BToolStripButton});
            this.sECTION_2BToolStrip.Location = new System.Drawing.Point(217, 416);
            this.sECTION_2BToolStrip.Name = "sECTION_2BToolStrip";
            this.sECTION_2BToolStrip.Size = new System.Drawing.Size(88, 25);
            this.sECTION_2BToolStrip.TabIndex = 7;
            this.sECTION_2BToolStrip.Text = "sECTION_2BToolStrip";
            // 
            // sECTION_2BToolStripButton
            // 
            this.sECTION_2BToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.sECTION_2BToolStripButton.Name = "sECTION_2BToolStripButton";
            this.sECTION_2BToolStripButton.Size = new System.Drawing.Size(76, 22);
            this.sECTION_2BToolStripButton.Text = "SECTION_2B";
            this.sECTION_2BToolStripButton.Click += new System.EventHandler(this.sECTION_2BToolStripButton_Click);
            // 
            // fIRSTNAME_STARTWITH_CONSONANTLETTERToolStrip
            // 
            this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStripButton});
            this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStrip.Location = new System.Drawing.Point(319, 416);
            this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStrip.Name = "fIRSTNAME_STARTWITH_CONSONANTLETTERToolStrip";
            this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStrip.Size = new System.Drawing.Size(265, 25);
            this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStrip.TabIndex = 8;
            this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStrip.Text = "fIRSTNAME_STARTWITH_CONSONANTLETTERToolStrip";
            // 
            // fIRSTNAME_STARTWITH_CONSONANTLETTERToolStripButton
            // 
            this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStripButton.Name = "fIRSTNAME_STARTWITH_CONSONANTLETTERToolStripButton";
            this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStripButton.Size = new System.Drawing.Size(23, 23);
            this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStripButton.Text = "FIRSTNAME_STARTWITH_CONSONANTLETTER";
            this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStripButton.Click += new System.EventHandler(this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStripButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(816, 461);
            this.Controls.Add(this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStrip);
            this.Controls.Add(this.sECTION_2BToolStrip);
            this.Controls.Add(this.lASTNAME_STARTWITH_AandCToolStrip);
            this.Controls.Add(this.rEFRESHToolStrip);
            this.Controls.Add(this._2NDYEAR_STUDENTToolStrip);
            this.Controls.Add(this.aDDRESS_SAMALToolStrip);
            this.Controls.Add(this.bSIT_STUDENTToolStrip);
            this.Controls.Add(this.bSCS_STUDENTToolStrip);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.bSCS_STUDENTToolStrip.ResumeLayout(false);
            this.bSCS_STUDENTToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDatabaseDataSet)).EndInit();
            this.bSIT_STUDENTToolStrip.ResumeLayout(false);
            this.bSIT_STUDENTToolStrip.PerformLayout();
            this.aDDRESS_SAMALToolStrip.ResumeLayout(false);
            this.aDDRESS_SAMALToolStrip.PerformLayout();
            this._2NDYEAR_STUDENTToolStrip.ResumeLayout(false);
            this._2NDYEAR_STUDENTToolStrip.PerformLayout();
            this.rEFRESHToolStrip.ResumeLayout(false);
            this.rEFRESHToolStrip.PerformLayout();
            this.lASTNAME_STARTWITH_AandCToolStrip.ResumeLayout(false);
            this.lASTNAME_STARTWITH_AandCToolStrip.PerformLayout();
            this.sECTION_2BToolStrip.ResumeLayout(false);
            this.sECTION_2BToolStrip.PerformLayout();
            this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStrip.ResumeLayout(false);
            this.fIRSTNAME_STARTWITH_CONSONANTLETTERToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private MyDatabaseDataSet myDatabaseDataSet;
        private System.Windows.Forms.BindingSource studentBindingSource;
        private MyDatabaseDataSetTableAdapters.StudentTableAdapter studentTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn programDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStrip bSCS_STUDENTToolStrip;
        private System.Windows.Forms.ToolStripButton bSCS_STUDENTToolStripButton;
        private System.Windows.Forms.ToolStrip bSIT_STUDENTToolStrip;
        private System.Windows.Forms.ToolStripButton bSIT_STUDENTToolStripButton;
        private System.Windows.Forms.ToolStrip aDDRESS_SAMALToolStrip;
        private System.Windows.Forms.ToolStripButton aDDRESS_SAMALToolStripButton;
        private System.Windows.Forms.ToolStrip _2NDYEAR_STUDENTToolStrip;
        private System.Windows.Forms.ToolStripButton _2NDYEAR_STUDENTToolStripButton;
        private System.Windows.Forms.ToolStrip rEFRESHToolStrip;
        private System.Windows.Forms.ToolStripButton rEFRESHToolStripButton;
        private System.Windows.Forms.ToolStrip lASTNAME_STARTWITH_AandCToolStrip;
        private System.Windows.Forms.ToolStripButton lASTNAME_STARTWITH_AandCToolStripButton;
        private System.Windows.Forms.ToolStrip sECTION_2BToolStrip;
        private System.Windows.Forms.ToolStripButton sECTION_2BToolStripButton;
        private System.Windows.Forms.ToolStrip fIRSTNAME_STARTWITH_CONSONANTLETTERToolStrip;
        private System.Windows.Forms.ToolStripButton fIRSTNAME_STARTWITH_CONSONANTLETTERToolStripButton;
    }
}

