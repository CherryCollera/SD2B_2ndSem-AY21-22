﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassExample1A_Duran_Fabian_Cruz
{
    class MyProfile
    {
        public void DisplayProfile()
        {
            System.Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E");
            System.Console.WriteLine("Name: \t\t\tAngelo Duran");
            System.Console.WriteLine("Birthday:\t\tMay 11, 2002");
            System.Console.WriteLine("Course:\t\t\tBS in Computer Science Major in Software Development");
            System.Console.WriteLine("Year:\t\t\t2nd Year");
            System.Console.WriteLine("Section:\t\t\tB");
            Console.ReadLine();
        }
    }
}
