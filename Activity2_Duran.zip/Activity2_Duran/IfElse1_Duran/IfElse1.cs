﻿/*20-03334
Angelo Duran
SD2B
April 6, 2022
This program will execute IfElse1*/

using System;

namespace IfElse_Duran
{
    class Ifelse
    {
        static void Main()
        {
            int num1, num2;
            Console.Write("Enter the 1st number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the 2nd Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2)
            {
                Console.WriteLine(num1 + " is greater than {0}.", num2);
            }

            else if (num1 < num2)
            {
                Console.WriteLine(num2 + " is greater than {0}.", num1);
            }

            else if (num1 == num2)
                Console.WriteLine(num1 + " is equal to {0}.", num2);

            Console.ReadKey();
        }
    }
}