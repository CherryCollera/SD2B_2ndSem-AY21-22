﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 16, 2022
 *  Determine the user's grade using if else
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CompareNames
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int grade = 0;
            double eqGrade = 0;
            string remarks = "";


            Console.Write("Enter your final grade : ");
            try
            {
                grade = Convert.ToInt32(Console.ReadLine());


                if (grade >= 98 && grade <= 100)
                {
                    eqGrade = 1.00;
                    remarks = "Excellent";
                }
                else if (grade >= 95 && grade <= 97)
                {
                    eqGrade = 1.25;
                    remarks = "Excellent";
                }
                else if (grade >= 92 && grade <= 94)
                {
                    eqGrade = 1.50;
                    remarks = "Very Good";
                }
                else if (grade >= 89 && grade <= 91)
                {
                    eqGrade = 1.75;
                    remarks = "Very Good";
                }
                else if (grade >= 86 && grade <= 88)
                {
                    eqGrade = 2.00;
                    remarks = "Good";
                }
                else if (grade >= 83 && grade <= 85)
                {
                    eqGrade = 2.25;
                    remarks = "Good";
                }
                else if (grade >= 80 && grade <= 82)
                {
                    eqGrade = 2.50;
                    remarks = "Fair";
                }
                else if (grade >= 77 && grade <= 79)
                {
                    eqGrade = 2.75;
                    remarks = "Fair";
                }
                else if (grade >= 75 && grade <= 77)
                {
                    eqGrade = 3.00;
                    remarks = "Passed";
                }
                else if (grade >= 72 && grade <= 74)
                {
                    eqGrade = 4.00;
                    remarks = "Conditional(MT only)";
                }
                else if (grade >= 60 && grade <= 71)
                {
                    eqGrade = 5.00;
                    remarks = "Failed";
                }

                Console.Write("Grade Equivalent: {0}\n", eqGrade);
                Console.Write("Remarks: {0}", remarks);
            }
            catch (Exception e)
            {
                Console.Write("Incomplete");
            }
        }
    }
}
