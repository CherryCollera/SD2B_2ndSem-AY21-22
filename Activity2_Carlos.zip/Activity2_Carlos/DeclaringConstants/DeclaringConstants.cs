﻿/*
 * 20-00382
 * Roiel A. Carlos
 * SD2B
 * April 7, 2022
 * This program will declare a constant and get the area of a circle with the radius.
 */
using System;

namespace DeclaringConstants_Carlos
{
    class DeclaringConstants
    {
        static void Main(string[] args)
        {
            const double pi = 3.14159;
            double radius, AreaCircle;
            Console.Write("Enter Radius: ");
            radius = Convert.ToDouble(Console.ReadLine());
            AreaCircle = pi * radius * radius;

            //print radius and the area of the circle with 4 decimals
            Console.Write("Radius: {0:0.0000}", radius);
            Console.Write(", Area: {0:0.0000}", AreaCircle);
            Console.ReadKey();
        }
    }
}
