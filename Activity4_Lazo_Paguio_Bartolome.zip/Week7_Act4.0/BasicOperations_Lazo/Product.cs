class Product{
    public void computeProduct(){
        DeclareVar.product = DeclareVar.num1 * DeclareVar.num2;
    }
}