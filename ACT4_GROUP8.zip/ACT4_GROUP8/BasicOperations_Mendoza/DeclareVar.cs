﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Mendoza
{
     class DeclareVar
    {
        public static int num1, num2, sum,diff,prod,qou,rem;

    }
}
