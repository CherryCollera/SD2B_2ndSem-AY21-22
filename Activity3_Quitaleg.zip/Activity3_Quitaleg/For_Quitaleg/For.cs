﻿/*
20-02604
Jaycee Audrei Mari M. Quitaleg
SD2B
April 08, 2022
This program will use the for loop.
 */

using System;

namespace For_Quitaleg
{
    class For_Quitaleg
    {
        static void Main(string[] args)
        {
            for (int i = 10 - 1; i >= 0; i--)
            {
                Console.WriteLine(i);
            }

            Console.ReadKey();
        }
    }
}