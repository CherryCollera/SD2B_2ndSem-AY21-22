﻿/** ===========================
 Name: Reywen Lee Bautista
 Course & Section: BSCS-SD2B
 Date: April 17, 2021
=============================*/
using System;

namespace GradingSystem_Bautista
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your grade: ");
            int grade = Convert.ToInt32(Console.ReadLine());

            switch (grade)
            {
                case int num when (num <= 100 && num >= 98):
                    Console.WriteLine("Grade Equivalent: {0}", 1.00);
                    Console.WriteLine("Remarks: {0}", "Excelent");
                    break;
                case int num when (num <= 97 && num >= 95):
                    Console.WriteLine("Grade Equivalent: {0}", 1.25);
                    Console.WriteLine("Remarks: {0}", "Very Good");
                    break;
                case int num when (num <= 94 && num >= 92):
                    Console.WriteLine("Grade Equivalent: {0}", 1.50);
                    Console.WriteLine("Remarks: {0}", "Very Good");
                    break;
                case int num when (num <= 91 && num >= 89):
                    Console.WriteLine("Grade Equivalent: {0}", 1.75);
                    Console.WriteLine("Remarks: {0}", "Very Good");
                    break;
                case int num when (num <= 88 && num >= 86):
                    Console.WriteLine("Grade Equivalent: {0}", 2.00);
                    Console.WriteLine("Remarks: {0}", "Good");
                    break;
                case int num when (num <= 85 && num >= 83):
                    Console.WriteLine("Grade Equivalent: {0}", 2.25);
                    Console.WriteLine("Remarks: {0}", "Good");
                    break;
                case int num when (num <= 82 && num >= 80):
                    Console.WriteLine("Grade Equivalent: {0}", 2.5);
                    Console.WriteLine("Remarks: {0}", "Fair");
                    break;
                case int num when (num <= 79 && num >= 77):
                    Console.WriteLine("Grade Equivalent: {0}", 2.75);
                    Console.WriteLine("Remarks: {0}", "Passed");
                    break;
                case int num when (num <= 76 && num >= 75):
                    Console.WriteLine("Grade Equivalent: {0}", 3.00);
                    Console.WriteLine("Remarks: {0}", "Passed");
                    break;
                case int num when (num <= 74 && num >= 72):
                    Console.WriteLine("Grade Equivalent: {0}", 4.00);
                    Console.WriteLine("Remarks: {0}", "Conditional");
                    break;
                case int num when (num <= 71 && num >= 60):
                    Console.WriteLine("Grade Equivalent: {0}", 5.00);
                    Console.WriteLine("Remarks: {0}", "Failed");
                    break;
                case < 60:
                    Console.WriteLine("Grade Equivalent: {0}", "INC");
                    Console.WriteLine("Remarks: {0}", "Incomplete");
                    break;
                default:
                    Console.WriteLine("Invalid");
                    break;
            }

            Console.ReadKey();
        }
    }
}
