﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace MidtermCaseStudy_Matos_Dianna_Grace
    {
        public partial class Sum : Form
            {
                public Sum()
                    {
                        InitializeComponent();
                    }

                private void button1_Click(object sender, EventArgs e)
                    {
                        int num = 25;
                        MessageBox.Show(num.ToString());
                    }

                private void button2_Click(object sender, EventArgs e)
                    {
                        float num = 25.78F;
                        MessageBox.Show(num.ToString());
                    }

                private void button3_Click(object sender, EventArgs e)
                    {
                        double num = 25.7889;
                        MessageBox.Show(num.ToString());
                    }

                private void label1_Click(object sender, EventArgs e)
                    {
                        
                    }

                private void label2_Click(object sender, EventArgs e)
                    {

                    }

                private void textBox1_TextChanged(object sender, EventArgs e)
                    {

                    }

                private void button4_Click(object sender, EventArgs e)
                    {
                        int num1, num2, sum;

                        
                        num1 = Convert.ToInt32(textBox1.Text);
                        num2 = Convert.ToInt32(textBox1.Text);


                        sum = num1 + num2;


                        MessageBox.Show("The sum is " + Convert.ToString(sum));
                    }

                private void pictureBox1_Click(object sender, EventArgs e)
                    {

                    }

                private void textBox2_TextChanged(object sender, EventArgs e)
                    {
                
                    }

                private void button6_Click(object sender, EventArgs e)
                    {
                        new Calculator().Show();
                        this.Hide();
                    }

                private void button5_Click(object sender, EventArgs e)
                    {
                        new Menu().Show();
                        this.Hide();
                    }
            }
    }
