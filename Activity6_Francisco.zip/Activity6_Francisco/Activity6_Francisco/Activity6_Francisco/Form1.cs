﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity6_Francisco
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'myDatabaseDataSet.Student' table. You can move, or remove it, as needed.
            this.studentTableAdapter.Fill(this.myDatabaseDataSet.Student);

        }

        private void bSCS_STUDENTToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentTableAdapter.BSCS_STUDENT(this.myDatabaseDataSet.Student);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void studentBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void bSIT_STUDENTToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentTableAdapter.BSIT_STUDENT(this.myDatabaseDataSet.Student);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void aDDRESS_SAMALToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentTableAdapter.ADDRESS_SAMAL(this.myDatabaseDataSet.Student);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void _2NDYEAR_STUDENTToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentTableAdapter._2NDYEAR_STUDENT(this.myDatabaseDataSet.Student);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void rEFRESHToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentTableAdapter.REFRESH(this.myDatabaseDataSet.Student);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void lASTNAME_STARTWITH_AandCToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentTableAdapter.LASTNAME_STARTWITH_AandC(this.myDatabaseDataSet.Student);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void sECTION_2BToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentTableAdapter.SECTION_2B(this.myDatabaseDataSet.Student);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fIRSTNAME_STARTWITH_CONSONANTLETTERToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentTableAdapter.FIRSTNAME_STARTWITH_CONSONANTLETTER(this.myDatabaseDataSet.Student);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
