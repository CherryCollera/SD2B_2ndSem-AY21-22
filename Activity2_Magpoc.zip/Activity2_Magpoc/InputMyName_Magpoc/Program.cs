﻿
/*
 
Jermaine T. Magpoc
SD-2B
March 20,2022
This Program Will display your name,date of birth, course, year & Section.


 
 */

using System;

namespace Sample2_MyProfile
{

    public class Program
    {
        static void Main(string[] args)
        {

            System.Console.Write("Name: ");
            string name = Console.ReadLine();
            System.Console.WriteLine("");

            System.Console.Write("Date of Birth: ");
            string birth = Console.ReadLine();
            System.Console.WriteLine("");

            System.Console.Write("Course: ");
            string course = Console.ReadLine();
            System.Console.WriteLine("");

            System.Console.Write("Year: ");
            string year = Console.ReadLine();
            System.Console.WriteLine("");

            System.Console.Write("Section: ");
            string section = Console.ReadLine();
            System.Console.WriteLine("");

            Console.ReadLine();


        }
    }
}