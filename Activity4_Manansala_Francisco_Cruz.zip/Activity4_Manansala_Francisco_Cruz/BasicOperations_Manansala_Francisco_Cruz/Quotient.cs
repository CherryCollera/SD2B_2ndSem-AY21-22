﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Manansala_Francisco_Cruz
{
    class Quotient
    {
        public void ComputeQuotient()
        {
            DeclareVar.quotient = (DeclareVar.num1 / DeclareVar.num2);
        }
    }
}
