﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1A_Anilao_Casaña_Sese
{
    class MyProfile //3rd Class
    {
        public void DisplayProfile()
        {
            System.Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E");
            System.Console.WriteLine("Name:\t\t\tRegee Casaña");
            System.Console.WriteLine("Birthday:\t\tMay 7, 2002");
            System.Console.WriteLine("Course:\t\t\tBS of Computer Science Major in Software Development");
            System.Console.WriteLine("Year:\t\t\t2nd Year");
            System.Console.WriteLine("Section:\t\tSD2B");
            System.Console.ReadLine();
        }
    }
}
