﻿/* Creating classes in OOP
 * Group Members : Roiel A. Carlos
 *                 Angelo R. Diego
 *                 Marian Gillian G. Sarmiento
 * Date: April 25, 2022
 * This program will get first and last name user input then display it by calling multiple classes.
 * This program will also display the profiles of the group members.
 */

using System;

namespace ClassExample1A_Carlos_Diego_Sarmiento
{
    class ClassExample1A
    {
        static void Main(string[] args)
        {
            Accept1A a = new Accept1A();
            a.AcceptDetails();

            Print1A p = new Print1A();
            p.PrintDetails(a.name);

            MyProfile1A myp = new MyProfile1A();
            myp.DisplayProfile();
        }
    }
}
