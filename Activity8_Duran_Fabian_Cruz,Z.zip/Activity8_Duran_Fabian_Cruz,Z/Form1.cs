﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.Common;

namespace Activity8_Duran_Fabian_Cruz_Z
{
    public partial class Form1 : Form
    {
        //Declaration
        int id;
        private OleDbConnection bookConn;
        private OleDbCommand oleDbCmd = new OleDbCommand();
        

        private String connParam = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\HP\Downloads\book3.accdb";
        //private String connParam = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\HP\Downloads\book3.mdb";
        public Form1()
        {
            //Initialization
            bookConn = new OleDbConnection(connParam);
            InitializeComponent();
            button1_SAVE.Enabled = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'book3DataSet.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter.Fill(this.book3DataSet.bookrecords);

        }

        private void button1_ADD_Click(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbCmd.Connection = bookConn;
            oleDbCmd.CommandText = "Insert into bookrecords (booktitle, description, bookno)" + " " + " values('" + this.textBox1.Text + "','" 
                + this.textBox2.Text + "','" + this.textBox3.Text + "')";;
            int temp = oleDbCmd.ExecuteNonQuery();
            if (temp > 0)
            {
                textBox1.Text = null;
                textBox2.Text = null;
                textBox3.Text = null;
                MessageBox.Show("Record Successfully Added!");
            }
            else
            {
                MessageBox.Show("Failed to add the Record please try again.");
            }

            bookConn.Close();
        }

        private void button2_VIEW_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("SELECT * FROM bookrecords", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("UPDATE * FROM bookrecords", connParam);
            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0],
                    dataTable.Rows[i][1], dataTable.Rows[i][2], dataTable.Rows[i][3]);
            }
        }

        private void button1_DELETE_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this record?", "Delete Record", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                bookConn.Open();
                oleDbCmd.Connection = bookConn;
                oleDbCmd.CommandText = "DELETE FROM bookrecords WHERE ID = " + id;
                int temp = oleDbCmd.ExecuteNonQuery();
                if (temp > 0)
                {
                    id = 0;
                    textBox1.Text = null;
                    textBox2.Text = null;
                    textBox3.Text = null;
                    MessageBox.Show("Record successfully deleted");
                    MessageBox.Show("Press view all to see the current record list.");

                }
                else
                {
                    MessageBox.Show("Record failed to be deleted");
                }
                bookConn.Close();
            
            }
            
        }

        private void button1_SAVE_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("You want to save the changes made?", "Save Record", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                bookConn.Open();
                oleDbCmd.Connection = bookConn;
                oleDbCmd.CommandText = "Update bookrecords set booktitle ='" + this.textBox1.Text + "', description ='"
                    + this.textBox2.Text + "', bookno = '" + this.textBox3.Text + "' Where ID =" + id + "";
                int temp = oleDbCmd.ExecuteNonQuery();
                if (temp > 0)
                {
                    textBox1.Text = null;
                    textBox2.Text = null;
                    textBox3.Text = null;
                    MessageBox.Show("Record successfully updated");
                    MessageBox.Show("Press view all records to show updated list");
                    button1_SAVE.Enabled = true;

                }
                else
                {
                    MessageBox.Show("Record Failed to update");
                }
                bookConn.Close();
            }else
                textBox1.Text = null;
                textBox2.Text = null;
                textBox3.Text = null;
                button1_SAVE.Enabled = false;

        }
    
        

        private void button1_EDIT_Click(object sender, EventArgs e)
        {
            button1_SAVE.Enabled = true;
            int rowIndex = dataGridView1.CurrentCell.RowIndex;
            int columnindex = dataGridView1.CurrentCell.ColumnIndex;

            textBox1.Text = dataGridView1.Rows[rowIndex].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.Rows[rowIndex].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.Rows[rowIndex].Cells[3].Value.ToString();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            textBox1.Text = null;
            textBox2.Text = null;
            textBox3.Text = null;
            button1_SAVE.Enabled = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
