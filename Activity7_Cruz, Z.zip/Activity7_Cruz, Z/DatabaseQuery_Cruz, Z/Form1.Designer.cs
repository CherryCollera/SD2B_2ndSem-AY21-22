﻿
namespace DatabaseQuery_Cruz__Z
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cartmanCollegeDataSet = new DatabaseQuery_Cruz__Z.CartmanCollegeDataSet();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblStudentsTableAdapter = new DatabaseQuery_Cruz__Z.CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Btn_HighGPA = new System.Windows.Forms.Button();
            this.Btn_ShowRecords = new System.Windows.Forms.Button();
            this.Btn_ViewGradeStat = new System.Windows.Forms.Button();
            this.Btn_GroupRecordsGPA = new System.Windows.Forms.Button();
            this.listBox_HighGPA = new System.Windows.Forms.ListBox();
            this.listBox_MinGPA = new System.Windows.Forms.ListBox();
            this.listBox_GroupGPA = new System.Windows.Forms.ListBox();
            this.labelCount = new System.Windows.Forms.Label();
            this.labelMin = new System.Windows.Forms.Label();
            this.labelMax = new System.Windows.Forms.Label();
            this.labelAverage = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_MinGPA = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(543, 247);
            this.dataGridView1.TabIndex = 0;
            // 
            // cartmanCollegeDataSet
            // 
            this.cartmanCollegeDataSet.DataSetName = "CartmanCollegeDataSet";
            this.cartmanCollegeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            // 
            // Btn_HighGPA
            // 
            this.Btn_HighGPA.Location = new System.Drawing.Point(27, 269);
            this.Btn_HighGPA.Name = "Btn_HighGPA";
            this.Btn_HighGPA.Size = new System.Drawing.Size(188, 23);
            this.Btn_HighGPA.TabIndex = 1;
            this.Btn_HighGPA.Text = "Show Students with High GPA";
            this.Btn_HighGPA.UseVisualStyleBackColor = true;
            this.Btn_HighGPA.Click += new System.EventHandler(this.button1_Click);
            // 
            // Btn_ShowRecords
            // 
            this.Btn_ShowRecords.Location = new System.Drawing.Point(264, 290);
            this.Btn_ShowRecords.Name = "Btn_ShowRecords";
            this.Btn_ShowRecords.Size = new System.Drawing.Size(98, 23);
            this.Btn_ShowRecords.TabIndex = 2;
            this.Btn_ShowRecords.Text = "Show Records";
            this.Btn_ShowRecords.UseVisualStyleBackColor = true;
            this.Btn_ShowRecords.Click += new System.EventHandler(this.Btn_ShowRecords_Click);
            // 
            // Btn_ViewGradeStat
            // 
            this.Btn_ViewGradeStat.Location = new System.Drawing.Point(561, 12);
            this.Btn_ViewGradeStat.Name = "Btn_ViewGradeStat";
            this.Btn_ViewGradeStat.Size = new System.Drawing.Size(134, 23);
            this.Btn_ViewGradeStat.TabIndex = 3;
            this.Btn_ViewGradeStat.Text = "View Grade Statistics";
            this.Btn_ViewGradeStat.UseVisualStyleBackColor = true;
            this.Btn_ViewGradeStat.Click += new System.EventHandler(this.Btn_ViewGradeStat_Click);
            // 
            // Btn_GroupRecordsGPA
            // 
            this.Btn_GroupRecordsGPA.Location = new System.Drawing.Point(754, 12);
            this.Btn_GroupRecordsGPA.Name = "Btn_GroupRecordsGPA";
            this.Btn_GroupRecordsGPA.Size = new System.Drawing.Size(140, 23);
            this.Btn_GroupRecordsGPA.TabIndex = 4;
            this.Btn_GroupRecordsGPA.Text = "Group Records by GPA";
            this.Btn_GroupRecordsGPA.UseVisualStyleBackColor = true;
            this.Btn_GroupRecordsGPA.Click += new System.EventHandler(this.Btn_GroupRecordsGPA_Click);
            // 
            // listBox_HighGPA
            // 
            this.listBox_HighGPA.FormattingEnabled = true;
            this.listBox_HighGPA.Location = new System.Drawing.Point(27, 306);
            this.listBox_HighGPA.Name = "listBox_HighGPA";
            this.listBox_HighGPA.Size = new System.Drawing.Size(188, 121);
            this.listBox_HighGPA.TabIndex = 5;
            // 
            // listBox_MinGPA
            // 
            this.listBox_MinGPA.FormattingEnabled = true;
            this.listBox_MinGPA.Location = new System.Drawing.Point(264, 319);
            this.listBox_MinGPA.Name = "listBox_MinGPA";
            this.listBox_MinGPA.Size = new System.Drawing.Size(214, 108);
            this.listBox_MinGPA.TabIndex = 6;
            // 
            // listBox_GroupGPA
            // 
            this.listBox_GroupGPA.FormattingEnabled = true;
            this.listBox_GroupGPA.Location = new System.Drawing.Point(754, 41);
            this.listBox_GroupGPA.Name = "listBox_GroupGPA";
            this.listBox_GroupGPA.Size = new System.Drawing.Size(140, 251);
            this.listBox_GroupGPA.TabIndex = 7;
            // 
            // labelCount
            // 
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new System.Drawing.Point(572, 52);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new System.Drawing.Size(35, 13);
            this.labelCount.TabIndex = 8;
            this.labelCount.Text = "label1";
            // 
            // labelMin
            // 
            this.labelMin.AutoSize = true;
            this.labelMin.Location = new System.Drawing.Point(572, 80);
            this.labelMin.Name = "labelMin";
            this.labelMin.Size = new System.Drawing.Size(35, 13);
            this.labelMin.TabIndex = 9;
            this.labelMin.Text = "label2";
            // 
            // labelMax
            // 
            this.labelMax.AutoSize = true;
            this.labelMax.Location = new System.Drawing.Point(572, 107);
            this.labelMax.Name = "labelMax";
            this.labelMax.Size = new System.Drawing.Size(35, 13);
            this.labelMax.TabIndex = 10;
            this.labelMax.Text = "label3";
            // 
            // labelAverage
            // 
            this.labelAverage.AutoSize = true;
            this.labelAverage.Location = new System.Drawing.Point(572, 138);
            this.labelAverage.Name = "labelAverage";
            this.labelAverage.Size = new System.Drawing.Size(35, 13);
            this.labelAverage.TabIndex = 11;
            this.labelAverage.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(261, 269);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Enter minimum GPA:";
            // 
            // textBox_MinGPA
            // 
            this.textBox_MinGPA.Location = new System.Drawing.Point(370, 266);
            this.textBox_MinGPA.Name = "textBox_MinGPA";
            this.textBox_MinGPA.Size = new System.Drawing.Size(100, 20);
            this.textBox_MinGPA.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(906, 450);
            this.Controls.Add(this.textBox_MinGPA);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labelAverage);
            this.Controls.Add(this.labelMax);
            this.Controls.Add(this.labelMin);
            this.Controls.Add(this.labelCount);
            this.Controls.Add(this.listBox_GroupGPA);
            this.Controls.Add(this.listBox_MinGPA);
            this.Controls.Add(this.listBox_HighGPA);
            this.Controls.Add(this.Btn_GroupRecordsGPA);
            this.Controls.Add(this.Btn_ViewGradeStat);
            this.Controls.Add(this.Btn_ShowRecords);
            this.Controls.Add(this.Btn_HighGPA);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CartmanCollegeDataSet cartmanCollegeDataSet;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button Btn_HighGPA;
        private System.Windows.Forms.Button Btn_ShowRecords;
        private System.Windows.Forms.Button Btn_ViewGradeStat;
        private System.Windows.Forms.Button Btn_GroupRecordsGPA;
        private System.Windows.Forms.ListBox listBox_HighGPA;
        private System.Windows.Forms.ListBox listBox_MinGPA;
        private System.Windows.Forms.ListBox listBox_GroupGPA;
        private System.Windows.Forms.Label labelCount;
        private System.Windows.Forms.Label labelMin;
        private System.Windows.Forms.Label labelMax;
        private System.Windows.Forms.Label labelAverage;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_MinGPA;
    }
}

