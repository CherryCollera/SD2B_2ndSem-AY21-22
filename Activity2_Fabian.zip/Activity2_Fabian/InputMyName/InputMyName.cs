﻿/*20-03361
Adrian D. Fabian
SD2B
April 7, 2022
This program will let you input your name*/

using System;


namespace InputMyName_Fabian
{
    class InputMyName_Fabian
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your name (fname)(lname): ");

            string Name = Console.ReadLine();

            Console.WriteLine("Hello! " + Name + "\n Welcome to OOP environment.");

            Console.ReadLine();
        }
    }
}