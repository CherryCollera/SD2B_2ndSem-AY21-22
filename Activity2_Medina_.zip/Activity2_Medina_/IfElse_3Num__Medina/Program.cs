﻿
/*  20-01732
    Angelica D. Medina

    BSCSSD-2B
    April 07, 2022

This program will display the example of if-else with 3 input numbers.
*/

using System;

namespace IfElse_3Num__Medina
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;

            System.Console.Write("Enter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            System.Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            System.Console.Write("Enter Third Number: ");
            num3 = Convert.ToInt32(Console.ReadLine());

            System.Console.WriteLine("");

            if (num1 > num2 && num1 > num3) { Console.Write("\n{0} is Greater than {1} and {2}", num1, num2, num3); }
            else if (num2 > num3) { Console.Write("\n{1} is Greater than {0} and {2}", num1, num2, num3); }
            else { Console.Write("\n{2} is Greater than {0} and {1}", num1, num2, num3); }

            System.Console.WriteLine("");

            System.Console.ReadKey();
        }
    }
}
