﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample2_Manansala_Francisco_Cruz
{
    class Declare
    {
        private static string color;
        public static String Color
        {
            get
            { return color; }
            set
            { color = value; }
        }
    }
}
