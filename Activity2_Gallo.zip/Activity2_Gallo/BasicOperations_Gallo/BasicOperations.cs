﻿/*
 20-01076
Noel M. Gallo Jr.
SD2B
April 7, 2022
This program will Compute using basic operations
 */
using System;

namespace ComputeTheSum
{

    class ComputeTheSum
    {

        public static void Main(string[] args)
        {
            System.Console.Write("Enter 1st number: ");
            int num1 = Convert.ToInt16(Console.ReadLine());
            System.Console.Write("Enter 2nd number: ");
            int num2 = Convert.ToInt16(Console.ReadLine());

            System.Console.WriteLine("\nSum = {0}.\nDifference = {1}.\nProduct = {2}." +
                "\nQuotient = {3}.\nRemainder = {4}.", (num1 + num2),
                (num1 - num2), (num1 * num2), (num1 / num2), (num1 % num2));
            System.Console.ReadKey();
        }

    }
}
