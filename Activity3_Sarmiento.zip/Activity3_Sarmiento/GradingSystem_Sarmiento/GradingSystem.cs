﻿/*20-00613
Marian Gillian G. Sarmiento
SD2B
April 19, 2022
This program will ask you to input your final grade and it will show your grade equivalent and remarks*/

using System;

namespace GradingSystem_Sarmiento
{
    class GradingSystem
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your final grade  :   ");
            string grades = Console.ReadLine();

            if (grades.ToLower() != "inc")
            {
                int grade = Convert.ToInt32(grades);

                if (grade >= 98 && grade <= 100)
                {
                    Console.WriteLine("Grade Equivalent    :   1.00");
                    Console.WriteLine("Remarks          :   Excellent");
                    Console.ReadLine();
                }
                else if (grade >= 95 && grade <= 97)
                {
                    Console.WriteLine("Grade Equivalent    :   1.25");
                    Console.WriteLine("Remarks          :   Excellent");
                    Console.ReadLine();
                }
                else if (grade >= 92 && grade <= 94)
                {
                    Console.WriteLine("Grade Equivalent    :   1.50");
                    Console.WriteLine("Remarks          :   Very Good");
                    Console.ReadLine();
                }
                else if (grade >= 89 && grade <= 91)
                {
                    Console.WriteLine("Grade Equivalent    :   1.75");
                    Console.WriteLine("Remarks          :   Very Good");
                    Console.ReadLine();
                }
                else if (grade >= 86 && grade <= 88)
                {
                    Console.WriteLine("Grade Equivalent    :   2.00");
                    Console.WriteLine("Remarks          :   Good");
                    Console.ReadLine();
                }
                else if (grade >= 83 && grade <= 85)
                {
                    Console.WriteLine("Grade Equivalent    :   2.25");
                    Console.WriteLine("Remarks          :   Good");
                    Console.ReadLine();
                }
                else if (grade >= 80 && grade <= 82)
                {
                    Console.WriteLine("Grade Equivalent    :   2.50");
                    Console.WriteLine("Remarks          :   Fair");
                    Console.ReadLine();
                }
                else if (grade >= 77 && grade <= 79)
                {
                    Console.WriteLine("Grade Equivalent    :   2.75");
                    Console.WriteLine("Remarks          :   Passed");
                    Console.ReadLine();
                }
                else if (grade >= 75 && grade <= 76)
                {
                    Console.WriteLine("Grade Equivalent    :   3.00");
                    Console.WriteLine("Remarks          :   Passed");
                    Console.ReadLine();
                }
                else if (grade >= 72 && grade <= 74)
                {
                    Console.WriteLine("Grade Equivalent    :   4.00");
                    Console.WriteLine("Remarks          :   Conditional");
                    Console.ReadLine();
                }
                else if (grade >= 60 && grade <= 71)
                {
                    Console.WriteLine("Grade Equivalent    :   5.00");
                    Console.WriteLine("Remarks          :   Failed");
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("INVALID");
                    Console.ReadLine();
                }
            }
            else
            {
                Console.WriteLine("Grade Equivalent :   INCOMPLETE");
                Console.WriteLine("Remarks          :   INCOMPLETE");
                Console.ReadLine();
            }
        }
    }
}
