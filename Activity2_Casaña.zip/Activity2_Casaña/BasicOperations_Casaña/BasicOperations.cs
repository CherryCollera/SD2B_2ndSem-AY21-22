﻿//This Program will show the basic operations
using System;

namespace BasicOperations_Casaña
{
    class BasicOperations
    {
        static void Main(string[] args)
        {
            //Declare variables
            int num1, num2;

            //Input First and Second Number
            Console.Write("\nEnter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            //Display the sum
            Console.Write("\nSum = {0}. ", num1 + num2);
            //Display the difference
            Console.Write("\nDifference = {0}. ", num1 - num2);
            //Display the Product
            Console.Write("\nProduct = {0}. ", num1 * num2);
            //Display the Qoutient
            Console.Write("\nQoutient = {0}. ", num1 / num2);
            //Display the remainder
            Console.Write("\nRemainder = {0}. ", num1 % num2);
            Console.ReadLine();
        }
    }
}
