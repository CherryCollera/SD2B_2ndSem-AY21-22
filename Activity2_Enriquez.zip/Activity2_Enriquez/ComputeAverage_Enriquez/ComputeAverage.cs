﻿/* 20 - 01484
 John Brix B. Enriquez
 SD2B
 April 5, 2022
 This program will compute the average of 5 numbers*/

using System;
namespace ComputeAverage
{
    class ComputeAverage
    {
        static void Main(string[] args)
        {
            double num1,num2,num3,num4,num5, total;
            Console.WriteLine("Enter 5 grades: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            num2 = Convert.ToInt32(Console.ReadLine());
            num3 = Convert.ToInt32(Console.ReadLine());
            num4 = Convert.ToInt32(Console.ReadLine());
            num5 = Convert.ToInt32(Console.ReadLine());
            double average = (num1 + num2 + num3 + num4 + num5) / 5;   
            Console.WriteLine("The average is {0:.000}.", average);
            Console.ReadKey();

        }
    }
}