class Quotient{
    public void computeQuotient(){
        DeclareVar.quotient = DeclareVar.num1 / DeclareVar.num2;
    }
}