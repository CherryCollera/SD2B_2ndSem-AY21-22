﻿/*20-00613
Marian Gillian G. Sarmiento
SD2B
April 5, 2022
This program will compute for the sum, difference, product, quotient and remainder of 2 integer values*/

using System;

namespace BasicOperations_Sarmiento
{
    class BasicOperations
    {
        static void Main(string[] args)
        {

            int num1, num2;
            Console.Write("\nEnter the first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\nSum = {0}.", num1 + num2);
            Console.WriteLine("Difference = {0}.", num1 - num2);
            Console.WriteLine("Product = {0}.", num1 * num2);
            Console.WriteLine("Quotient = {0}.", num1 / num2);
            Console.WriteLine("Remainder = {0}.", num1 % num2);
            Console.ReadLine();
        }
    }
}
