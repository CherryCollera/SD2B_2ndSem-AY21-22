﻿/*
 * 20-00382
 * Roiel A. Carlos
 * SD2B
 * April 18, 2022
 * This program will show how a while loop is performed
 */
using System;

namespace While_Carlos
{
    class While
    {
        static void Main(string[] args)
        {
            int i = 0;
            while (i < 10)
            {
                Console.Write("While statement ");
                Console.WriteLine(i);
                i++;
            }
            Console.ReadKey();
        }
    }
}
