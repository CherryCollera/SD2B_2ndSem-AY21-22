﻿/*
 * 20-00382
 * Roiel A. Carlos
 * SD2B
 * March 27, 2022
 * This program will display my details; specifically my name, date of birth, course, year, and section
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample2_MyProfile
{
    internal class roielcarlos
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine();
            System.Console.WriteLine("Name: Roiel A. Carlos");
            System.Console.WriteLine();
            System.Console.WriteLine("Date of Birth: December 3 2001");
            System.Console.WriteLine();
            System.Console.WriteLine("Course: BS Computer Science Major in Software Development");
            System.Console.WriteLine();
            System.Console.WriteLine("Year: II");
            System.Console.WriteLine();
            System.Console.WriteLine("Section: SD2B");
            System.Console.ReadKey();
        }
    }
}
