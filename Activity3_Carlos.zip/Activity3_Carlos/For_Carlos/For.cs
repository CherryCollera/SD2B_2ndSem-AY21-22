﻿/*
 * 20-00382
 * Roiel A. Carlos
 * SD2B
 * April 18, 2022
 * This program will show how a for loop is performed.
 */
using System;

namespace For_Carlos
{
    class For
    {
        static void Main(string[] args)
        {
            for (int i = 10 - 1; i >= 0; i--)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
