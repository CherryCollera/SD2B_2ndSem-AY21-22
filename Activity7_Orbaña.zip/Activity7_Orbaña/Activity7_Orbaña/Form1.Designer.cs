﻿
namespace Activity7_Orbaña
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cartmanCollegeDataSet = new Activity7_Orbaña.CartmanCollegeDataSet();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblStudentsTableAdapter = new Activity7_Orbaña.CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_HighGPA = new System.Windows.Forms.Button();
            this.listBox_HighGPA = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_MinGPA = new System.Windows.Forms.TextBox();
            this.btn_ShowRecords = new System.Windows.Forms.Button();
            this.listBox_MinGPA = new System.Windows.Forms.ListBox();
            this.btn_GradeStatistics = new System.Windows.Forms.Button();
            this.labelCount = new System.Windows.Forms.Label();
            this.labelMin = new System.Windows.Forms.Label();
            this.labelMax = new System.Windows.Forms.Label();
            this.labelAverage = new System.Windows.Forms.Label();
            this.btn_GroupGPA = new System.Windows.Forms.Button();
            this.listBox_GroupGPA = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 49;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(550, 245);
            this.dataGridView1.TabIndex = 0;
            // 
            // cartmanCollegeDataSet
            // 
            this.cartmanCollegeDataSet.DataSetName = "CartmanCollegeDataSet";
            this.cartmanCollegeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.Width = 120;
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            this.lastNameDataGridViewTextBoxColumn.Width = 120;
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            this.firstNameDataGridViewTextBoxColumn.Width = 120;
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            this.gradePointAverageDataGridViewTextBoxColumn.Width = 120;
            // 
            // btn_HighGPA
            // 
            this.btn_HighGPA.Location = new System.Drawing.Point(12, 272);
            this.btn_HighGPA.Name = "btn_HighGPA";
            this.btn_HighGPA.Size = new System.Drawing.Size(234, 23);
            this.btn_HighGPA.TabIndex = 1;
            this.btn_HighGPA.Text = "Show Students with High GPA";
            this.btn_HighGPA.UseVisualStyleBackColor = true;
            this.btn_HighGPA.Click += new System.EventHandler(this.btn_HighGPA_Click);
            // 
            // listBox_HighGPA
            // 
            this.listBox_HighGPA.FormattingEnabled = true;
            this.listBox_HighGPA.ItemHeight = 16;
            this.listBox_HighGPA.Location = new System.Drawing.Point(12, 343);
            this.listBox_HighGPA.Name = "listBox_HighGPA";
            this.listBox_HighGPA.Size = new System.Drawing.Size(179, 164);
            this.listBox_HighGPA.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(303, 275);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Enter minimum GPA:";
            // 
            // txt_MinGPA
            // 
            this.txt_MinGPA.Location = new System.Drawing.Point(462, 272);
            this.txt_MinGPA.Name = "txt_MinGPA";
            this.txt_MinGPA.Size = new System.Drawing.Size(100, 22);
            this.txt_MinGPA.TabIndex = 4;
            this.txt_MinGPA.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btn_ShowRecords
            // 
            this.btn_ShowRecords.Location = new System.Drawing.Point(306, 306);
            this.btn_ShowRecords.Name = "btn_ShowRecords";
            this.btn_ShowRecords.Size = new System.Drawing.Size(135, 23);
            this.btn_ShowRecords.TabIndex = 5;
            this.btn_ShowRecords.Text = "Show Records";
            this.btn_ShowRecords.UseVisualStyleBackColor = true;
            this.btn_ShowRecords.Click += new System.EventHandler(this.btn_ShowRecords_Click);
            // 
            // listBox_MinGPA
            // 
            this.listBox_MinGPA.FormattingEnabled = true;
            this.listBox_MinGPA.ItemHeight = 16;
            this.listBox_MinGPA.Location = new System.Drawing.Point(306, 343);
            this.listBox_MinGPA.Name = "listBox_MinGPA";
            this.listBox_MinGPA.Size = new System.Drawing.Size(189, 164);
            this.listBox_MinGPA.TabIndex = 6;
            // 
            // btn_GradeStatistics
            // 
            this.btn_GradeStatistics.Location = new System.Drawing.Point(583, 12);
            this.btn_GradeStatistics.Name = "btn_GradeStatistics";
            this.btn_GradeStatistics.Size = new System.Drawing.Size(170, 23);
            this.btn_GradeStatistics.TabIndex = 7;
            this.btn_GradeStatistics.Text = "View Grades Statistics";
            this.btn_GradeStatistics.UseVisualStyleBackColor = true;
            this.btn_GradeStatistics.Click += new System.EventHandler(this.btn_GradeStatistics_Click);
            // 
            // labelCount
            // 
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new System.Drawing.Point(580, 53);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new System.Drawing.Size(46, 17);
            this.labelCount.TabIndex = 8;
            this.labelCount.Text = "label2";
            // 
            // labelMin
            // 
            this.labelMin.AutoSize = true;
            this.labelMin.Location = new System.Drawing.Point(580, 106);
            this.labelMin.Name = "labelMin";
            this.labelMin.Size = new System.Drawing.Size(46, 17);
            this.labelMin.TabIndex = 9;
            this.labelMin.Text = "label2";
            // 
            // labelMax
            // 
            this.labelMax.AutoSize = true;
            this.labelMax.Location = new System.Drawing.Point(580, 159);
            this.labelMax.Name = "labelMax";
            this.labelMax.Size = new System.Drawing.Size(46, 17);
            this.labelMax.TabIndex = 10;
            this.labelMax.Text = "label2";
            // 
            // labelAverage
            // 
            this.labelAverage.AutoSize = true;
            this.labelAverage.Location = new System.Drawing.Point(580, 214);
            this.labelAverage.Name = "labelAverage";
            this.labelAverage.Size = new System.Drawing.Size(46, 17);
            this.labelAverage.TabIndex = 11;
            this.labelAverage.Text = "label2";
            // 
            // btn_GroupGPA
            // 
            this.btn_GroupGPA.Location = new System.Drawing.Point(785, 12);
            this.btn_GroupGPA.Name = "btn_GroupGPA";
            this.btn_GroupGPA.Size = new System.Drawing.Size(205, 23);
            this.btn_GroupGPA.TabIndex = 12;
            this.btn_GroupGPA.Text = "Group Records by GPA";
            this.btn_GroupGPA.UseVisualStyleBackColor = true;
            this.btn_GroupGPA.Click += new System.EventHandler(this.btn_GroupGPA_Click);
            // 
            // listBox_GroupGPA
            // 
            this.listBox_GroupGPA.FormattingEnabled = true;
            this.listBox_GroupGPA.ItemHeight = 16;
            this.listBox_GroupGPA.Location = new System.Drawing.Point(785, 53);
            this.listBox_GroupGPA.Name = "listBox_GroupGPA";
            this.listBox_GroupGPA.Size = new System.Drawing.Size(205, 212);
            this.listBox_GroupGPA.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1002, 544);
            this.Controls.Add(this.listBox_GroupGPA);
            this.Controls.Add(this.btn_GroupGPA);
            this.Controls.Add(this.labelAverage);
            this.Controls.Add(this.labelMax);
            this.Controls.Add(this.labelMin);
            this.Controls.Add(this.labelCount);
            this.Controls.Add(this.btn_GradeStatistics);
            this.Controls.Add(this.listBox_MinGPA);
            this.Controls.Add(this.btn_ShowRecords);
            this.Controls.Add(this.txt_MinGPA);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox_HighGPA);
            this.Controls.Add(this.btn_HighGPA);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Database Query Orbaña";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CartmanCollegeDataSet cartmanCollegeDataSet;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btn_HighGPA;
        private System.Windows.Forms.ListBox listBox_HighGPA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_MinGPA;
        private System.Windows.Forms.Button btn_ShowRecords;
        private System.Windows.Forms.ListBox listBox_MinGPA;
        private System.Windows.Forms.Button btn_GradeStatistics;
        private System.Windows.Forms.Label labelCount;
        private System.Windows.Forms.Label labelMin;
        private System.Windows.Forms.Label labelMax;
        private System.Windows.Forms.Label labelAverage;
        private System.Windows.Forms.Button btn_GroupGPA;
        private System.Windows.Forms.ListBox listBox_GroupGPA;
    }
}

