﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1A_Carlos_Diego_Sarmiento
{
    class Print1A
    {
        public void PrintDetails(string name)
        {
            System.Console.Write("Hello " + name
                + "\nYou have created classes in OOP");
        }
    }
}
