﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 14, 2022
 *  Program: Displays the input name by the user
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Sample3_InputMyName
    {
        internal class Program
            {
                static void Main(string[] args)
                    {
                        Console.WriteLine("Enter your name [FN LN]:  ");
                        string name = Console.ReadLine();


                        Console.WriteLine("\n\nHello " + name + "!");
                        Console.WriteLine("Welcome to OOP environment.");
                        Console.ReadKey();
                    }
            }
    }
