﻿/* 20 - 01484
 John Brix B. Enriquez
 SD2B
 April 17, 2022
 This program will display equivalent of remarks of grade*/

using System;
namespace GradingSystem
{
    class GradingSystem
    {
        static void Main(string[] args)
        {
            int finalGrade;
            Console.Write("Enter your final grade: ");
            finalGrade = Convert.ToInt32(Console.ReadLine());
            if (finalGrade >= 98 && finalGrade < 101)
            {
                Console.WriteLine("Grade Equivalent: 1.00");
                Console.WriteLine("Remarks: Excellent");
            }
            else if (finalGrade >= 95 && finalGrade < 98)
            {
                Console.WriteLine("Grade Equivalent: 1.25");
                Console.WriteLine("Remarks: Very Good");
            }
            else if (finalGrade >= 92 && finalGrade < 95)
            {
                Console.WriteLine("Grade Equivalent: 1.50");
                Console.WriteLine("Remarks: Very Good");
            }
            else if (finalGrade >= 89 && finalGrade < 92)
            {
                Console.WriteLine("Grade Equivalent: 1.75");
                Console.WriteLine("Remarks: Very Good");
            }
            else if (finalGrade >= 86 && finalGrade < 89)
            {
                Console.WriteLine("Grade Equivalent: 2.00");
                Console.WriteLine("Remarks: Good");
            }
            else if (finalGrade >= 83 && finalGrade < 86)
            {
                Console.WriteLine("Grade Equivalent: 2.25");
                Console.WriteLine("Remarks: Good");
            }
            else if (finalGrade >= 80 && finalGrade < 83)
            {
                Console.WriteLine("Grade Equivalent: 2.50");
                Console.WriteLine("Remarks: Fair");
            }
            else if (finalGrade >= 77 && finalGrade < 80)
            {
                Console.WriteLine("Grade Equivalent: 2.75");
                Console.WriteLine("Remarks: Passed");
            }
            else if (finalGrade >= 75 && finalGrade < 77)
            {
                Console.WriteLine("Grade Equivalent: 3.00");
                Console.WriteLine("Remarks: Passed");
            }
            else if (finalGrade >= 72 && finalGrade < 75)
            {
                Console.WriteLine("Grade Equivalent: 4.00");
                Console.WriteLine("Remarks: Conditional (MT only)");
            }
            else if (finalGrade >= 60 && finalGrade < 72)
            {
                Console.WriteLine("Grade Equivalent: 5.00");
                Console.WriteLine("Remarks: Failed");
            }
            else
            {
                Console.WriteLine("Grade Equivalent: Inc");
                Console.WriteLine("Remark: Incomplete");
            }
            Console.ReadKey();
        }
    }
}