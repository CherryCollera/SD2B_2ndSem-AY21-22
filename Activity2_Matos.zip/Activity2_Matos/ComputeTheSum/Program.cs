﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 15, 2022
 *  Display the sum of two given numbers
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ComputeTheSum
    {
        internal class Program
            {
                static void Main(string[] args)
                    {
                        Console.WriteLine("Enter first number:   ");
                        int num1 = int.Parse(Console.ReadLine());           // Read and store input in an int data type

                        Console.WriteLine("Enter first number:   ");
                        int num2 = int.Parse(Console.ReadLine());           // Read and store input in an int data type

                        
                        // Calculate the two given numbers using addition (+)
                        int sum = num1 + num2;


                        // Display 
                        Console.WriteLine("\n\n" + num1 + " + " + num2 + " = " + sum);
                        Console.ReadKey();
                    }
            }
    }
