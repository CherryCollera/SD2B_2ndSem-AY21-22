﻿/*20-00613
Marian Gillian G. Sarmiento
SD2B
April 19, 2022
This program will show how a for loop is performed*/

using System;

namespace For_Sarmiento
{
    class For
    {
        static void Main(string[] args)
        {
            for (int i = 10 - 1; i >= 0; i--)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
