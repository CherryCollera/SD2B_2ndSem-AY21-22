﻿/*
 * student Id number : 20-05258
 * student full name : Zedrick A. Mojica
 * Section : BSCS-SD2B
 * Date : 17/04/2022
 * Purpose : Switch loop
 */
using System;

namespace While_Mojica
{
    class While
    {
        static void Main(string[] args)
        {
            int i = 0;
            //loop until i is greater than 10
            while (i < 10)
            {
                Console.Write("While Statement ");
                Console.WriteLine(i);
                i++;
            }
            Console.ReadLine();
        }
    }
}
