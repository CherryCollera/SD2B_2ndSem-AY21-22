﻿/*
 * Group number: 2
 * Group Members: Gallo, Noel Jr. 
                  Mojica, Zedrick
                  Enriquez, John Brix
 * Section : BSCS-SD2B
 * Date : 26/04/2022
 * Purpose : using methods to print car colors
 */
using System;

namespace ClassExample2_Gallo_Mojica_Enriquez
{
    class Program
    {
        static void Main(string[] args)
        {

            Car car;
            car = new Car("Red");
            Console.WriteLine(car.Describe());
            car = new Car("Green");
            Console.WriteLine(car.Describe());
            Console.ReadLine();
        }
    }
}
