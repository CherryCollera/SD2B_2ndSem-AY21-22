﻿/*
 * 20-00382
 * Roiel A. Carlos
 * SD2B
 * April 7, 2022
 * This program will get the average of 5 numbers.
 */

using System;

namespace ComputeAverage_Carlos
{
    class ComputeAverage
    {
        static void Main(string[] args)
        {
            double grade1, grade2, grade3, grade4, grade5;
            Console.WriteLine("Enter 5 Grades:");

            //read 5 grades
            grade1 = Convert.ToDouble(Console.ReadLine());
            grade2 = Convert.ToDouble(Console.ReadLine());
            grade3 = Convert.ToDouble(Console.ReadLine());
            grade4 = Convert.ToDouble(Console.ReadLine());
            grade5 = Convert.ToDouble(Console.ReadLine());

            //compute the average
            double avg = ((grade1 + grade2 + grade3 + grade4 + grade5)/5);

            //print average with 3 decimal places.
            Console.WriteLine("The average is {0:0.000}.", avg);
            Console.ReadKey();
        }
    }
}
 