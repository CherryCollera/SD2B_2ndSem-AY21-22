﻿
namespace DatabaseQuery_Medina
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.cartmanCollegeDataSet1 = new DatabaseQuery_Medina.CartmanCollegeDataSet1();
            this.cartmanCollegeDataSet = new DatabaseQuery_Medina.CartmanCollegeDataSet();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblStudentsTableAdapter = new DatabaseQuery_Medina.CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter();
            this.tblStudentsTableAdapter1 = new DatabaseQuery_Medina.CartmanCollegeDataSet1TableAdapters.tblStudentsTableAdapter();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbl_Average = new System.Windows.Forms.Label();
            this.lbl_Max = new System.Windows.Forms.Label();
            this.lbl_Min = new System.Windows.Forms.Label();
            this.lbl_Count = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_ViewGradeStat = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.listBox_GroupGPA = new System.Windows.Forms.ListBox();
            this.btn_GroupRecordsGPA = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.listBox_HighGPA = new System.Windows.Forms.ListBox();
            this.btn_HighGpa = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.listBox_MinGPA = new System.Windows.Forms.ListBox();
            this.btn_ShowRecords = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_MinGPA = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.PowderBlue;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentsBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(4, 11);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(565, 214);
            this.dataGridView1.TabIndex = 0;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            // 
            // tblStudentsBindingSource1
            // 
            this.tblStudentsBindingSource1.DataMember = "tblStudents";
            this.tblStudentsBindingSource1.DataSource = this.cartmanCollegeDataSet1;
            // 
            // cartmanCollegeDataSet1
            // 
            this.cartmanCollegeDataSet1.DataSetName = "CartmanCollegeDataSet1";
            this.cartmanCollegeDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cartmanCollegeDataSet
            // 
            this.cartmanCollegeDataSet.DataSetName = "CartmanCollegeDataSet";
            this.cartmanCollegeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // tblStudentsTableAdapter1
            // 
            this.tblStudentsTableAdapter1.ClearBeforeFill = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(22, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(574, 239);
            this.panel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.btn_ViewGradeStat);
            this.panel2.Location = new System.Drawing.Point(619, 22);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(260, 615);
            this.panel2.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.PowderBlue;
            this.panel4.Controls.Add(this.lbl_Average);
            this.panel4.Controls.Add(this.lbl_Max);
            this.panel4.Controls.Add(this.lbl_Min);
            this.panel4.Controls.Add(this.lbl_Count);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Location = new System.Drawing.Point(4, 78);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(253, 511);
            this.panel4.TabIndex = 1;
            // 
            // lbl_Average
            // 
            this.lbl_Average.AutoSize = true;
            this.lbl_Average.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Average.Location = new System.Drawing.Point(20, 200);
            this.lbl_Average.Name = "lbl_Average";
            this.lbl_Average.Size = new System.Drawing.Size(83, 28);
            this.lbl_Average.TabIndex = 1;
            this.lbl_Average.Text = "*Average";
            // 
            // lbl_Max
            // 
            this.lbl_Max.AutoSize = true;
            this.lbl_Max.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Max.Location = new System.Drawing.Point(20, 145);
            this.lbl_Max.Name = "lbl_Max";
            this.lbl_Max.Size = new System.Drawing.Size(80, 28);
            this.lbl_Max.TabIndex = 1;
            this.lbl_Max.Text = "*Highest";
            // 
            // lbl_Min
            // 
            this.lbl_Min.AutoSize = true;
            this.lbl_Min.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Min.Location = new System.Drawing.Point(20, 95);
            this.lbl_Min.Name = "lbl_Min";
            this.lbl_Min.Size = new System.Drawing.Size(76, 28);
            this.lbl_Min.TabIndex = 1;
            this.lbl_Min.Text = "*Lowest";
            // 
            // lbl_Count
            // 
            this.lbl_Count.AutoSize = true;
            this.lbl_Count.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Count.Location = new System.Drawing.Point(20, 48);
            this.lbl_Count.Name = "lbl_Count";
            this.lbl_Count.Size = new System.Drawing.Size(69, 28);
            this.lbl_Count.TabIndex = 1;
            this.lbl_Count.Text = "*Count";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Kristen ITC", 11.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 22);
            this.label1.TabIndex = 0;
            // 
            // btn_ViewGradeStat
            // 
            this.btn_ViewGradeStat.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btn_ViewGradeStat.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ViewGradeStat.Location = new System.Drawing.Point(4, 11);
            this.btn_ViewGradeStat.Name = "btn_ViewGradeStat";
            this.btn_ViewGradeStat.Size = new System.Drawing.Size(253, 60);
            this.btn_ViewGradeStat.TabIndex = 0;
            this.btn_ViewGradeStat.Text = "VIEW GRADE STATISTICS";
            this.btn_ViewGradeStat.UseVisualStyleBackColor = false;
            this.btn_ViewGradeStat.Click += new System.EventHandler(this.btn_ViewGradeStat_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel3.Controls.Add(this.listBox_GroupGPA);
            this.panel3.Controls.Add(this.btn_GroupRecordsGPA);
            this.panel3.Location = new System.Drawing.Point(885, 22);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(260, 615);
            this.panel3.TabIndex = 3;
            // 
            // listBox_GroupGPA
            // 
            this.listBox_GroupGPA.BackColor = System.Drawing.Color.PowderBlue;
            this.listBox_GroupGPA.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox_GroupGPA.FormattingEnabled = true;
            this.listBox_GroupGPA.ItemHeight = 28;
            this.listBox_GroupGPA.Location = new System.Drawing.Point(4, 81);
            this.listBox_GroupGPA.Name = "listBox_GroupGPA";
            this.listBox_GroupGPA.Size = new System.Drawing.Size(253, 508);
            this.listBox_GroupGPA.TabIndex = 1;
            // 
            // btn_GroupRecordsGPA
            // 
            this.btn_GroupRecordsGPA.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btn_GroupRecordsGPA.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_GroupRecordsGPA.Location = new System.Drawing.Point(4, 11);
            this.btn_GroupRecordsGPA.Name = "btn_GroupRecordsGPA";
            this.btn_GroupRecordsGPA.Size = new System.Drawing.Size(253, 60);
            this.btn_GroupRecordsGPA.TabIndex = 0;
            this.btn_GroupRecordsGPA.Text = "GROUP RECORDS BY GPA";
            this.btn_GroupRecordsGPA.UseVisualStyleBackColor = false;
            this.btn_GroupRecordsGPA.Click += new System.EventHandler(this.btn_GroupRecordsGPA_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel5.Controls.Add(this.listBox_HighGPA);
            this.panel5.Controls.Add(this.btn_HighGpa);
            this.panel5.Location = new System.Drawing.Point(22, 326);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(266, 311);
            this.panel5.TabIndex = 4;
            // 
            // listBox_HighGPA
            // 
            this.listBox_HighGPA.BackColor = System.Drawing.Color.PowderBlue;
            this.listBox_HighGPA.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox_HighGPA.FormattingEnabled = true;
            this.listBox_HighGPA.ItemHeight = 28;
            this.listBox_HighGPA.Location = new System.Drawing.Point(7, 70);
            this.listBox_HighGPA.Name = "listBox_HighGPA";
            this.listBox_HighGPA.Size = new System.Drawing.Size(252, 200);
            this.listBox_HighGPA.TabIndex = 1;
            // 
            // btn_HighGpa
            // 
            this.btn_HighGpa.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btn_HighGpa.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HighGpa.Location = new System.Drawing.Point(6, 4);
            this.btn_HighGpa.Name = "btn_HighGpa";
            this.btn_HighGpa.Size = new System.Drawing.Size(253, 60);
            this.btn_HighGpa.TabIndex = 0;
            this.btn_HighGpa.Text = "SHOW STUDENTS WITH HIGH GPA";
            this.btn_HighGpa.UseVisualStyleBackColor = false;
            this.btn_HighGpa.Click += new System.EventHandler(this.btn_HighGpa_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel6.Controls.Add(this.listBox_MinGPA);
            this.panel6.Controls.Add(this.btn_ShowRecords);
            this.panel6.Location = new System.Drawing.Point(330, 326);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(266, 311);
            this.panel6.TabIndex = 5;
            // 
            // listBox_MinGPA
            // 
            this.listBox_MinGPA.BackColor = System.Drawing.Color.PowderBlue;
            this.listBox_MinGPA.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox_MinGPA.FormattingEnabled = true;
            this.listBox_MinGPA.ItemHeight = 28;
            this.listBox_MinGPA.Location = new System.Drawing.Point(6, 70);
            this.listBox_MinGPA.Name = "listBox_MinGPA";
            this.listBox_MinGPA.Size = new System.Drawing.Size(252, 200);
            this.listBox_MinGPA.TabIndex = 1;
            // 
            // btn_ShowRecords
            // 
            this.btn_ShowRecords.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btn_ShowRecords.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ShowRecords.Location = new System.Drawing.Point(3, 4);
            this.btn_ShowRecords.Name = "btn_ShowRecords";
            this.btn_ShowRecords.Size = new System.Drawing.Size(253, 60);
            this.btn_ShowRecords.TabIndex = 0;
            this.btn_ShowRecords.Text = "SHOW RECORDS";
            this.btn_ShowRecords.UseVisualStyleBackColor = false;
            this.btn_ShowRecords.Click += new System.EventHandler(this.btn_ShowRecords_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(270, 277);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(263, 22);
            this.label2.TabIndex = 6;
            this.label2.Text = "Enter Minimum GPA:     ";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txt_MinGPA
            // 
            this.txt_MinGPA.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MinGPA.Location = new System.Drawing.Point(477, 269);
            this.txt_MinGPA.Name = "txt_MinGPA";
            this.txt_MinGPA.Size = new System.Drawing.Size(119, 41);
            this.txt_MinGPA.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1171, 659);
            this.Controls.Add(this.txt_MinGPA);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Database Query Medina";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CartmanCollegeDataSet cartmanCollegeDataSet;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
        private CartmanCollegeDataSet1 cartmanCollegeDataSet1;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource1;
        private CartmanCollegeDataSet1TableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_ViewGradeStat;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ListBox listBox_GroupGPA;
        private System.Windows.Forms.Button btn_GroupRecordsGPA;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.ListBox listBox_HighGPA;
        private System.Windows.Forms.Button btn_HighGpa;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ListBox listBox_MinGPA;
        private System.Windows.Forms.Button btn_ShowRecords;
        private System.Windows.Forms.Label lbl_Average;
        private System.Windows.Forms.Label lbl_Max;
        private System.Windows.Forms.Label lbl_Min;
        private System.Windows.Forms.Label lbl_Count;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_MinGPA;
    }
}

