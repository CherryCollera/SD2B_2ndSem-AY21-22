﻿using System;

namespace Activity2_Medina_
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World! :) ");
        }
    }
}
