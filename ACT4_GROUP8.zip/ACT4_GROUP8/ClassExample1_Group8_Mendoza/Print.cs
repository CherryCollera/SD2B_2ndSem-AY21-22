﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Group8_Mendoza
{
     class Print
    {
        public void PrintDetails()
        {
            Accept a = new Accept();
            a.AcceptDetails();
            Console.Write("Hello "+ a.firstname+" "+ a.lastname +"!!!\nYou have created a classesin OOP");
            MyProfile mp= new MyProfile();
            mp.DisplayProfile();
        }
    }
}
