﻿/*20-0332
Regee D. Casaña
SD2B
April 2, 2022
This program will display "Hello World"*/

using System;

namespace HelloWorld_Casaña
{
    class HelloWorld
    {
        static void Main(String[] args)
        {
            System.Console.WriteLine("Hello World!");
            System.Console.ReadKey();
        }
    }
}