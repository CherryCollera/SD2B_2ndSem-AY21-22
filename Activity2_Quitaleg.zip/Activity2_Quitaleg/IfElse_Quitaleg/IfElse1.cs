﻿/*
20-02604
Jaycee Audrei Mari M. Quitaleg
SD2B
April 06, 2022
This program will display if the first number is greater,lesser,or equal to the second number."
 */
using System;

namespace IfElse
{
    class IfElse1
    {
        static void Main(string[] args)
        {
            Console.Write("Input first num: ");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Input second num: ");
            int num2 = Convert.ToInt32(Console.ReadLine());

            if(num1 > num2)
            {
                Console.WriteLine("\n{0} is greater than {1}", num1, num2);
            }
           
            else if(num1 == num2)
            {
                Console.WriteLine("\n{0} is equal to {1}", num1, num2);
            }
           
            else
            {
                Console.WriteLine("\n{0} is less than {1}", num1, num2);
            }
            
            Console.ReadLine();

        }
    }
}
