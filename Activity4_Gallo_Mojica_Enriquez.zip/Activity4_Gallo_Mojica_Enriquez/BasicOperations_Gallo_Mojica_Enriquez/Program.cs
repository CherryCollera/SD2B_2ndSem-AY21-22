﻿/*
 * Group number: 2
 * Group Members: Gallo, Noel Jr. 
                  Mojica, Zedrick
                  Enriquez, John Brix
 * Section : BSCS-SD2B
 * Date : 26/04/2022
 * Purpose : using methods to do basic operations
 */
using System;

namespace BasicOperations_Gallo_Mojica_Enriquez
{
    class Program
    {
        static void Main(string[] args)
        {
            Input input = new Input();
            input.InputNumber("Enter 1st Number: ", "Enter 2nd Number: ");

            Console.WriteLine("\nThe Sum is {0}." +
                "\nThe Difference is {1}." +
                "\nThe Product is {2}." +
                "\nThe Quotient is {3}." +
                "\nThe Remainder is {4}.", Sum.ComputeSum(),
                Difference.ComputeDifference(), Product.ComputeProduct(),
                Quotient.ComputeQuotient(), Remainder.ComputeRemainder());

            Console.ReadKey();
        }
    }
}
