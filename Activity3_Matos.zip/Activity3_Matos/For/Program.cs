﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 16, 2022
 *  Display numbers form 9-0 in using for loop
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CompareNames
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int i = 10 - 1; i >=0; i--)
                Console.WriteLine(i);
            Console.ReadKey();
        }
    }
}
