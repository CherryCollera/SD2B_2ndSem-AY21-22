﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 14, 2022
 *  Program: Displays student information
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Sample2_MyProfile
    {
        internal class Program
            {
                static void Main(string[] args)
                    {
                        Console.WriteLine("Name:                 Dianna Grace Matos");
                        Console.WriteLine("Date of Birth:        July 1");
                        Console.WriteLine("Course:               BSCS Software Development");
                        Console.WriteLine("Year:                 2");
                        Console.WriteLine("Section:              SD2B");
                        Console.ReadKey();
                    }
            }
    }
