﻿using System;

namespace For_Duran
{
    class For
    {
        static void Main(string[] args)
        {
            Console.WriteLine("For statement: ");
            for (int i = 10 - 1; i >= 0; i--)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
