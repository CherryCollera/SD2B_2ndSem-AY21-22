﻿/*
 * 20-00382
 * Roiel A. Carlos
 * SD2B
 * March 27, 2022
 * This program will display the greeting "Hello World"
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample1_HelloWorld
{
    internal class roielcarlos
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World!");
            System.Console.ReadKey();
        }
    }
}
