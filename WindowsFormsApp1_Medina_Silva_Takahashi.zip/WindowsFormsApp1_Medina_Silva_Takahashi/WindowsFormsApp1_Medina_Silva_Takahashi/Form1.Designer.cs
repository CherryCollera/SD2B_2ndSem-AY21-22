﻿
namespace WindowsFormsApp1_Medina_Silva_Takahashi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_getMessage = new System.Windows.Forms.Button();
            this.btn_hide1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_getMessage
            // 
            this.btn_getMessage.Location = new System.Drawing.Point(174, 61);
            this.btn_getMessage.Name = "btn_getMessage";
            this.btn_getMessage.Size = new System.Drawing.Size(214, 41);
            this.btn_getMessage.TabIndex = 0;
            this.btn_getMessage.Text = "Get Message";
            this.btn_getMessage.UseVisualStyleBackColor = true;
            this.btn_getMessage.Click += new System.EventHandler(this.btn_getMessage_Click);
            // 
            // btn_hide1
            // 
            this.btn_hide1.Location = new System.Drawing.Point(446, 154);
            this.btn_hide1.Name = "btn_hide1";
            this.btn_hide1.Size = new System.Drawing.Size(106, 35);
            this.btn_hide1.TabIndex = 1;
            this.btn_hide1.Text = "Hide";
            this.btn_hide1.UseVisualStyleBackColor = true;
            this.btn_hide1.Click += new System.EventHandler(this.btn_hide1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(582, 214);
            this.Controls.Add(this.btn_hide1);
            this.Controls.Add(this.btn_getMessage);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_getMessage;
        private System.Windows.Forms.Button btn_hide1;
    }
}

