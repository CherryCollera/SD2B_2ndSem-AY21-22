﻿/*  20-01732
    Angelica D. Medina

    BSCSSD-2B
    April 17, 2022

This program will perform a while loop.
*/


using System;

namespace WhileLoop_Medina
{
    class whileloop_medina
    {
        static void Main(string[] args)
        {
            int i = 0;
            while (i<10)
            {
                Console.Write("While Statement  ");
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
