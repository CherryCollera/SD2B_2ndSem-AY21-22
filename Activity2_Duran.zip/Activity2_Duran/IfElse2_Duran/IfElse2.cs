﻿/*20-03334
Angelo Duran
SD2B
April 6, 2022
This program will execute IfElse2*/

using System;

namespace IfElse2
{
    class IfElse2_Duran
    {
        static void Main()
        {
            int num1, num2, num3;
            Console.Write("Enter 1st number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nEnter 2nd number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nEnter 3rd number: ");
            num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2 && num1 > num3)
            {
                Console.WriteLine(num1 + " is greater than " + num2 + " and " + num3);
                Console.ReadLine();
            }
            else if (num2 > num1 && num2 > num3)
            {
                Console.WriteLine(num2 + " is greater than " + num1 + " and " + num3);
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine(num3 + " is greater than " + num1 + " and " + num2);
                Console.ReadLine();
            }
        }
    }
}