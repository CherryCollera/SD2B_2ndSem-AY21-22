﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Gallo_Mojica_Enriquez
{
    internal class Quotient
    {
        public static int ComputeQuotient()
        {
            return DeclareVar.num1 / DeclareVar.num2;
        }
    }
}
