﻿/*20-03332
Regee D. Casaña
SD2B
April 2, 2022
This program will display my Profile*/

using System;

namespace MyProfile_Casaña
{
    class MyProfile
    {
        static void Main(string[] args)
        {
            Console.Write("\tName: " + "Regee D. Casaña\n\n");
            Console.WriteLine("\tDate of Birth: " + "May 7, 2002\n");
            Console.WriteLine("\tCourse: " + "BS in Computer Science major in Software Development\n");
            Console.WriteLine("\tYear: " + "II\n");
            Console.WriteLine("\tSection: " + "SD2B\n");
            Console.ReadLine();
        }
    }
}