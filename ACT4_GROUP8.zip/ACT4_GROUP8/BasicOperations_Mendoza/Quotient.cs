﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Mendoza
{
     class Quotient
    {
        public void ComputeQuotient()
        {
            DeclareVar.qou = DeclareVar.num1 / DeclareVar.num2;

        }
    }
}
