﻿/** ===========================
 Name: Reywen Lee Bautista
 Course & Section: BSCS-SD2B
 Date: April 17, 2021
=============================*/
using System;

namespace CompareNumbers_Bautista
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;

            Console.Write("Enter 1st number: ");
            num1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter 2st number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter 3st number: ");
            num3 = Convert.ToInt32(Console.ReadLine());

            if ((num1 == num2) || (num1 == num3) || (num2 == num3))
            {
                if (num1 > num2)
                {
                    if (num1 == num3) { Console.WriteLine("\n{0} and {2} are equal and greater than {1}", num1, num2, num3); }
                    else { Console.WriteLine("\n{1} and {2} are equal and less than {0}", num1, num2, num3); }
                }

                else if (num1 > num3)
                {
                    Console.WriteLine("\n{0} and {1} are equal and greater than {2}", num1, num2, num3);
                }
                else if (num2 > num1)
                {
                    if (num2 == num3) { Console.WriteLine("\n{1} and {2} are equal and greater than {0}", num1, num2, num3); }
                    else { Console.WriteLine("\n{0} and {2} are equal and less than {1}", num1, num2, num3); }
                }
                else if (num3 > num1)
                {
                    Console.WriteLine("\n{0} and {1} are equal and less than {2}", num1, num2, num3);
                }
                else
                {
                    Console.WriteLine("\n{0}, {1} and {2} are equal", num1, num2, num3);
                }
            }
            else if ((num1 > num2) && (num1 > num3))
            {
                Console.WriteLine("\n{0} is greater than {1} and {2}", num1, num2, num3);
            }
            else if ((num2 > num3))
            {
                Console.WriteLine("\n{1} is greater than {0} and {2}", num1, num2, num3);
            }
            else if ((num2 < num3))
            {
                Console.WriteLine("\n{2} is greater than {0} and {1}", num1, num2, num3);
            }
            else
            {
                Console.WriteLine("\nInvalid");
            }

            Console.ReadKey();
        }
    }
}
