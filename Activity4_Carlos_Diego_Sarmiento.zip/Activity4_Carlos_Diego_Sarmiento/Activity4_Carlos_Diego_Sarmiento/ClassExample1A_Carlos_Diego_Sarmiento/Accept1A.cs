﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1A_Carlos_Diego_Sarmiento
{
    class Accept1A
    {
        public string name;
        public void AcceptDetails()
        {
            System.Console.Write("Enter firstname and lastname:\t");
            name = System.Console.ReadLine();
        }
    }
}
