﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 15, 2022
 * Program that utilizes constant variable
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DeclaringConstants
    {
        internal class Program
            {
                static void Main(string[] args)
                    {                          
                        // Storage
                        double r, Area;
                        double PI = 3.14;


                        // Input r
                        Console.WriteLine("Enter Radius: ");
                        r = Convert.ToDouble(Console.ReadLine());           // Read and store input to r


                        // Calculate Area
                        Area = PI * r * r;


                        // Display
                        Console.WriteLine("\n\nRadius: {0:N4} \nArea: {1:N4}", r, Area);
                        Console.ReadKey();
                    }
            }
    }
