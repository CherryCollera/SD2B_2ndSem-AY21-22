﻿/*  MEMBERS: CARLOS, ROIEL A.
 *           DIEGO, ANGELO R.
 *           SARMIENTO, MARIAN GILLIAN G.
 *  SD2B 
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace DatabaseConnection_Carlos_Diego_Sarmiento
{
    public partial class Form1 : Form
    {
        private OleDbConnection bookConn;
        private OleDbCommand oleDbCmd = new OleDbCommand();
        //private String connParam = @"Provider=Microsoft.Jet.OLEDB.4.0;
           //Data Source=C:\Users\PC\Downloads\Activity8_Carlos_Diego_Sarmiento\book3.mdb";
        
        private String connParam = @"Provider=Microsoft.ACE.OLEDB.12.0;
            Data Source=C:\Users\PC\Downloads\Activity8_Carlos_Diego_Sarmiento\book3.accdb";

        //selecting on datagrid view based on ID
        private int bookID;

        public Form1()
        {
            bookConn = new OleDbConnection(connParam);

            InitializeComponent();

            //save is disabled and datagridview is on read only
            Btn_Save.Enabled = false;
            dataGridView1.ReadOnly = true;
        }

        //method to clear all fields and set bookID to 0
        private void clearAll()
        {
            txt_Title.Clear();
            txt_Desc.Clear();
            txt_BookNo.Clear();
            bookID = 0;
        }

        private void Btn_View_Click(object sender, EventArgs e)
        {
            lbl_Note.Text = "";
            lbl_Note2.Text = "";
            lbl_note3.Text = "";

            bookID = 0;

            txt_Title.Clear();
            txt_Desc.Clear();
            txt_BookNo.Clear();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("SELECT * FROM bookrecords", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("UDPATE * FROM bookrecords", connParam);
            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0], dataTable.Rows[i][1],
                    dataTable.Rows[i][2], dataTable.Rows[i][3]);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'book3DataSet1.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter1.Fill(this.book3DataSet1.bookrecords);
            // TODO: This line of code loads data into the 'book3DataSet.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter.Fill(this.book3DataSet.bookrecords);

        }

        private void Btn_Add_Click(object sender, EventArgs e)
        {
            if (txt_Title.Text != "" && txt_BookNo.Text != "" && txt_Desc.Text != "")
            {
                bookConn.Open();
                oleDbCmd.Connection = bookConn;
                oleDbCmd.CommandText = "Insert into bookrecords (booktitle, description, bookno) " +
                    "values ('" + this.txt_Title.Text + "' , '" + this.txt_Desc.Text + "' , '" + this.txt_BookNo.Text + "');";
                int temp = oleDbCmd.ExecuteNonQuery();
                if (temp > 0)
                {
                    clearAll();

                    MessageBox.Show("Record successfully added");

                    lbl_Note.Text = "PLEASE CLICK VIEW ALL RECORDS";
                    lbl_Note2.Text = "TO UPDATE RECORDS";
                    lbl_note3.Text = "";
                }
                else
                {
                    MessageBox.Show("Record Fail Added");
                }
                bookConn.Close();
            }
            else
            {
                MessageBox.Show("Please fill out every field!");
            }
        }

        private void Btn_Delete_Click(object sender, EventArgs e)
        {
            if (bookID != 0)
            {
                DialogResult ans;
                ans = MessageBox.Show("Are you sure you want to remove " + txt_Title.Text + "?"
                    , "REMOVE " + txt_Title.Text + "?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (ans == DialogResult.Yes)
                {
                    bookConn.Open();
                    oleDbCmd.Connection = bookConn;
                    oleDbCmd.CommandText = "DELETE FROM bookrecords WHERE ID = " + bookID + ";";
                    int temp = oleDbCmd.ExecuteNonQuery();
                    bookConn.Close();

                    MessageBox.Show(txt_Title.Text + " has been deleted!");

                    txt_Title.Text = null;
                    txt_Desc.Text = null;
                    txt_BookNo.Text = null;

                    lbl_Note.Text = "PLEASE CLICK VIEW ALL RECORDS";
                    lbl_Note2.Text = "TO UPDATE RECORDS";
                }
                else
                {
                    MessageBox.Show("Cancelled");
                    clearAll();
                }
            }
            else
            {
                MessageBox.Show("Please select what to delete");
            }
        }

        private void Btn_Save_Click(object sender, EventArgs e)
        {
            //save the changes
            bookConn.Open();
            oleDbCmd.Connection = bookConn;
            oleDbCmd.CommandText = "UPDATE bookrecords SET booktitle = '" + this.txt_Title.Text + "' , " +
                "description = '" + txt_Desc.Text + "' , bookno = '" + txt_BookNo.Text + "' " +
                "WHERE ID = " + bookID + ";";
            int temp = oleDbCmd.ExecuteNonQuery();
            bookConn.Close();

            MessageBox.Show("Changes have been applied.");

            //enable all buttons except save
            Btn_Save.Enabled = false;
            Btn_Delete.Enabled = true;
            Btn_Add.Enabled = true;
            dataGridView1.Enabled = true;
            btn_Edit.Enabled = true;
            Btn_View.Enabled = true;

            //clear fields and set ID to 0
            clearAll();

            lbl_Note.Text = "PLEASE CLICK VIEW ALL RECORDS";
            lbl_Note2.Text = "TO UPDATE RECORDS";
            lbl_note3.Text = "";
        }

        private void btn_Edit_Click(object sender, EventArgs e)
        {
            if (txt_Title.Text != "" || txt_Desc.Text != "" || txt_BookNo.Text != "")
            {
                //only enable save and view records button
                Btn_Save.Enabled = true;
                dataGridView1.ReadOnly = false;
                Btn_Add.Enabled = false;
                Btn_Delete.Enabled = false;
                dataGridView1.Enabled = false;
                btn_Edit.Enabled = false;
                Btn_View.Enabled = false;

                lbl_Note.Text = "NOTE: ONLY ONE CAN BE EDITED!";
                lbl_Note2.Text = "SELECTING ON DATA GRID IS DISABLED!";
                lbl_note3.Text = "SELECT AGAIN AFTER CLICKING SAVE";
            }
            else
            {
                MessageBox.Show("Please select what you would like to edit");
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //get bookID based on row clicked and show details on textboxes
            bookID = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            txt_Title.Text = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[1].Value);
            txt_Desc.Text = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[2].Value);
            txt_BookNo.Text = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[3].Value);
        }
    }
}
