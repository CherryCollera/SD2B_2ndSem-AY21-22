﻿/*
 * 20-01726
 * Aira M Takahashi
 * SD2A
 */
using System;

namespace InputMyName_Takahashi
{
    class Program
    {
        static void Main(string[] args)
        {
            String firstname;
            String lastname;
            Console.WriteLine("Enter your Name <firstname.lastname>" );
             firstname = Console.ReadLine();
             lastname = Console.ReadLine();
            Console.WriteLine("Hello" + firstname + " "+lastname+ "!!!" +
                "\nWelcome to OOP environment");
            Console.ReadKey();
        }
    }
}
