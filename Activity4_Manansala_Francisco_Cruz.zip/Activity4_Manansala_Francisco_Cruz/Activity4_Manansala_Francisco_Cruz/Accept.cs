﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Manansala_Francisco_Cruz
{
    class Accept
    {
        public String firstname, lastname;
        public void AcceptDetails()
        {
            System.Console.Write("Enter your first name: ");
            firstname = Console.ReadLine();
            System.Console.Write("Enter your last name: ");
            lastname = Console.ReadLine();
        }
    }
}
