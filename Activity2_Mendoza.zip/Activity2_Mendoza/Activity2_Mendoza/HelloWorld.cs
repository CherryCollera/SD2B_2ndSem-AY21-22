﻿/*
20-02530
Carl Joseph Mendoza
SD2B
October 23, 2002
The program will display the phrase "Hello World!"
 */

using System;

namespace HelloWorld_Mendoza
{
    class HelloWorld
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Hello, World!");
            Console.ReadKey();
        }


    }


}

