﻿using System;

namespace Sample2_MyProfile
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name: Andrei P. Lazo\n");
            Console.WriteLine("Date of Birth: March 4 2002\n");
            Console.WriteLine("Course: BS Computer Science\n");
            Console.WriteLine("Year: II\n");
            Console.WriteLine("Section: 2B");
        }
    }
}
