﻿using System;

namespace CompareNumbers_Manansala
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;
            Console.Write("\nEnter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Third Number: ");
            num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2 && num1 > num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num1, num2, num3);
                Console.WriteLine("{0} is less than {1}", num2, num1);
                Console.WriteLine("{0} is less than {1}", num3, num1);
                Console.ReadLine();
            }
            else if (num2 > num1 && num2 > num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num2, num1, num3);
                Console.WriteLine("{0} is less than {1}", num1, num2);
                Console.WriteLine("{0} is less than {1}", num3, num2);
                Console.ReadLine();
            }
            else if (num3 > num1 && num3 > num2)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num3, num1, num2);
                Console.WriteLine("{0} is less than {1}", num1, num3);
                Console.WriteLine("{0} is less than {1}", num2, num3);
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("{0}, {1}, and {2} are equal", num1, num2, num3);
                Console.ReadLine();
            }
        }
    }
}
