﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1A_Silva
{
    class MyProfile1a
    {
        public void DisplayProfile()

        {
            //display the "Profile" 
            System.Console.WriteLine("\n\n\t\t\t\tP R O F I L E\n");
            System.Console.WriteLine("Name\t\t\t: Alyssa Mae Silva \n");
            System.Console.WriteLine("Birthday\t\t: October 27, 2001\n");
            System.Console.WriteLine("Course\t\t\t: BS Computer Science " + "major in Software Development \n");
            System.Console.WriteLine("Year\t\t\t: 2nd Year\n");
            System.Console.WriteLine("Section\t\t\t: B\n");
            System.Console.ReadLine();
        }
    }
}
