﻿/* 20 - 01484
 John Brix B. Enriquez
 SD2B
 April 5, 2022
 This program will compare two numbers*/

using System;
namespace IfElse1
{
    class IfElse1
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("Enter the first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            if(num1 > num2)
            {
                Console.WriteLine("{0} is greater than {1}.", num1, num2);
            }
            else if(num1 == num2)
            {
                Console.WriteLine("{0} is equal to {1}.", num1, num2);
            }
            else
            {
                Console.WriteLine("{0} is greater than {1}.", num2, num1);
            }
            Console.ReadKey();

        }
    }
}