﻿/** ===========================
 Name: Reywen Lee Bautista
 Course & Section: BSCS-SD2B
 Date: April 1, 2022
=============================*/

using System;

namespace ComputeTheSum_Bautista
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("Enter the first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Sum={0}  ", num1 + num2);
            Console.ReadLine();
        }
    }
}
