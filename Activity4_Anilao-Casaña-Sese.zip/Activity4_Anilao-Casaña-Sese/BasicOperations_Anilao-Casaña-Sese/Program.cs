﻿using System;

namespace BasicOperations_Anilao_Casaña_Sese
{
    class Program
    {
        static void Main(string[] args)
        {
            Input input = new Input();  
            input.InputValues();       

            Sum sum = new Sum();    
            sum.ComputeSum();       
            //display the sum of num1 and num2
            Console.WriteLine("\nSum\t\t=\t{0}", DeclareVar.sum); 

            Difference difference = new Difference(); 
            difference.ComputeDifference();
            //display the difference of num1 and num2
            Console.WriteLine("Difference\t=\t{0}", DeclareVar.difference);  

            Product product = new Product();
            product.ComputeProduct();
            //display the product of num1 and num2
            Console.WriteLine("Product\t\t=\t{0}", DeclareVar.product);   

            Quotient quotient = new Quotient();
            quotient.ComputeQuotient();
            //display the quotient of num1 and num2
            Console.WriteLine("Quotient\t=\t{0}", DeclareVar.quotient);  

            Remainder remainder = new Remainder();
            remainder.ComputeRemainder();
            //display the remainder of num1 and num2
            Console.WriteLine("Remainder\t=\t{0}", DeclareVar.remainder);    
            Console.ReadLine();
        }
    }
}
