﻿/*20 - 03334
Angelo C.Duran
SD2B
April 4, 2022
This program will let you input your name*/

using System;

namespace InputMyName_Duran
{
    class InputMyName
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your name (fname)(Lname):  ");

            String Name = Console.ReadLine();

            Console.WriteLine("Hello! " + Name + "\n  Welcome To OOP environment!");

            Console.ReadLine();
        }
    }
}