﻿/*
20-02604
Jaycee Audrei Mari M. Quitaleg
SD2B
April 06, 2022
This program will declare a constant and display it.
 */

using System;

namespace DeclaringConstants
{
    class DeclaringConstants
    {
        static void Main()
        {
            Console.Write("Enter radius: ");
            int radius = Convert.ToInt32(Console.ReadLine());
            const double pi = Math.PI;
            double AreaCircle = pi * radius * radius;

            Console.WriteLine("Radius = {0}\tArea = {1}", radius,AreaCircle);
            Console.ReadLine();
        }
    }
}

