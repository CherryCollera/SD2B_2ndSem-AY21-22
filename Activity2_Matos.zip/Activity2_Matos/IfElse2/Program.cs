﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 15, 2022
 * Program to determine which is greater among the 3 input numbers
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace IfElse2
    {
        internal class Program
            {
                static void Main(string[] args)
                    {
                        Console.WriteLine("Enter first number: ");
                        int num1 = int.Parse(Console.ReadLine());           // Read and store input 

                        Console.WriteLine("Enter second number: ");
                        int num2 = int.Parse(Console.ReadLine());           // Read and store input 

                        Console.WriteLine("Enter third number: ");
                        int num3 = int.Parse(Console.ReadLine());           // Read and store input 
                        Console.WriteLine("\n\n");


                        if (num1 > num2) 
                            {
                                if (num1 > num3) 
                                   Console.Write("Number one is the largest!\n");
                                else
                                   Console.Write("Number three is the largest!\n");                        
                            }
                        else if (num2 > num3)
                            Console.Write("Number two is the largest!\n");
                        else
                            Console.Write("Number three is the largest!\n");
                    }
            }
    }
