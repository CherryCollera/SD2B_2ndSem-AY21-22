﻿using System;

namespace BasicOperations_Lazo
{
    class Program
    {
        static void Main(string[] args)
        {
            Input input = new Input();
            input.inputValues();

            Sum sum = new Sum();
            sum.computeSum();
            System.Console.WriteLine("Sum: " + DeclareVar.sum);


            Difference diff = new Difference();
            diff.computeDifference();
            System.Console.WriteLine("Difference: " + DeclareVar.difference);


            Product prod = new Product();
            prod.computeProduct();
            System.Console.WriteLine("Product: " + DeclareVar.product);


            Quotient quotient = new Quotient();
            quotient.computeQuotient();
            System.Console.WriteLine("Quotient: " + DeclareVar.quotient);

            Remainder rem = new Remainder();
            rem.computeRemainder();
            System.Console.WriteLine("Remainder: " + DeclareVar.remainder);



        }
    }
}
