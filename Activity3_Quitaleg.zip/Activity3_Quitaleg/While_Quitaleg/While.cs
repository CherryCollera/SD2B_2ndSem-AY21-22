﻿/*
20-02604
Jaycee Audrei Mari M. Quitaleg
SD2B
April 08, 2022
This program will use the while loop.
 */

using System;

namespace While_Quitaleg
{
    class While_Quitaleg
    {
        static void Main(string[] args)
        {
            int i = 0;
            while (i < 10)
            {
                Console.Write("While statement");
                Console.WriteLine(i);
                i++;
            }

            Console.ReadKey();
        }
    }
}
