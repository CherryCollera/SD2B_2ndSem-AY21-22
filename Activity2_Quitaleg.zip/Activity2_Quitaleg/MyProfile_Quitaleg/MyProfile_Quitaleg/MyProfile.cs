﻿/*
20-02604
Jaycee Audrei Mari M. Quitaleg
SD2B
April 06, 2022
This program will display my profile."
 */

using System;

namespace MyProfile
{
    class Profile
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name: Jaycee Audrei Mari M. Quitaleg");
            Console.WriteLine();
            Console.WriteLine("Date of Birth: February 21, 2002");
            Console.WriteLine();
            Console.WriteLine("Course: Bachelor of Science in Computer Science");
            Console.WriteLine();
            Console.WriteLine("Year & Section: SD2B");
            Console.ReadKey();
        }
    }
}
