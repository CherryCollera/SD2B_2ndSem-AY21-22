﻿/* 20 - 01484
 John Brix B. Enriquez
 SD2B
 April 17, 2022
 This program will display the implementation of For loop*/

using System;
namespace For
{
    class For
    {
        static void Main(string[] args)
        {
            for(int i = 10 - 1; i >= 0; i--)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}