﻿/*20-00613
Marian Gillian G. Sarmiento
SD2B
April 19, 2022
This program will show how a while loop is performed*/

using System;

namespace While_Sarmiento
{
    class While
    {
        static void Main(string[] args)
        {
            int i = 0;
            while (i < 10)
            {
                Console.Write("While Statement ");
                Console.WriteLine(i);
                i++;
            }
            Console.ReadLine();
        }
    }
}
