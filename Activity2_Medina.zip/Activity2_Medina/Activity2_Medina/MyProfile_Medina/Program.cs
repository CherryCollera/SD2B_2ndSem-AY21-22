﻿/*  20-01732
    Angelica D. Medina

    BSCSSD-2B
    April 07, 2022

This program will display the information about my student profile (Name, Birthday, Program/Course, Year, and Section). 
*/

using System;

namespace Sample2_MyProfile
{
    class AngelicaMedina
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("My Profile!\n");

            System.Console.WriteLine("Name:             Angelica Dellosa Medina");
            System.Console.WriteLine();

            System.Console.WriteLine("Date of Birth:    November 14, 2001");
            System.Console.WriteLine("");

            System.Console.WriteLine("Program/Course:   BS Computer Science major in Software Development\n");
            System.Console.WriteLine("Year:             II\n");
            System.Console.WriteLine("Section:          2B");
            System.Console.WriteLine();

            System.Console.ReadKey();
        }
    }
}



