﻿/*
 * student Id number : 20-05258
 * student full name : Zedrick A. Mojica
 * Section : BSCS-SD2B
 * Date : 04/04/2022
 * Purpose : displaying the programmer's name, date of birth, course, year and section
 */
using System;

namespace Activity2_Mojica
{
    class MyProfile
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Name: Zedrick A. Mojica");
            Console.WriteLine("");
            System.Console.WriteLine("Date of birth: March 22");
            Console.WriteLine("");
            System.Console.WriteLine("Course: BS Computer Science ");
            Console.WriteLine("");
            System.Console.WriteLine("Year: 2nd year");
            Console.WriteLine("");
            System.Console.WriteLine("Section : SD2B");
            System.Console.ReadKey();
        }
    }
}