﻿/*
 * 20-00382
 * Roiel A. Carlos
 * SD2B
 * April 18, 2022
 * This program will show how a do-while loop is performed
 */
using System;

namespace DoWhile_Carlos
{
    class DoWhile
    {
        static void Main(string[] args)
        {
            int[] loopArray = new int[] { 6, 7, 8, 10 };
            int loopSum = 0;
            int i = 0;

            do
            {
                loopSum += loopArray[i]; 
                i++;
            } while (i < 4);

            Console.WriteLine(loopSum);
            Console.ReadKey();
        }
    }
}
