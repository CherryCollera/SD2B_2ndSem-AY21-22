﻿/*20 - 03334
Angelo C.Duran
SD2B
April 4, 2022
This program will display the phrase "Hello World"*/

using System;

namespace HelloWorld_Duran
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            System.Console.ReadKey();
        }
    }
}