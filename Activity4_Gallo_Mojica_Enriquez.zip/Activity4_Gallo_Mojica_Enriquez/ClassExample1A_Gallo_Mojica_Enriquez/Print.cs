﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Gallo_Mojica_Enriquez
{
    internal class Print //Creating 2nd class
    {
        public void PrintDetails(String firstName, String lastName)
        {
            Console.WriteLine("Hello " + firstName + " " + lastName + "!!! \nYou have created class in OOP");
            
        }
    }
}
