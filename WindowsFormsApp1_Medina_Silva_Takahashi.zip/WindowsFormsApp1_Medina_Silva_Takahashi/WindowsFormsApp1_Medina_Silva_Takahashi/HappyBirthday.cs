﻿/* 		Activity #5
 * 		Grp 9
 * 	Members: Medina, Angelica
	   	 Silva, Alyssa Mae
	   	 Takahashi, Aira
 * BSCS-SD2B
 * 05/04/2022*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1_Medina_Silva_Takahashi
{
    class HappyBirthday
    {
        public string GetMessage(string firstname, string lastname)
        {
            return "Happy Birthday " + firstname + lastname+ " !!!";
        }
    }
}
