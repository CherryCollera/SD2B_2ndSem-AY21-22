﻿/*Activity 4
  Group 5
  Members:
            Anilao, Jean Claudine D.
            Casaña, Regee D.
            Sese, Regie A.
Program and Section: BSCS SD2B
Date: 24/04/2022
This Program will display Class Example number 2 */

using System;

namespace ClassExample2_Anilao_Casaña_Sese
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car;
            car = new Car("Red");
            Console.WriteLine(car.Describe());
            car = new Car("Green");
            Console.WriteLine(car.Describe());
            Console.ReadLine();
        }
    }
}
