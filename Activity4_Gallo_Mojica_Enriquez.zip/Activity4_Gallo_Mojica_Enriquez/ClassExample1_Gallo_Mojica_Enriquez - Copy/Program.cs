﻿/*
 * Group number: 2
 * Group Members: gallo, Noel Jr. 
                  Mojica, Zedrick
                  Enriquez, John Brix
 * Section : BSCS-SD2B
 * Date : 26/04/2022
 * Purpose : using methods to get an input and print it 
 */
using System;

namespace ClassExample1_Gallo_Mojica_Enriquez
{
    class Program
    {
        static void Main(string[] args)
        {
            Print p = new Print();
            p.PrintDetails();
            Console.ReadKey();
        }
    }
}
