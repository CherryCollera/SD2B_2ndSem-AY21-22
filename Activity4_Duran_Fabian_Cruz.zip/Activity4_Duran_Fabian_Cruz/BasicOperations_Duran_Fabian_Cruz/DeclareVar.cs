﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicOperations_Duran_Fabian_Cruz
{
    class DeclareVar
    {
        public static int num1, num2, sum, difference, product, quotient, remainder;
    }
}
