﻿using System;

namespace Sample2_MyProfile
{
    class ArnieJamesManansala
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\tName: " + "Arnie James H. Manansala\n");
            Console.WriteLine("\tDate of Birth: " + "May 11, 2002\n");
            Console.WriteLine("\tCourse: " + "BS in Computer Science major in Software Development\n");
            Console.WriteLine("\tYear: " + "2nd\n");
            Console.WriteLine("\tSection: " + "SD2B\n");
            Console.ReadKey();
        }
    }
}
