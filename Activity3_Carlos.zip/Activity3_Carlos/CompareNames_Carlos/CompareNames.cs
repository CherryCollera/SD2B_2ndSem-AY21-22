﻿/*
 * 20-00382
 * Roiel A. Carlos
 * SD2B
 * April 18, 2022
 * This program will compare names
 */
using System;

namespace CompareNames_Carlos
{
    class CompareNames
    {
        static void Main(string[] args)
        {
            string name1 = "Royel";
            string name2 = "Royel";
            string name3 = "Roiel";
            string name4 = "roiel";
            string name5 = "ROIEL";

            Console.WriteLine("\nUsing Equals() method");

            Console.WriteLine("   compare {0} to {1}: {2}", name1, name2, String.Equals(name1, name2));
            Console.WriteLine("   compare {0} to {1}: {2}", name1, name3, String.Equals(name1, name3));
            Console.WriteLine("   Length of {0} is {1} ", name1, name1.Length);
            Console.WriteLine("   String {0} Substring(0, 3) will return {1}", name5, name5.Substring(0, 3));

            Console.WriteLine("\nUsing Compare() method");
            Console.WriteLine("   compare {0} to {1}: {2}", name1, name2, String.Compare(name1, name2));
            Console.WriteLine("   compare {0} to {1}: {2}", name1, name3, String.Compare(name1, name3));
            Console.WriteLine("   compare {0} to {1}: {2}", name3, name1, String.Compare(name3, name1));
            Console.WriteLine("   compare {0} to {1}: {2}", name4, name5, String.Equals(name4, name5));


            Console.WriteLine("\nUsing CompareTo() method");
            Console.WriteLine("   compare {0} to {1}: (2)", name1, name2, name1.CompareTo(name2));
            Console.WriteLine("   compare {0} to {1}: {2}", name1, name3, name1.CompareTo(name3));
            Console.WriteLine("   compare {0} to {1}: {2}", name3, name1, name3.CompareTo(name1));

            Console.ReadKey();
        }
    }
}
