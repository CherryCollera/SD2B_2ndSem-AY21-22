﻿
namespace DataGridView_Sese
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.refreshToolStrip = new System.Windows.Forms.ToolStrip();
            this.refreshToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.bSCSToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSCSToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.bSITToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSITToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.resident_SamalToolStrip = new System.Windows.Forms.ToolStrip();
            this.resident_SamalToolStripButton = new System.Windows.Forms.ToolStripButton();
            this._2ndYr_StudToolStrip = new System.Windows.Forms.ToolStrip();
            this._2ndYr_StudToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.studIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.middlenameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.database01DataSet = new DataGridView_Sese.Database01DataSet();
            this.studentTableAdapter = new DataGridView_Sese.Database01DataSetTableAdapters.StudentTableAdapter();
            this.lastName_A_and_CToolStrip = new System.Windows.Forms.ToolStrip();
            this.lastName_A_and_CToolStripButton = new System.Windows.Forms.ToolStripButton();
            this._2BToolStrip = new System.Windows.Forms.ToolStrip();
            this._2BToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.firstName_ConsonantToolStrip = new System.Windows.Forms.ToolStrip();
            this.firstName_ConsonantToolStripButton = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.refreshToolStrip.SuspendLayout();
            this.bSCSToolStrip.SuspendLayout();
            this.bSITToolStrip.SuspendLayout();
            this.resident_SamalToolStrip.SuspendLayout();
            this._2ndYr_StudToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database01DataSet)).BeginInit();
            this.lastName_A_and_CToolStrip.SuspendLayout();
            this._2BToolStrip.SuspendLayout();
            this.firstName_ConsonantToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studIDDataGridViewTextBoxColumn,
            this.lastnameDataGridViewTextBoxColumn,
            this.firstnameDataGridViewTextBoxColumn,
            this.middlenameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.birthdayDataGridViewTextBoxColumn,
            this.programDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.studentBindingSource;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(776, 293);
            this.dataGridView1.TabIndex = 0;
            // 
            // refreshToolStrip
            // 
            this.refreshToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.refreshToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshToolStripButton});
            this.refreshToolStrip.Location = new System.Drawing.Point(12, 308);
            this.refreshToolStrip.Name = "refreshToolStrip";
            this.refreshToolStrip.Size = new System.Drawing.Size(62, 25);
            this.refreshToolStrip.TabIndex = 1;
            this.refreshToolStrip.Text = "refreshToolStrip";
            // 
            // refreshToolStripButton
            // 
            this.refreshToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.refreshToolStripButton.Name = "refreshToolStripButton";
            this.refreshToolStripButton.Size = new System.Drawing.Size(50, 22);
            this.refreshToolStripButton.Text = "Refresh";
            this.refreshToolStripButton.Click += new System.EventHandler(this.refreshToolStripButton_Click);
            // 
            // bSCSToolStrip
            // 
            this.bSCSToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSCSToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSCSToolStripButton});
            this.bSCSToolStrip.Location = new System.Drawing.Point(74, 308);
            this.bSCSToolStrip.Name = "bSCSToolStrip";
            this.bSCSToolStrip.Size = new System.Drawing.Size(50, 25);
            this.bSCSToolStrip.TabIndex = 2;
            this.bSCSToolStrip.Text = "bSCSToolStrip";
            this.bSCSToolStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.bSCSToolStrip_ItemClicked);
            // 
            // bSCSToolStripButton
            // 
            this.bSCSToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSCSToolStripButton.Name = "bSCSToolStripButton";
            this.bSCSToolStripButton.Size = new System.Drawing.Size(38, 22);
            this.bSCSToolStripButton.Text = "BSCS";
            this.bSCSToolStripButton.Click += new System.EventHandler(this.bSCSToolStripButton_Click);
            // 
            // bSITToolStrip
            // 
            this.bSITToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSITToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSITToolStripButton});
            this.bSITToolStrip.Location = new System.Drawing.Point(124, 308);
            this.bSITToolStrip.Name = "bSITToolStrip";
            this.bSITToolStrip.Size = new System.Drawing.Size(45, 25);
            this.bSITToolStrip.TabIndex = 3;
            this.bSITToolStrip.Text = "bSITToolStrip";
            // 
            // bSITToolStripButton
            // 
            this.bSITToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSITToolStripButton.Name = "bSITToolStripButton";
            this.bSITToolStripButton.Size = new System.Drawing.Size(33, 22);
            this.bSITToolStripButton.Text = "BSIT";
            this.bSITToolStripButton.Click += new System.EventHandler(this.bSITToolStripButton_Click);
            // 
            // resident_SamalToolStrip
            // 
            this.resident_SamalToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.resident_SamalToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resident_SamalToolStripButton});
            this.resident_SamalToolStrip.Location = new System.Drawing.Point(169, 308);
            this.resident_SamalToolStrip.Name = "resident_SamalToolStrip";
            this.resident_SamalToolStrip.Size = new System.Drawing.Size(105, 25);
            this.resident_SamalToolStrip.TabIndex = 4;
            this.resident_SamalToolStrip.Text = "resident_SamalToolStrip";
            this.resident_SamalToolStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.resident_SamalToolStrip_ItemClicked);
            // 
            // resident_SamalToolStripButton
            // 
            this.resident_SamalToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.resident_SamalToolStripButton.Name = "resident_SamalToolStripButton";
            this.resident_SamalToolStripButton.Size = new System.Drawing.Size(93, 22);
            this.resident_SamalToolStripButton.Text = "Resident_Samal";
            this.resident_SamalToolStripButton.Click += new System.EventHandler(this.resident_SamalToolStripButton_Click);
            // 
            // _2ndYr_StudToolStrip
            // 
            this._2ndYr_StudToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this._2ndYr_StudToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._2ndYr_StudToolStripButton});
            this._2ndYr_StudToolStrip.Location = new System.Drawing.Point(274, 308);
            this._2ndYr_StudToolStrip.Name = "_2ndYr_StudToolStrip";
            this._2ndYr_StudToolStrip.Size = new System.Drawing.Size(87, 25);
            this._2ndYr_StudToolStrip.TabIndex = 5;
            this._2ndYr_StudToolStrip.Text = "_2ndYr_StudToolStrip";
            // 
            // _2ndYr_StudToolStripButton
            // 
            this._2ndYr_StudToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this._2ndYr_StudToolStripButton.Name = "_2ndYr_StudToolStripButton";
            this._2ndYr_StudToolStripButton.Size = new System.Drawing.Size(75, 22);
            this._2ndYr_StudToolStripButton.Text = "_2ndYr_Stud";
            this._2ndYr_StudToolStripButton.Click += new System.EventHandler(this._2ndYr_StudToolStripButton_Click);
            // 
            // studIDDataGridViewTextBoxColumn
            // 
            this.studIDDataGridViewTextBoxColumn.DataPropertyName = "StudID";
            this.studIDDataGridViewTextBoxColumn.HeaderText = "StudID";
            this.studIDDataGridViewTextBoxColumn.Name = "studIDDataGridViewTextBoxColumn";
            // 
            // lastnameDataGridViewTextBoxColumn
            // 
            this.lastnameDataGridViewTextBoxColumn.DataPropertyName = "Lastname";
            this.lastnameDataGridViewTextBoxColumn.HeaderText = "Lastname";
            this.lastnameDataGridViewTextBoxColumn.Name = "lastnameDataGridViewTextBoxColumn";
            // 
            // firstnameDataGridViewTextBoxColumn
            // 
            this.firstnameDataGridViewTextBoxColumn.DataPropertyName = "Firstname";
            this.firstnameDataGridViewTextBoxColumn.HeaderText = "Firstname";
            this.firstnameDataGridViewTextBoxColumn.Name = "firstnameDataGridViewTextBoxColumn";
            // 
            // middlenameDataGridViewTextBoxColumn
            // 
            this.middlenameDataGridViewTextBoxColumn.DataPropertyName = "Middlename";
            this.middlenameDataGridViewTextBoxColumn.HeaderText = "Middlename";
            this.middlenameDataGridViewTextBoxColumn.Name = "middlenameDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // birthdayDataGridViewTextBoxColumn
            // 
            this.birthdayDataGridViewTextBoxColumn.DataPropertyName = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.HeaderText = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.Name = "birthdayDataGridViewTextBoxColumn";
            // 
            // programDataGridViewTextBoxColumn
            // 
            this.programDataGridViewTextBoxColumn.DataPropertyName = "Program";
            this.programDataGridViewTextBoxColumn.HeaderText = "Program";
            this.programDataGridViewTextBoxColumn.Name = "programDataGridViewTextBoxColumn";
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            // 
            // studentBindingSource
            // 
            this.studentBindingSource.DataMember = "Student";
            this.studentBindingSource.DataSource = this.database01DataSet;
            // 
            // database01DataSet
            // 
            this.database01DataSet.DataSetName = "Database01DataSet";
            this.database01DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentTableAdapter
            // 
            this.studentTableAdapter.ClearBeforeFill = true;
            // 
            // lastName_A_and_CToolStrip
            // 
            this.lastName_A_and_CToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.lastName_A_and_CToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lastName_A_and_CToolStripButton});
            this.lastName_A_and_CToolStrip.Location = new System.Drawing.Point(361, 308);
            this.lastName_A_and_CToolStrip.Name = "lastName_A_and_CToolStrip";
            this.lastName_A_and_CToolStrip.Size = new System.Drawing.Size(127, 25);
            this.lastName_A_and_CToolStrip.TabIndex = 6;
            this.lastName_A_and_CToolStrip.Text = "lastName_A_and_CToolStrip";
            // 
            // lastName_A_and_CToolStripButton
            // 
            this.lastName_A_and_CToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lastName_A_and_CToolStripButton.Name = "lastName_A_and_CToolStripButton";
            this.lastName_A_and_CToolStripButton.Size = new System.Drawing.Size(115, 22);
            this.lastName_A_and_CToolStripButton.Text = "LastName_A_and_C";
            this.lastName_A_and_CToolStripButton.Click += new System.EventHandler(this.lastName_A_and_CToolStripButton_Click);
            // 
            // _2BToolStrip
            // 
            this._2BToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this._2BToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._2BToolStripButton});
            this._2BToolStrip.Location = new System.Drawing.Point(488, 308);
            this._2BToolStrip.Name = "_2BToolStrip";
            this._2BToolStrip.Size = new System.Drawing.Size(41, 25);
            this._2BToolStrip.TabIndex = 7;
            this._2BToolStrip.Text = "_2BToolStrip";
            // 
            // _2BToolStripButton
            // 
            this._2BToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this._2BToolStripButton.Name = "_2BToolStripButton";
            this._2BToolStripButton.Size = new System.Drawing.Size(29, 22);
            this._2BToolStripButton.Text = "_2B";
            this._2BToolStripButton.Click += new System.EventHandler(this._2BToolStripButton_Click);
            // 
            // firstName_ConsonantToolStrip
            // 
            this.firstName_ConsonantToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.firstName_ConsonantToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.firstName_ConsonantToolStripButton});
            this.firstName_ConsonantToolStrip.Location = new System.Drawing.Point(529, 308);
            this.firstName_ConsonantToolStrip.Name = "firstName_ConsonantToolStrip";
            this.firstName_ConsonantToolStrip.Size = new System.Drawing.Size(140, 25);
            this.firstName_ConsonantToolStrip.TabIndex = 8;
            this.firstName_ConsonantToolStrip.Text = "firstName_ConsonantToolStrip";
            // 
            // firstName_ConsonantToolStripButton
            // 
            this.firstName_ConsonantToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.firstName_ConsonantToolStripButton.Name = "firstName_ConsonantToolStripButton";
            this.firstName_ConsonantToolStripButton.Size = new System.Drawing.Size(23, 23);
            this.firstName_ConsonantToolStripButton.Text = "FirstName_Consonant";
            this.firstName_ConsonantToolStripButton.Click += new System.EventHandler(this.firstName_ConsonantToolStripButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(808, 450);
            this.Controls.Add(this.firstName_ConsonantToolStrip);
            this.Controls.Add(this._2BToolStrip);
            this.Controls.Add(this.lastName_A_and_CToolStrip);
            this.Controls.Add(this._2ndYr_StudToolStrip);
            this.Controls.Add(this.resident_SamalToolStrip);
            this.Controls.Add(this.bSITToolStrip);
            this.Controls.Add(this.bSCSToolStrip);
            this.Controls.Add(this.refreshToolStrip);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.refreshToolStrip.ResumeLayout(false);
            this.refreshToolStrip.PerformLayout();
            this.bSCSToolStrip.ResumeLayout(false);
            this.bSCSToolStrip.PerformLayout();
            this.bSITToolStrip.ResumeLayout(false);
            this.bSITToolStrip.PerformLayout();
            this.resident_SamalToolStrip.ResumeLayout(false);
            this.resident_SamalToolStrip.PerformLayout();
            this._2ndYr_StudToolStrip.ResumeLayout(false);
            this._2ndYr_StudToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database01DataSet)).EndInit();
            this.lastName_A_and_CToolStrip.ResumeLayout(false);
            this.lastName_A_and_CToolStrip.PerformLayout();
            this._2BToolStrip.ResumeLayout(false);
            this._2BToolStrip.PerformLayout();
            this.firstName_ConsonantToolStrip.ResumeLayout(false);
            this.firstName_ConsonantToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private Database01DataSet database01DataSet;
        private System.Windows.Forms.BindingSource studentBindingSource;
        private Database01DataSetTableAdapters.StudentTableAdapter studentTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn middlenameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn programDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStrip refreshToolStrip;
        private System.Windows.Forms.ToolStripButton refreshToolStripButton;
        private System.Windows.Forms.ToolStrip bSCSToolStrip;
        private System.Windows.Forms.ToolStripButton bSCSToolStripButton;
        private System.Windows.Forms.ToolStrip bSITToolStrip;
        private System.Windows.Forms.ToolStripButton bSITToolStripButton;
        private System.Windows.Forms.ToolStrip resident_SamalToolStrip;
        private System.Windows.Forms.ToolStripButton resident_SamalToolStripButton;
        private System.Windows.Forms.ToolStrip _2ndYr_StudToolStrip;
        private System.Windows.Forms.ToolStripButton _2ndYr_StudToolStripButton;
        private System.Windows.Forms.ToolStrip lastName_A_and_CToolStrip;
        private System.Windows.Forms.ToolStripButton lastName_A_and_CToolStripButton;
        private System.Windows.Forms.ToolStrip _2BToolStrip;
        private System.Windows.Forms.ToolStripButton _2BToolStripButton;
        private System.Windows.Forms.ToolStrip firstName_ConsonantToolStrip;
        private System.Windows.Forms.ToolStripButton firstName_ConsonantToolStripButton;
    }
}

