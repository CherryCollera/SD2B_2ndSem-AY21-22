﻿/*
 20-01076
Noel M. Gallo Jr.
SD2B
April 7, 2022
This program will input and display a name
 */
using System;

namespace Sample3_InputMyName
{

    class InputMyName
    {

        public static void Main(string[] args)
        {
            System.Console.Write("Insert Fullname (Firstname Lastname): ");
            string Fname = Console.ReadLine();

            System.Console.WriteLine("\nHello {0} !!!", Fname);
            System.Console.WriteLine("Welcome to OOP Environment");


            System.Console.ReadKey();
        }

    }
}