﻿//This Program will display do-while loop

using System;

namespace DoWhile_Casaña
{
    class DoWhile
    {
        static void Main(string[] args)
        {
            //initialize integer array
            int[] ArrayInt = new int[] { 6, 7, 8, 10 };
            int ArraySum = 0;
            int i = 0;

            //loop while i is less than 4
            do
            {
                ArraySum += ArrayInt[i]; //computing the sum of every elements in the array
                i++;
            } while (i < 4);
            
            //Display the sum of all the elements in the array
            Console.WriteLine(ArraySum);
            Console.ReadKey();
        }
    }
}
