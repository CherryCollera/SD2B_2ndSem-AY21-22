﻿//This program will display my Profile

using System;

namespace MyProfile_SESE
{
    class MyProfile
    {
        static void Main(string[] args)
        {
            Console.Write("\tName: " + "Regie A. Sese\n\n");
            Console.WriteLine("\tDate of Birth: " + "September 14, 2001\n");
            Console.WriteLine("\tCourse: " + "BS in Computer Science major in Software Development\n");
            Console.WriteLine("\tYear: " + "II\n");
            Console.WriteLine("\tSection: " + "SD2B\n");
            Console.ReadLine();
        }
    }
}
