﻿using System;

namespace BasicOperations_Manansala_Francisco_Cruz
{
    class Program
    {
        static void Main(string[] args)
        {
            Input input = new Input();
            input.InputValues();

            Sum sum = new Sum();
            sum.ComputeSum();
            Console.WriteLine("\nSum\t\t=\t{0}", DeclareVar.sum);

            Difference difference = new Difference();
            difference.ComputeDifference();
            Console.WriteLine("Difference\t=\t{0}", DeclareVar.difference);

            Product product = new Product();
            product.ComputeProduct();
            Console.WriteLine("Product\t\t=\t{0}", DeclareVar.product);

            Quotient quotient = new Quotient();
            quotient.ComputeQuotient();
            Console.WriteLine("Quotient\t=\t{0}", DeclareVar.quotient);

            Remainder remainder = new Remainder();
            remainder.ComputeRemainder();
            Console.WriteLine("Remainder\t=\t{0}", DeclareVar.remainder);
            Console.ReadLine();
        }
    }
}
