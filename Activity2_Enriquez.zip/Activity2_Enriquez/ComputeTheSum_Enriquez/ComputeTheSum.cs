﻿/* 20 - 01484
 John Brix B. Enriquez
 SD2B
 April 5, 2022
 This program will display sum of two number*/

using System;
namespace ComputeTheSum
{
    class ComputeTheSum
    {
        static void Main(string[] args)
        {
           int num1, num2;
            Console.Write("Enter the first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Sum: {0}", num1 + num2);
            Console.ReadKey();

        }
    }
}