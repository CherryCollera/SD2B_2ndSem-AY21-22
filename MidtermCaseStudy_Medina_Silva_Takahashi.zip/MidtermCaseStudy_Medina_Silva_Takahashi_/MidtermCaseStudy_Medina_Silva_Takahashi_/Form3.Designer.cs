﻿
namespace MidtermCaseStudy_Medina_Silva_Takahashi_
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.btnInt = new System.Windows.Forms.Button();
            this.btnFloat = new System.Windows.Forms.Button();
            this.btnDouble = new System.Windows.Forms.Button();
            this.lbl1stNum = new System.Windows.Forms.Label();
            this.lbl2ndNum = new System.Windows.Forms.Label();
            this.txt1stNum = new System.Windows.Forms.TextBox();
            this.txt2ndNum = new System.Windows.Forms.TextBox();
            this.btnComputeSum = new System.Windows.Forms.Button();
            this.btnToCalcu = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnInt
            // 
            this.btnInt.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnInt.Location = new System.Drawing.Point(25, 35);
            this.btnInt.Name = "btnInt";
            this.btnInt.Size = new System.Drawing.Size(187, 43);
            this.btnInt.TabIndex = 0;
            this.btnInt.Text = "Integer";
            this.btnInt.UseVisualStyleBackColor = true;
            this.btnInt.Click += new System.EventHandler(this.btnInt_Click);
            // 
            // btnFloat
            // 
            this.btnFloat.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFloat.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnFloat.Location = new System.Drawing.Point(274, 35);
            this.btnFloat.Name = "btnFloat";
            this.btnFloat.Size = new System.Drawing.Size(187, 43);
            this.btnFloat.TabIndex = 0;
            this.btnFloat.Text = "Float";
            this.btnFloat.UseVisualStyleBackColor = true;
            this.btnFloat.Click += new System.EventHandler(this.btnFloat_Click);
            // 
            // btnDouble
            // 
            this.btnDouble.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDouble.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnDouble.Location = new System.Drawing.Point(513, 35);
            this.btnDouble.Name = "btnDouble";
            this.btnDouble.Size = new System.Drawing.Size(187, 43);
            this.btnDouble.TabIndex = 0;
            this.btnDouble.Text = "Double";
            this.btnDouble.UseVisualStyleBackColor = true;
            this.btnDouble.Click += new System.EventHandler(this.btnDouble_Click);
            // 
            // lbl1stNum
            // 
            this.lbl1stNum.AutoSize = true;
            this.lbl1stNum.BackColor = System.Drawing.Color.Transparent;
            this.lbl1stNum.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1stNum.ForeColor = System.Drawing.Color.White;
            this.lbl1stNum.Location = new System.Drawing.Point(26, 151);
            this.lbl1stNum.Name = "lbl1stNum";
            this.lbl1stNum.Size = new System.Drawing.Size(157, 17);
            this.lbl1stNum.TabIndex = 1;
            this.lbl1stNum.Text = "Enter First Number";
            // 
            // lbl2ndNum
            // 
            this.lbl2ndNum.AutoSize = true;
            this.lbl2ndNum.BackColor = System.Drawing.Color.Transparent;
            this.lbl2ndNum.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2ndNum.ForeColor = System.Drawing.Color.White;
            this.lbl2ndNum.Location = new System.Drawing.Point(365, 151);
            this.lbl2ndNum.Name = "lbl2ndNum";
            this.lbl2ndNum.Size = new System.Drawing.Size(179, 17);
            this.lbl2ndNum.TabIndex = 1;
            this.lbl2ndNum.Text = "Enter Second Number";
            // 
            // txt1stNum
            // 
            this.txt1stNum.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txt1stNum.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt1stNum.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txt1stNum.Location = new System.Drawing.Point(185, 146);
            this.txt1stNum.Multiline = true;
            this.txt1stNum.Name = "txt1stNum";
            this.txt1stNum.Size = new System.Drawing.Size(121, 43);
            this.txt1stNum.TabIndex = 2;
            this.txt1stNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt1stNum.UseWaitCursor = true;
            // 
            // txt2ndNum
            // 
            this.txt2ndNum.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txt2ndNum.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt2ndNum.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txt2ndNum.Location = new System.Drawing.Point(550, 146);
            this.txt2ndNum.Multiline = true;
            this.txt2ndNum.Name = "txt2ndNum";
            this.txt2ndNum.Size = new System.Drawing.Size(121, 43);
            this.txt2ndNum.TabIndex = 2;
            this.txt2ndNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt2ndNum.TextChanged += new System.EventHandler(this.txt2ndNum_TextChanged);
            // 
            // btnComputeSum
            // 
            this.btnComputeSum.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComputeSum.ForeColor = System.Drawing.Color.IndianRed;
            this.btnComputeSum.Location = new System.Drawing.Point(274, 207);
            this.btnComputeSum.Name = "btnComputeSum";
            this.btnComputeSum.Size = new System.Drawing.Size(187, 43);
            this.btnComputeSum.TabIndex = 0;
            this.btnComputeSum.Text = "Compute Sum";
            this.btnComputeSum.UseVisualStyleBackColor = true;
            this.btnComputeSum.Click += new System.EventHandler(this.btnComputeSum_Click);
            // 
            // btnToCalcu
            // 
            this.btnToCalcu.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnToCalcu.ForeColor = System.Drawing.Color.IndianRed;
            this.btnToCalcu.Location = new System.Drawing.Point(315, 269);
            this.btnToCalcu.Name = "btnToCalcu";
            this.btnToCalcu.Size = new System.Drawing.Size(107, 30);
            this.btnToCalcu.TabIndex = 3;
            this.btnToCalcu.Text = "Calculator";
            this.btnToCalcu.UseVisualStyleBackColor = true;
            this.btnToCalcu.Click += new System.EventHandler(this.btnToCalcu_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(725, 349);
            this.Controls.Add(this.btnToCalcu);
            this.Controls.Add(this.txt2ndNum);
            this.Controls.Add(this.txt1stNum);
            this.Controls.Add(this.lbl2ndNum);
            this.Controls.Add(this.lbl1stNum);
            this.Controls.Add(this.btnDouble);
            this.Controls.Add(this.btnComputeSum);
            this.Controls.Add(this.btnFloat);
            this.Controls.Add(this.btnInt);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInt;
        private System.Windows.Forms.Button btnFloat;
        private System.Windows.Forms.Button btnDouble;
        private System.Windows.Forms.Label lbl1stNum;
        private System.Windows.Forms.Label lbl2ndNum;
        private System.Windows.Forms.TextBox txt1stNum;
        private System.Windows.Forms.TextBox txt2ndNum;
        private System.Windows.Forms.Button btnComputeSum;
        private System.Windows.Forms.Button btnToCalcu;
    }
}