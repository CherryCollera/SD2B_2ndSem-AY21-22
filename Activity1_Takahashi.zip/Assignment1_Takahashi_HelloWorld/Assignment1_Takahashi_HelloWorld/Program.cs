﻿/*
 * 20-01726
 * Aira M Takahashi
 * SD2A
 */

using System;

namespace Assignment1_Takahashi_HelloWorld
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World!");
            System.Console.ReadKey();
        }
    }
}
