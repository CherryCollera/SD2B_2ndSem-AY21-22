﻿using System;

namespace MyProfile_Manansala
{
    class MyProfile
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\tName: " + "Arnie James H. Manansala\n");
            Console.WriteLine("\tDate of Birth: " + "May 11, 2002\n");
            Console.WriteLine("\tCourse: " + "B.S. in Computer Science major in Software Development\n");
            Console.WriteLine("\tYear: " + "2nd\n");
            Console.WriteLine("\tSection: " + "SD2B\n");
            Console.ReadKey();
        }
    }
}
