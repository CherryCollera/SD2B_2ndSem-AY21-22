﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Carlos_Diego_Sarmiento
{
    class Print
    {
        public void PrintDetails()
        {
            Accept a = new Accept();
            a.AcceptDetails();
            System.Console.Write("Hello " + a.name
                + "\nYou have created classes in OOP");
            MyProfile myp = new MyProfile();
            myp.DisplayProfile();
        }
    }
}
