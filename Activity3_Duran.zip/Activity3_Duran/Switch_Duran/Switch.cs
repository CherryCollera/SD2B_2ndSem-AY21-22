﻿using System;

namespace Switch_Duran
{
    class Switch
    {
        static void Main(string[] args)
        {
            String name;
            char gender;

            Console.Write("Enter your Name: ");
            name = Console.ReadLine();
            Console.Write("Enter your gender(M/F): ");
            gender = Convert.ToChar(Console.ReadLine());

            switch (gender)
            {
                case 'M':
                case 'm':
                    Console.WriteLine("\n Hello, " + name + "!"
                        + (" Welcome to the Male Community!"));
                    break;

                case 'F':
                case 'f':
                    Console.WriteLine("\n Hello, " + name + "!"
                        + (" Welcome to the Female Community!"));
                    break;

                default:
                    Console.WriteLine("\nInvalid input. Please try again and put the correct elements needed");
                    break;
            }
        }
    }
}
