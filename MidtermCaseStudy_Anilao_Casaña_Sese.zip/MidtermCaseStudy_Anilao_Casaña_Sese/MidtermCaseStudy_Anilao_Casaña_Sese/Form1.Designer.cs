﻿
namespace MidtermCaseStudy_Anilao_Casaña_Sese
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.msgButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // msgButton
            // 
            this.msgButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.msgButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.msgButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msgButton.Location = new System.Drawing.Point(87, 80);
            this.msgButton.Name = "msgButton";
            this.msgButton.Size = new System.Drawing.Size(150, 50);
            this.msgButton.TabIndex = 0;
            this.msgButton.Text = "Message";
            this.msgButton.UseVisualStyleBackColor = false;
            this.msgButton.Click += new System.EventHandler(this.msgButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(336, 211);
            this.Controls.Add(this.msgButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button msgButton;
    }
}

