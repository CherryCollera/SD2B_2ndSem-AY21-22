﻿/*20-02190 
Borboran, Keanu Dave E.
SD2B
March 29, 2022
This program will let the user input his/her name and show the output to the user*/

using System;

namespace Sample3_Borboran
{
    class userInput
    {
        static void Main(string[]args)
        {
            System.Console.WriteLine("Enter your name (firstname lastname): ");
            String name = Console.ReadLine();
            System.Console.WriteLine("");
            System.Console.WriteLine(" Hello " +name+ "!!!");
            System.Console.WriteLine(" Welcome to OOP Environment.");

            System.Console.ReadKey();
        }
    }
}