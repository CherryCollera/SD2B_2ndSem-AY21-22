﻿using System;

namespace ClassExample1_Duran_Fabian_Cruz
{
    class Program
    {
        static void Main(string[] args)
        {
            Print p = new Print();
            p.PrintDetails();
            Console.ReadLine();
        }
    }
}
