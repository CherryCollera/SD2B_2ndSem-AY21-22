﻿/*20-00903
Regie A. Sese
SD2B
March 22, 2022
This Program will display the name that I will input*/

using System;

namespace Sample3_InputMyName
{
    class InputMyName
    {
        static void Main(string[] args)
        {
            //Enter your firstname and lastname
            System.Console.Write("Enter your Name <Firstname Lastname> : ");
            string name = Console.ReadLine();

            //Display your name
            Console.WriteLine("\nHello " + name + " !!!"
                + "\nWelcome to OOP Environment.");
            System.Console.ReadKey();
        }
    }
}