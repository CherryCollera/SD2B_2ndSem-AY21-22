﻿namespace DataGridView_Lazoo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.refreshToolStrip = new System.Windows.Forms.ToolStrip();
            this.refreshToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lastName_AToolStrip = new System.Windows.Forms.ToolStrip();
            this.lastName_AToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.middleNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.table1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.database_LazoDataSet = new DataGridView_Lazoo.Database_LazoDataSet();
            this.table1TableAdapter = new DataGridView_Lazoo.Database_LazoDataSetTableAdapters.Table1TableAdapter();
            this.bscs_students2ToolStrip = new System.Windows.Forms.ToolStrip();
            this.bscs_students2ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.bsit_studentsToolStrip = new System.Windows.Forms.ToolStrip();
            this.bsit_studentsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.address_SamalToolStrip = new System.Windows.Forms.ToolStrip();
            this.address_SamalToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.secondYearToolStrip = new System.Windows.Forms.ToolStrip();
            this.secondYearToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.starts_A_CToolStrip = new System.Windows.Forms.ToolStrip();
            this.starts_A_CToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.section_2BToolStrip = new System.Windows.Forms.ToolStrip();
            this.section_2BToolStripButton = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.refreshToolStrip.SuspendLayout();
            this.lastName_AToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.table1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database_LazoDataSet)).BeginInit();
            this.bscs_students2ToolStrip.SuspendLayout();
            this.bsit_studentsToolStrip.SuspendLayout();
            this.address_SamalToolStrip.SuspendLayout();
            this.secondYearToolStrip.SuspendLayout();
            this.starts_A_CToolStrip.SuspendLayout();
            this.section_2BToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.middleNameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.birthdayDataGridViewTextBoxColumn,
            this.programDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.table1BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(42, 61);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(809, 328);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // refreshToolStrip
            // 
            this.refreshToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.refreshToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshToolStripButton});
            this.refreshToolStrip.Location = new System.Drawing.Point(19, 401);
            this.refreshToolStrip.Name = "refreshToolStrip";
            this.refreshToolStrip.Size = new System.Drawing.Size(59, 25);
            this.refreshToolStrip.TabIndex = 1;
            this.refreshToolStrip.Text = "refreshToolStrip";
            // 
            // refreshToolStripButton
            // 
            this.refreshToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.refreshToolStripButton.Name = "refreshToolStripButton";
            this.refreshToolStripButton.Size = new System.Drawing.Size(47, 22);
            this.refreshToolStripButton.Text = "refresh";
            this.refreshToolStripButton.Click += new System.EventHandler(this.refreshToolStripButton_Click);
            // 
            // lastName_AToolStrip
            // 
            this.lastName_AToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.lastName_AToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lastName_AToolStripButton});
            this.lastName_AToolStrip.Location = new System.Drawing.Point(98, 401);
            this.lastName_AToolStrip.Name = "lastName_AToolStrip";
            this.lastName_AToolStrip.Size = new System.Drawing.Size(89, 25);
            this.lastName_AToolStrip.TabIndex = 2;
            this.lastName_AToolStrip.Text = "lastName_AToolStrip";
            this.lastName_AToolStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.lastName_AToolStrip_ItemClicked);
            // 
            // lastName_AToolStripButton
            // 
            this.lastName_AToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lastName_AToolStripButton.Name = "lastName_AToolStripButton";
            this.lastName_AToolStripButton.Size = new System.Drawing.Size(77, 22);
            this.lastName_AToolStripButton.Text = "LastName_A";
            this.lastName_AToolStripButton.Click += new System.EventHandler(this.lastName_AToolStripButton_Click);
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // middleNameDataGridViewTextBoxColumn
            // 
            this.middleNameDataGridViewTextBoxColumn.DataPropertyName = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.HeaderText = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.Name = "middleNameDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // birthdayDataGridViewTextBoxColumn
            // 
            this.birthdayDataGridViewTextBoxColumn.DataPropertyName = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.HeaderText = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.Name = "birthdayDataGridViewTextBoxColumn";
            // 
            // programDataGridViewTextBoxColumn
            // 
            this.programDataGridViewTextBoxColumn.DataPropertyName = "Program";
            this.programDataGridViewTextBoxColumn.HeaderText = "Program";
            this.programDataGridViewTextBoxColumn.Name = "programDataGridViewTextBoxColumn";
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            // 
            // table1BindingSource
            // 
            this.table1BindingSource.DataMember = "Table1";
            this.table1BindingSource.DataSource = this.database_LazoDataSet;
            // 
            // database_LazoDataSet
            // 
            this.database_LazoDataSet.DataSetName = "Database_LazoDataSet";
            this.database_LazoDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // table1TableAdapter
            // 
            this.table1TableAdapter.ClearBeforeFill = true;
            // 
            // bscs_students2ToolStrip
            // 
            this.bscs_students2ToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bscs_students2ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bscs_students2ToolStripButton});
            this.bscs_students2ToolStrip.Location = new System.Drawing.Point(200, 401);
            this.bscs_students2ToolStrip.Name = "bscs_students2ToolStrip";
            this.bscs_students2ToolStrip.Size = new System.Drawing.Size(102, 25);
            this.bscs_students2ToolStrip.TabIndex = 3;
            this.bscs_students2ToolStrip.Text = "bscs_students2ToolStrip";
            // 
            // bscs_students2ToolStripButton
            // 
            this.bscs_students2ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bscs_students2ToolStripButton.Name = "bscs_students2ToolStripButton";
            this.bscs_students2ToolStripButton.Size = new System.Drawing.Size(90, 22);
            this.bscs_students2ToolStripButton.Text = "bscs_students2";
            this.bscs_students2ToolStripButton.Click += new System.EventHandler(this.bscs_students2ToolStripButton_Click);
            // 
            // bsit_studentsToolStrip
            // 
            this.bsit_studentsToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bsit_studentsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bsit_studentsToolStripButton});
            this.bsit_studentsToolStrip.Location = new System.Drawing.Point(318, 401);
            this.bsit_studentsToolStrip.Name = "bsit_studentsToolStrip";
            this.bsit_studentsToolStrip.Size = new System.Drawing.Size(92, 25);
            this.bsit_studentsToolStrip.TabIndex = 4;
            this.bsit_studentsToolStrip.Text = "bsit_studentsToolStrip";
            // 
            // bsit_studentsToolStripButton
            // 
            this.bsit_studentsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bsit_studentsToolStripButton.Name = "bsit_studentsToolStripButton";
            this.bsit_studentsToolStripButton.Size = new System.Drawing.Size(80, 22);
            this.bsit_studentsToolStripButton.Text = "bsit_students";
            this.bsit_studentsToolStripButton.Click += new System.EventHandler(this.bsit_studentsToolStripButton_Click);
            // 
            // address_SamalToolStrip
            // 
            this.address_SamalToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.address_SamalToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.address_SamalToolStripButton});
            this.address_SamalToolStrip.Location = new System.Drawing.Point(410, 401);
            this.address_SamalToolStrip.Name = "address_SamalToolStrip";
            this.address_SamalToolStrip.Size = new System.Drawing.Size(102, 25);
            this.address_SamalToolStrip.TabIndex = 5;
            this.address_SamalToolStrip.Text = "address_SamalToolStrip";
            // 
            // address_SamalToolStripButton
            // 
            this.address_SamalToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.address_SamalToolStripButton.Name = "address_SamalToolStripButton";
            this.address_SamalToolStripButton.Size = new System.Drawing.Size(90, 22);
            this.address_SamalToolStripButton.Text = "Address_Samal";
            this.address_SamalToolStripButton.Click += new System.EventHandler(this.address_SamalToolStripButton_Click);
            // 
            // secondYearToolStrip
            // 
            this.secondYearToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.secondYearToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.secondYearToolStripButton});
            this.secondYearToolStrip.Location = new System.Drawing.Point(521, 401);
            this.secondYearToolStrip.Name = "secondYearToolStrip";
            this.secondYearToolStrip.Size = new System.Drawing.Size(83, 25);
            this.secondYearToolStrip.TabIndex = 6;
            this.secondYearToolStrip.Text = "secondYearToolStrip";
            // 
            // secondYearToolStripButton
            // 
            this.secondYearToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.secondYearToolStripButton.Name = "secondYearToolStripButton";
            this.secondYearToolStripButton.Size = new System.Drawing.Size(71, 22);
            this.secondYearToolStripButton.Text = "secondYear";
            this.secondYearToolStripButton.Click += new System.EventHandler(this.secondYearToolStripButton_Click);
            // 
            // starts_A_CToolStrip
            // 
            this.starts_A_CToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.starts_A_CToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.starts_A_CToolStripButton});
            this.starts_A_CToolStrip.Location = new System.Drawing.Point(613, 401);
            this.starts_A_CToolStrip.Name = "starts_A_CToolStrip";
            this.starts_A_CToolStrip.Size = new System.Drawing.Size(77, 25);
            this.starts_A_CToolStrip.TabIndex = 7;
            this.starts_A_CToolStrip.Text = "starts_A_CToolStrip";
            // 
            // starts_A_CToolStripButton
            // 
            this.starts_A_CToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.starts_A_CToolStripButton.Name = "starts_A_CToolStripButton";
            this.starts_A_CToolStripButton.Size = new System.Drawing.Size(65, 22);
            this.starts_A_CToolStripButton.Text = "starts_A_C";
            this.starts_A_CToolStripButton.Click += new System.EventHandler(this.starts_A_CToolStripButton_Click);
            // 
            // section_2BToolStrip
            // 
            this.section_2BToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.section_2BToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.section_2BToolStripButton});
            this.section_2BToolStrip.Location = new System.Drawing.Point(702, 401);
            this.section_2BToolStrip.Name = "section_2BToolStrip";
            this.section_2BToolStrip.Size = new System.Drawing.Size(80, 25);
            this.section_2BToolStrip.TabIndex = 8;
            this.section_2BToolStrip.Text = "section_2BToolStrip";
            // 
            // section_2BToolStripButton
            // 
            this.section_2BToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.section_2BToolStripButton.Name = "section_2BToolStripButton";
            this.section_2BToolStripButton.Size = new System.Drawing.Size(68, 22);
            this.section_2BToolStripButton.Text = "Section_2B";
            this.section_2BToolStripButton.Click += new System.EventHandler(this.section_2BToolStripButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(875, 458);
            this.Controls.Add(this.section_2BToolStrip);
            this.Controls.Add(this.starts_A_CToolStrip);
            this.Controls.Add(this.secondYearToolStrip);
            this.Controls.Add(this.address_SamalToolStrip);
            this.Controls.Add(this.bsit_studentsToolStrip);
            this.Controls.Add(this.bscs_students2ToolStrip);
            this.Controls.Add(this.lastName_AToolStrip);
            this.Controls.Add(this.refreshToolStrip);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Activity 6";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.refreshToolStrip.ResumeLayout(false);
            this.refreshToolStrip.PerformLayout();
            this.lastName_AToolStrip.ResumeLayout(false);
            this.lastName_AToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.table1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database_LazoDataSet)).EndInit();
            this.bscs_students2ToolStrip.ResumeLayout(false);
            this.bscs_students2ToolStrip.PerformLayout();
            this.bsit_studentsToolStrip.ResumeLayout(false);
            this.bsit_studentsToolStrip.PerformLayout();
            this.address_SamalToolStrip.ResumeLayout(false);
            this.address_SamalToolStrip.PerformLayout();
            this.secondYearToolStrip.ResumeLayout(false);
            this.secondYearToolStrip.PerformLayout();
            this.starts_A_CToolStrip.ResumeLayout(false);
            this.starts_A_CToolStrip.PerformLayout();
            this.section_2BToolStrip.ResumeLayout(false);
            this.section_2BToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private Database_LazoDataSet database_LazoDataSet;
        private System.Windows.Forms.BindingSource table1BindingSource;
        private Database_LazoDataSetTableAdapters.Table1TableAdapter table1TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn middleNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn programDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStrip refreshToolStrip;
        private System.Windows.Forms.ToolStripButton refreshToolStripButton;
        private System.Windows.Forms.ToolStrip lastName_AToolStrip;
        private System.Windows.Forms.ToolStripButton lastName_AToolStripButton;
        private System.Windows.Forms.ToolStrip bscs_students2ToolStrip;
        private System.Windows.Forms.ToolStripButton bscs_students2ToolStripButton;
        private System.Windows.Forms.ToolStrip bsit_studentsToolStrip;
        private System.Windows.Forms.ToolStripButton bsit_studentsToolStripButton;
        private System.Windows.Forms.ToolStrip address_SamalToolStrip;
        private System.Windows.Forms.ToolStripButton address_SamalToolStripButton;
        private System.Windows.Forms.ToolStrip secondYearToolStrip;
        private System.Windows.Forms.ToolStripButton secondYearToolStripButton;
        private System.Windows.Forms.ToolStrip starts_A_CToolStrip;
        private System.Windows.Forms.ToolStripButton starts_A_CToolStripButton;
        private System.Windows.Forms.ToolStrip section_2BToolStrip;
        private System.Windows.Forms.ToolStripButton section_2BToolStripButton;
    }
}

