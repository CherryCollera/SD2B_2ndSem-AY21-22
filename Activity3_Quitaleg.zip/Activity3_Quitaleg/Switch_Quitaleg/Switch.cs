﻿/*
20-02604
Jaycee Audrei Mari M. Quitaleg
SD2B
April 08, 2022
This program will determine if the user is Male or Female using Switch statements.
 */

using System;

namespace For_Quitaleg
{
    class For_Quitaleg
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your name: ");
            string name = Console.ReadLine();
            Console.Write("Enter your gender (M/F): ");
            char gender = Convert.ToChar(Console.ReadLine());

            switch (gender)
            {
                case 'M': case 'm':
                    Console.WriteLine("\nHi " + name + "! Your gender is Male!");
                    break;

                case 'F': case 'f':
                    Console.WriteLine("\nHi " + name + "! Your gender is Female!");
                    break;
                
                default:
                    Console.WriteLine("\nInvalid input. Please try again.");
                    break;
            }
            Console.ReadKey();
        }
    }
}
