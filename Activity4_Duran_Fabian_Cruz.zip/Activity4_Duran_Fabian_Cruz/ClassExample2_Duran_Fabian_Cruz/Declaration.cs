﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassExample2_Duran_Fabian_Cruz
{
    class Declaration
    {
        public string Color
        {
            get
            {
                return Color;
            }
            set
            {
                Color = value;
            }
        }
    }
}
