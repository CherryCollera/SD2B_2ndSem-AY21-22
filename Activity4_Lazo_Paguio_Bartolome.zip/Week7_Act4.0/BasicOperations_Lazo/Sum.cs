class Sum{
    public void computeSum(){
        DeclareVar.sum = DeclareVar.num1 + DeclareVar.num2;
    }
}