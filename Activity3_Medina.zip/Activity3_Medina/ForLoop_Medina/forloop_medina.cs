﻿/*  20-01732
    Angelica D. Medina

    BSCSSD-2B
    April 17, 2022

This program will perform a for loop and it will repeat for 10 times.
*/


using System;

namespace ForLoop_Medina
{
    class forloop_medina
    {
        static void Main(string[] args)
        {
            for (int k = 10 - 1; k >= 0; k--)
            {
                Console.WriteLine(k);
            }

            Console.ReadKey();
        }
    }
}
