﻿using System;

namespace Sample3_InputMyName
{
    class ArnieJamesManansala
    {
        static void Main(string[] args)
        {
            String fullname;
            Console.Write("Enter your Name:" +
                "(Firstname Lastname) ");
            fullname = Console.ReadLine();
            
            Console.WriteLine("\nHello " + fullname
                + "!!!\n" + "Welcome to OOP Environment.");
            Console.ReadKey();
        }
    }
}
