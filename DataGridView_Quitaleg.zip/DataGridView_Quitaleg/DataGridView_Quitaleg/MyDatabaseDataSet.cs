﻿namespace DataGridView_Quitaleg
{


    partial class MyDatabaseDataSet
    {
    }
}
