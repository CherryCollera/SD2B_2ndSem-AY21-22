﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity6_Medina
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'activity6_DB_MedinaDataSet.tblStudents' table. You can move, or remove it, as needed.
            this.tblStudentsTableAdapter.Fill(this.activity6_DB_MedinaDataSet.tblStudents);

        }

        private void tblStudentsBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void refreshToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.tblStudentsTableAdapter.refresh(this.activity6_DB_MedinaDataSet.tblStudents);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void refreshToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void bSCSToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.tblStudentsTableAdapter.BSCS(this.activity6_DB_MedinaDataSet.tblStudents);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void bSCSToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void bSITToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.tblStudentsTableAdapter.BSIT(this.activity6_DB_MedinaDataSet.tblStudents);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void lastName_A_CToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.tblStudentsTableAdapter.LastName_A_C(this.activity6_DB_MedinaDataSet.tblStudents);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void sECTION_2BToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.tblStudentsTableAdapter.SECTION_2B(this.activity6_DB_MedinaDataSet.tblStudents);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void aDDRESS_SAMALToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.tblStudentsTableAdapter.ADDRESS_SAMAL(this.activity6_DB_MedinaDataSet.tblStudents);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void sECOND_YEARToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.tblStudentsTableAdapter.SECOND_YEAR(this.activity6_DB_MedinaDataSet.tblStudents);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void firstName_ConsonantsToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.tblStudentsTableAdapter.FirstName_Consonants(this.activity6_DB_MedinaDataSet.tblStudents);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
