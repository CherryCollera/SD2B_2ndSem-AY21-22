﻿/* 20 - 01484
 John Brix B. Enriquez
 SD2B
 April 5, 2022
 This program will display the my details*/

using System;
namespace MyProfile
{
    class MyProfile
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name: John Brix B. Enriquez\n");
            Console.WriteLine("Date of Birth: September 18\n");
            Console.WriteLine("Course: BS Computer Science Major in Software Development\n");
            Console.WriteLine("Year: II\n");
            Console.WriteLine("Section: SD2B");
            Console.ReadKey();
        }
    }
}