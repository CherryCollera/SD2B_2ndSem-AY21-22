﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Group8_Mendoza
{
     class Accept
    {
        public string firstname, lastname;
        public void AcceptDetails()
        {
            Console.Write("Enter your Firstname and Lastname:\t ");
            firstname = Console.ReadLine();
            lastname = Console.ReadLine();
        }

    }
}
