﻿using System;

namespace ClassExample2_Lazo
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car;
            car = new Car("Red");
            Console.WriteLine(car.Describe());
            car = new Car("Green");
            Console.WriteLine(car.Describe());
            Console.ReadLine();
        }
    }

    class Car
    {

        private string color;

        public Car(string color)
        {
            this.color = color;
        }

        public string Describe()
        {
            return "This car is " + color;
        }
    }

    class Declaration
    {
        public string color
        {
            get
            {
                return color;
            }
            set{
                color = value;
            }
        }
    }
}
