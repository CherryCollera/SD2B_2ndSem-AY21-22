﻿using System;

namespace Do_While
{
    class Program
    {
        static void Main(string[] args)
        {
            int [] arr = new int []{1,2,3,15};
            int sum  = 0;
            int i = 0;
            do{
                sum += arr[i];
                i++;
            }
            while (i<1);
            
            Console.WriteLine(sum);
            
        }
    }
}
