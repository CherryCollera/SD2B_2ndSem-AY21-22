﻿
namespace WindowsFormsApp1_Medina_Silva_Takahashi
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_firstName = new System.Windows.Forms.Label();
            this.lbl_lastName = new System.Windows.Forms.Label();
            this.txt_firstName = new System.Windows.Forms.TextBox();
            this.txt_lastName = new System.Windows.Forms.TextBox();
            this.btn_getMessage2 = new System.Windows.Forms.Button();
            this.btn_hide2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_firstName
            // 
            this.lbl_firstName.AutoSize = true;
            this.lbl_firstName.Font = new System.Drawing.Font("Lucida Console", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_firstName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_firstName.Location = new System.Drawing.Point(27, 39);
            this.lbl_firstName.Name = "lbl_firstName";
            this.lbl_firstName.Size = new System.Drawing.Size(107, 15);
            this.lbl_firstName.TabIndex = 0;
            this.lbl_firstName.Text = "First Name";
            this.lbl_firstName.Click += new System.EventHandler(this.lbl_firstName_Click);
            // 
            // lbl_lastName
            // 
            this.lbl_lastName.AutoSize = true;
            this.lbl_lastName.Font = new System.Drawing.Font("Lucida Console", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_lastName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_lastName.Location = new System.Drawing.Point(27, 88);
            this.lbl_lastName.Name = "lbl_lastName";
            this.lbl_lastName.Size = new System.Drawing.Size(97, 15);
            this.lbl_lastName.TabIndex = 1;
            this.lbl_lastName.Text = "Last Name";
            // 
            // txt_firstName
            // 
            this.txt_firstName.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_firstName.Location = new System.Drawing.Point(140, 29);
            this.txt_firstName.Name = "txt_firstName";
            this.txt_firstName.Size = new System.Drawing.Size(205, 34);
            this.txt_firstName.TabIndex = 2;
            // 
            // txt_lastName
            // 
            this.txt_lastName.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_lastName.Location = new System.Drawing.Point(140, 78);
            this.txt_lastName.Name = "txt_lastName";
            this.txt_lastName.Size = new System.Drawing.Size(205, 34);
            this.txt_lastName.TabIndex = 2;
            // 
            // btn_getMessage2
            // 
            this.btn_getMessage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_getMessage2.Location = new System.Drawing.Point(140, 184);
            this.btn_getMessage2.Name = "btn_getMessage2";
            this.btn_getMessage2.Size = new System.Drawing.Size(114, 29);
            this.btn_getMessage2.TabIndex = 3;
            this.btn_getMessage2.Text = "Get Message";
            this.btn_getMessage2.UseVisualStyleBackColor = true;
            this.btn_getMessage2.Click += new System.EventHandler(this.btn_getMessage2_Click);
            // 
            // btn_hide2
            // 
            this.btn_hide2.Location = new System.Drawing.Point(293, 314);
            this.btn_hide2.Name = "btn_hide2";
            this.btn_hide2.Size = new System.Drawing.Size(75, 23);
            this.btn_hide2.TabIndex = 4;
            this.btn_hide2.Text = "Hide";
            this.btn_hide2.UseVisualStyleBackColor = true;
            this.btn_hide2.Click += new System.EventHandler(this.btn_hide2_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(389, 354);
            this.Controls.Add(this.btn_hide2);
            this.Controls.Add(this.btn_getMessage2);
            this.Controls.Add(this.txt_lastName);
            this.Controls.Add(this.txt_firstName);
            this.Controls.Add(this.lbl_lastName);
            this.Controls.Add(this.lbl_firstName);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_firstName;
        private System.Windows.Forms.Label lbl_lastName;
        private System.Windows.Forms.TextBox txt_firstName;
        private System.Windows.Forms.TextBox txt_lastName;
        private System.Windows.Forms.Button btn_getMessage2;
        private System.Windows.Forms.Button btn_hide2;
    }
}