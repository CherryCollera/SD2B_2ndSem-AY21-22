class Input{

    public void inputValues(){
        System.Console.Write("Enter first number: ");
        DeclareVar.num1 = System.Convert.ToInt32(System.Console.ReadLine());
        System.Console.Write("Enter second number: ");
        DeclareVar.num2 = System.Convert.ToInt32(System.Console.ReadLine());

    }
}