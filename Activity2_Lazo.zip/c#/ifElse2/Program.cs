﻿using System;

namespace ifElse2
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;
            Console.Write("Enter first number:  ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number:  ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter third number:  ");
            num3 = Convert.ToInt32(Console.ReadLine());

            if ((num1 > num2) && (num1 > num3))
            {
                Console.WriteLine(num1 + " is greater than " + num2 + " & " + num3);
            }
            else if ((num2 > num1) && (num2 > num3))
            {
                Console.WriteLine(num2 + " is greater than " + num1 + " & " + num3);
            }
            else
            {
                Console.WriteLine(num3 + " is greater than " + num1 + " & " + num2);
            }
        }
    }
}
