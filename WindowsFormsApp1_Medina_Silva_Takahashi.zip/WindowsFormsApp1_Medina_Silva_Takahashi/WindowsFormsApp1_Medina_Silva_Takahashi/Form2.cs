﻿/* 		Activity #5
 * 		Grp 9
 * 	Members: Medina, Angelica
	   	 Silva, Alyssa Mae
	   	 Takahashi, Aira
 * BSCS-SD2B
 * 05/04/2022*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1_Medina_Silva_Takahashi
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void lbl_firstName_Click(object sender, EventArgs e)
        {

        }

        private void btn_getMessage2_Click(object sender, EventArgs e)
        {
            string Firstname = txt_firstName.Text;
            string Lastname = txt_lastName.Text;

            
            HappyBirthday hb = new HappyBirthday();
       
            MessageBox.Show(hb.GetMessage(Firstname, Lastname));
        }

        private void btn_hide2_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();

            f3.Show();

            this.Hide();
        }
    }
}
