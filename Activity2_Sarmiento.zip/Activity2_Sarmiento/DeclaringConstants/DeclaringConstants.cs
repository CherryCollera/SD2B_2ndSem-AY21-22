﻿/*20-00613
Marian Gillian G. Sarmiento
SD2B
April 5, 2022
This program will declare constants*/

using System;

namespace DeclaringConstants
{
    class DeclaringConstants
    {
        static void Main(string[] args)
        {

            const double pi = 3.14159;
            double radius, AreaCircle;

            Console.Write("Enter Radius: ");
            radius = Convert.ToInt32(Console.ReadLine());

            AreaCircle = pi * radius * radius;
            Console.Write("Radius: {0:0.0000}, ", radius);
            Console.Write("Area: {0:0.0000}", AreaCircle);
            Console.ReadKey();
        }
    }
}
