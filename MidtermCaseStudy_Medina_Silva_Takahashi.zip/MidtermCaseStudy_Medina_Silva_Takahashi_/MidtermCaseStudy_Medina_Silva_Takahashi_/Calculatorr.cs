﻿/* Midterm Case Study Group 9
		<Members>
	Medina, Angelica
	Silva, Alyssa Mae
	Takahashi, Aira

<BSCS SD2B> **/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidtermCaseStudy_Medina_Silva_Takahashi_
{
    public partial class Calculatorr : Form
    {
        double total1 = 0;
        double total2 = 0;
        bool plusButtonClicked = false;
        bool minusButtonClicked = false;
        bool divideButtonClicked = false;
        bool multiplyButtonClicked = false;

        public Calculatorr()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + btn1.Text;
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + btn2.Text;
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + btn3.Text;
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + btn4.Text;
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + btn5.Text;
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + btn6.Text;
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + btn7.Text;
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + btn8.Text;
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + btn9.Text;
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + btn0.Text;
        }

        private void btnPoint_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + btnPoint.Text;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(textBox1.Text);
            textBox1.Clear();

            minusButtonClicked = false;

            plusButtonClicked = true;

            divideButtonClicked = false;

            multiplyButtonClicked = false;
        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(textBox1.Text);
            textBox1.Clear();

            minusButtonClicked = true;

            plusButtonClicked = false;

            divideButtonClicked = false;

            multiplyButtonClicked = false;
        }

        private void btbMultiply_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(textBox1.Text);
            textBox1.Clear();

            minusButtonClicked = false;

            plusButtonClicked = false;

            divideButtonClicked = false;

            multiplyButtonClicked = true;
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(textBox1.Text);
            textBox1.Clear();

            minusButtonClicked = false;

            plusButtonClicked = false;

            divideButtonClicked = true;

            multiplyButtonClicked = false;
        }

        private void btnBackF1_Click(object sender, EventArgs e)
        {
            Form1 back = new Form1();
            back.Show();
            this.Hide();
        }

        private void btnGoF3_Click(object sender, EventArgs e)
        {
            Form3 go = new Form3();
            go.Show();
            this.Hide();
        }

        private void btnEquals_Click(object sender, EventArgs e)
        {
            if (plusButtonClicked == true)

            {

                total2 = total1 + double.Parse(textBox1.Text);

            }

            else if (minusButtonClicked == true)

            {

                total2 = total1 - double.Parse(textBox1.Text);

            }

            else if (multiplyButtonClicked == true)

            {

                total2 = total1 * double.Parse(textBox1.Text);

            }

            else if (divideButtonClicked == true)

            {
                total2 = total1 / double.Parse(textBox1.Text);

            }

            textBox1.Text = total2.ToString(); total1 = 0;
        }
    }
}
