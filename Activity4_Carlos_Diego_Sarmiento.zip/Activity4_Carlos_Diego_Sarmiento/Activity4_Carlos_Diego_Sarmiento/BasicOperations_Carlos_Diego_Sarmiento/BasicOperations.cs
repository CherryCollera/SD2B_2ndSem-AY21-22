﻿/* Creating classes in OOP
 * Group Members : Roiel A. Carlos
 *                 Angelo R. Diego
 *                 Marian Gillian G. Sarmiento
 * Date: April 25, 2022
 * This program will perform the basic operations using multiple classes.
 */

using System;

namespace BasicOperations_Carlos_Diego_Sarmiento
{
    class BasicOperations
    {
        static void Main(string[] args)
        {
            Input input = new Input();
            input.getNum();

            Sum sum = new Sum();
            sum.computeSum();

            Difference diff = new Difference();
            diff.computeDiff();

            Product prod = new Product();
            prod.computeProduct();

            Quotient quot = new Quotient();
            quot.computeQuotient();

            Remainder rem = new Remainder();
            rem.getRemainder();

            Console.ReadKey();
        }
    }
}
