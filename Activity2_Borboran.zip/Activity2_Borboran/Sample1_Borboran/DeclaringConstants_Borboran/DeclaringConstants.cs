﻿/*20-02190
 Borboran, Keanu Dave
This program will declare constants*/

using System;

namespace DeclaringConstants_Borboran
{
    class DeclaringConstants
    {
        static void Main(string[] args)
        {
            const double pi = 3.14159;
            Double rds, areaC;

            Console.Write("Enter Radius: ");
            rds = Convert.ToDouble(Console.ReadLine());

           areaC = pi * rds * rds;

           Console.Write("Radius: {0:0.0000}, ", rds);
           Console.Write("Area: {0:0.0000}", areaC);
           Console.ReadLine();
        }
    }
}