﻿/* 	ACTIVITY4_Grp9			
	BSCS SD2B

GrpMembers:	Medina, Angelica D
		    Silva, Alyssa MaeT. 
		    Takahashi, Aira M.

Date:   04-27-2022
 */

using System;

namespace BasicOperations_Medina
{
    class Program
    {
        static void Main(string[] args)
        {
            
                
                Input input = new Input();  //object for class "Input"
                input.InputValues();        //calling the method "InputValues()" from class Input

                Difference dd = new Difference();  //object for class "Difference"
                dd.ComputeDifference();            //calling the method "ComputeDifference()" from class Difference

                Sum ss = new Sum();    //object for class "Sum"
                ss.ComputeSum();       //calling the method "ComputeSum()" from class Sum

                Product pp = new Product();    //object for class "Product"
                pp.ComputeProduct();           //calling the method "ComputeProduct()" from class Product

                Quotient qq = new Quotient(); //object for class "Quotient"
                qq.ComputeQuotient();         //calling the method "ComputeQuotient()" from class Quotient

                Remainder rr = new Remainder();  //object for class "Remainder"
                rr.ComputeRemainder();           //calling the method "ComputeRemainder()" from class Remainder

                //display answers of all basic operation
                Console.WriteLine("\n\n\n\tDifference =  " + DeclareVar.diff);
                Console.WriteLine("\tSum =  " + DeclareVar.sum);
                Console.WriteLine("\tProduct =  " + DeclareVar.prod);
                Console.WriteLine("\tQuotient =  " + DeclareVar.quotient);
                Console.WriteLine("\tRemainder =  " + DeclareVar.r);
                Console.ReadKey();
            }
        }
    }

