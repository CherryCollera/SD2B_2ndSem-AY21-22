﻿/*
 * student Id number : 20-05258
 * student full name : Zedrick A. Mojica
 * Section : BSCS-SD2B
 * Date : 04/04/2022
 * Purpose : compare two numbers to check what is larger
 */
using System;

namespace Activity2_Mojica
{
    class IfElse1
    {
        static void Main(string[] args)
        {
            int num1, num2;
            System.Console.Write("Enter first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            System.Console.Write("Enter second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            if (num1 > num2)
            {
                System.Console.Write(num1 + " is greater than " + num2);
            }
            else if (num2 > num1)
            {
                System.Console.Write(num2 + " is greater than " + num1);
            }
            else
            {
                System.Console.Write(num2 + " is equal to " + num1);
            }
            System.Console.ReadKey();
        }
    }
}