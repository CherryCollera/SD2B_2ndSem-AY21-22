﻿
namespace Activity6_Medina
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.refreshToolStrip = new System.Windows.Forms.ToolStrip();
            this.refreshToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.bSCSToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSCSToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.bSITToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSITToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lastName_A_CToolStrip = new System.Windows.Forms.ToolStrip();
            this.lastName_A_CToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.sECTION_2BToolStrip = new System.Windows.Forms.ToolStrip();
            this.sECTION_2BToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.aDDRESS_SAMALToolStrip = new System.Windows.Forms.ToolStrip();
            this.aDDRESS_SAMALToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.sECOND_YEARToolStrip = new System.Windows.Forms.ToolStrip();
            this.sECOND_YEARToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.firstName_ConsonantsToolStrip = new System.Windows.Forms.ToolStrip();
            this.firstName_ConsonantsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.studentIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.middleNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.activity6_DB_MedinaDataSet = new Activity6_Medina.Activity6_DB_MedinaDataSet();
            this.tblStudentsTableAdapter = new Activity6_Medina.Activity6_DB_MedinaDataSetTableAdapters.tblStudentsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.refreshToolStrip.SuspendLayout();
            this.bSCSToolStrip.SuspendLayout();
            this.bSITToolStrip.SuspendLayout();
            this.lastName_A_CToolStrip.SuspendLayout();
            this.sECTION_2BToolStrip.SuspendLayout();
            this.aDDRESS_SAMALToolStrip.SuspendLayout();
            this.sECOND_YEARToolStrip.SuspendLayout();
            this.firstName_ConsonantsToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.activity6_DB_MedinaDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studentIDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.middleNameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.birthdayDataGridViewTextBoxColumn,
            this.programDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 40);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(844, 246);
            this.dataGridView1.TabIndex = 0;
            // 
            // refreshToolStrip
            // 
            this.refreshToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.refreshToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshToolStripButton});
            this.refreshToolStrip.Location = new System.Drawing.Point(12, 304);
            this.refreshToolStrip.Name = "refreshToolStrip";
            this.refreshToolStrip.Size = new System.Drawing.Size(59, 25);
            this.refreshToolStrip.TabIndex = 1;
            this.refreshToolStrip.Text = "refreshToolStrip";
            this.refreshToolStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.refreshToolStrip_ItemClicked);
            // 
            // refreshToolStripButton
            // 
            this.refreshToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.refreshToolStripButton.Name = "refreshToolStripButton";
            this.refreshToolStripButton.Size = new System.Drawing.Size(47, 22);
            this.refreshToolStripButton.Text = "refresh";
            this.refreshToolStripButton.Click += new System.EventHandler(this.refreshToolStripButton_Click);
            // 
            // bSCSToolStrip
            // 
            this.bSCSToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSCSToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSCSToolStripButton});
            this.bSCSToolStrip.Location = new System.Drawing.Point(150, 304);
            this.bSCSToolStrip.Name = "bSCSToolStrip";
            this.bSCSToolStrip.Size = new System.Drawing.Size(50, 25);
            this.bSCSToolStrip.Stretch = true;
            this.bSCSToolStrip.TabIndex = 2;
            this.bSCSToolStrip.Text = "bSCSToolStrip";
            this.bSCSToolStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.bSCSToolStrip_ItemClicked);
            // 
            // bSCSToolStripButton
            // 
            this.bSCSToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSCSToolStripButton.Name = "bSCSToolStripButton";
            this.bSCSToolStripButton.Size = new System.Drawing.Size(38, 22);
            this.bSCSToolStripButton.Text = "BSCS";
            this.bSCSToolStripButton.Click += new System.EventHandler(this.bSCSToolStripButton_Click);
            // 
            // bSITToolStrip
            // 
            this.bSITToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSITToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSITToolStripButton});
            this.bSITToolStrip.Location = new System.Drawing.Point(330, 304);
            this.bSITToolStrip.Name = "bSITToolStrip";
            this.bSITToolStrip.Size = new System.Drawing.Size(45, 25);
            this.bSITToolStrip.TabIndex = 3;
            this.bSITToolStrip.Text = "bSITToolStrip";
            // 
            // bSITToolStripButton
            // 
            this.bSITToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSITToolStripButton.Name = "bSITToolStripButton";
            this.bSITToolStripButton.Size = new System.Drawing.Size(33, 22);
            this.bSITToolStripButton.Text = "BSIT";
            this.bSITToolStripButton.Click += new System.EventHandler(this.bSITToolStripButton_Click);
            // 
            // lastName_A_CToolStrip
            // 
            this.lastName_A_CToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.lastName_A_CToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lastName_A_CToolStripButton});
            this.lastName_A_CToolStrip.Location = new System.Drawing.Point(330, 339);
            this.lastName_A_CToolStrip.Name = "lastName_A_CToolStrip";
            this.lastName_A_CToolStrip.Size = new System.Drawing.Size(102, 25);
            this.lastName_A_CToolStrip.TabIndex = 4;
            this.lastName_A_CToolStrip.Text = "lastName_A_CToolStrip";
            // 
            // lastName_A_CToolStripButton
            // 
            this.lastName_A_CToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lastName_A_CToolStripButton.Name = "lastName_A_CToolStripButton";
            this.lastName_A_CToolStripButton.Size = new System.Drawing.Size(90, 22);
            this.lastName_A_CToolStripButton.Text = "LastName_A_C";
            this.lastName_A_CToolStripButton.Click += new System.EventHandler(this.lastName_A_CToolStripButton_Click);
            // 
            // sECTION_2BToolStrip
            // 
            this.sECTION_2BToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.sECTION_2BToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sECTION_2BToolStripButton});
            this.sECTION_2BToolStrip.Location = new System.Drawing.Point(479, 304);
            this.sECTION_2BToolStrip.Name = "sECTION_2BToolStrip";
            this.sECTION_2BToolStrip.Size = new System.Drawing.Size(88, 25);
            this.sECTION_2BToolStrip.TabIndex = 5;
            this.sECTION_2BToolStrip.Text = "sECTION_2BToolStrip";
            // 
            // sECTION_2BToolStripButton
            // 
            this.sECTION_2BToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.sECTION_2BToolStripButton.Name = "sECTION_2BToolStripButton";
            this.sECTION_2BToolStripButton.Size = new System.Drawing.Size(76, 22);
            this.sECTION_2BToolStripButton.Text = "SECTION_2B";
            this.sECTION_2BToolStripButton.Click += new System.EventHandler(this.sECTION_2BToolStripButton_Click);
            // 
            // aDDRESS_SAMALToolStrip
            // 
            this.aDDRESS_SAMALToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.aDDRESS_SAMALToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDDRESS_SAMALToolStripButton});
            this.aDDRESS_SAMALToolStrip.Location = new System.Drawing.Point(629, 339);
            this.aDDRESS_SAMALToolStrip.Name = "aDDRESS_SAMALToolStrip";
            this.aDDRESS_SAMALToolStrip.Size = new System.Drawing.Size(116, 25);
            this.aDDRESS_SAMALToolStrip.TabIndex = 6;
            this.aDDRESS_SAMALToolStrip.Text = "aDDRESS_SAMALToolStrip";
            // 
            // aDDRESS_SAMALToolStripButton
            // 
            this.aDDRESS_SAMALToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.aDDRESS_SAMALToolStripButton.Name = "aDDRESS_SAMALToolStripButton";
            this.aDDRESS_SAMALToolStripButton.Size = new System.Drawing.Size(104, 22);
            this.aDDRESS_SAMALToolStripButton.Text = "ADDRESS_SAMAL";
            this.aDDRESS_SAMALToolStripButton.Click += new System.EventHandler(this.aDDRESS_SAMALToolStripButton_Click);
            // 
            // sECOND_YEARToolStrip
            // 
            this.sECOND_YEARToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.sECOND_YEARToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sECOND_YEARToolStripButton});
            this.sECOND_YEARToolStrip.Location = new System.Drawing.Point(479, 339);
            this.sECOND_YEARToolStrip.Name = "sECOND_YEARToolStrip";
            this.sECOND_YEARToolStrip.Size = new System.Drawing.Size(102, 25);
            this.sECOND_YEARToolStrip.TabIndex = 7;
            this.sECOND_YEARToolStrip.Text = "sECOND_YEARToolStrip";
            // 
            // sECOND_YEARToolStripButton
            // 
            this.sECOND_YEARToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.sECOND_YEARToolStripButton.Name = "sECOND_YEARToolStripButton";
            this.sECOND_YEARToolStripButton.Size = new System.Drawing.Size(90, 22);
            this.sECOND_YEARToolStripButton.Text = "SECOND_YEAR";
            this.sECOND_YEARToolStripButton.Click += new System.EventHandler(this.sECOND_YEARToolStripButton_Click);
            // 
            // firstName_ConsonantsToolStrip
            // 
            this.firstName_ConsonantsToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.firstName_ConsonantsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.firstName_ConsonantsToolStripButton});
            this.firstName_ConsonantsToolStrip.Location = new System.Drawing.Point(150, 339);
            this.firstName_ConsonantsToolStrip.Name = "firstName_ConsonantsToolStrip";
            this.firstName_ConsonantsToolStrip.Size = new System.Drawing.Size(145, 25);
            this.firstName_ConsonantsToolStrip.TabIndex = 8;
            this.firstName_ConsonantsToolStrip.Text = "firstName_ConsonantsToolStrip";
            // 
            // firstName_ConsonantsToolStripButton
            // 
            this.firstName_ConsonantsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.firstName_ConsonantsToolStripButton.Name = "firstName_ConsonantsToolStripButton";
            this.firstName_ConsonantsToolStripButton.Size = new System.Drawing.Size(133, 22);
            this.firstName_ConsonantsToolStripButton.Text = "FirstName_Consonants";
            this.firstName_ConsonantsToolStripButton.Click += new System.EventHandler(this.firstName_ConsonantsToolStripButton_Click);
            // 
            // studentIDDataGridViewTextBoxColumn
            // 
            this.studentIDDataGridViewTextBoxColumn.DataPropertyName = "StudentID";
            this.studentIDDataGridViewTextBoxColumn.HeaderText = "StudentID";
            this.studentIDDataGridViewTextBoxColumn.Name = "studentIDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // middleNameDataGridViewTextBoxColumn
            // 
            this.middleNameDataGridViewTextBoxColumn.DataPropertyName = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.HeaderText = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.Name = "middleNameDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // birthdayDataGridViewTextBoxColumn
            // 
            this.birthdayDataGridViewTextBoxColumn.DataPropertyName = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.HeaderText = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.Name = "birthdayDataGridViewTextBoxColumn";
            // 
            // programDataGridViewTextBoxColumn
            // 
            this.programDataGridViewTextBoxColumn.DataPropertyName = "Program";
            this.programDataGridViewTextBoxColumn.HeaderText = "Program";
            this.programDataGridViewTextBoxColumn.Name = "programDataGridViewTextBoxColumn";
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.activity6_DB_MedinaDataSet;
            this.tblStudentsBindingSource.CurrentChanged += new System.EventHandler(this.tblStudentsBindingSource_CurrentChanged);
            // 
            // activity6_DB_MedinaDataSet
            // 
            this.activity6_DB_MedinaDataSet.DataSetName = "Activity6_DB_MedinaDataSet";
            this.activity6_DB_MedinaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(876, 450);
            this.Controls.Add(this.firstName_ConsonantsToolStrip);
            this.Controls.Add(this.sECOND_YEARToolStrip);
            this.Controls.Add(this.aDDRESS_SAMALToolStrip);
            this.Controls.Add(this.sECTION_2BToolStrip);
            this.Controls.Add(this.lastName_A_CToolStrip);
            this.Controls.Add(this.bSITToolStrip);
            this.Controls.Add(this.bSCSToolStrip);
            this.Controls.Add(this.refreshToolStrip);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.refreshToolStrip.ResumeLayout(false);
            this.refreshToolStrip.PerformLayout();
            this.bSCSToolStrip.ResumeLayout(false);
            this.bSCSToolStrip.PerformLayout();
            this.bSITToolStrip.ResumeLayout(false);
            this.bSITToolStrip.PerformLayout();
            this.lastName_A_CToolStrip.ResumeLayout(false);
            this.lastName_A_CToolStrip.PerformLayout();
            this.sECTION_2BToolStrip.ResumeLayout(false);
            this.sECTION_2BToolStrip.PerformLayout();
            this.aDDRESS_SAMALToolStrip.ResumeLayout(false);
            this.aDDRESS_SAMALToolStrip.PerformLayout();
            this.sECOND_YEARToolStrip.ResumeLayout(false);
            this.sECOND_YEARToolStrip.PerformLayout();
            this.firstName_ConsonantsToolStrip.ResumeLayout(false);
            this.firstName_ConsonantsToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.activity6_DB_MedinaDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private Activity6_DB_MedinaDataSet activity6_DB_MedinaDataSet;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private Activity6_DB_MedinaDataSetTableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn middleNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn programDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStrip refreshToolStrip;
        private System.Windows.Forms.ToolStripButton refreshToolStripButton;
        private System.Windows.Forms.ToolStrip bSCSToolStrip;
        private System.Windows.Forms.ToolStripButton bSCSToolStripButton;
        private System.Windows.Forms.ToolStrip bSITToolStrip;
        private System.Windows.Forms.ToolStripButton bSITToolStripButton;
        private System.Windows.Forms.ToolStrip lastName_A_CToolStrip;
        private System.Windows.Forms.ToolStripButton lastName_A_CToolStripButton;
        private System.Windows.Forms.ToolStrip sECTION_2BToolStrip;
        private System.Windows.Forms.ToolStripButton sECTION_2BToolStripButton;
        private System.Windows.Forms.ToolStrip aDDRESS_SAMALToolStrip;
        private System.Windows.Forms.ToolStripButton aDDRESS_SAMALToolStripButton;
        private System.Windows.Forms.ToolStrip sECOND_YEARToolStrip;
        private System.Windows.Forms.ToolStripButton sECOND_YEARToolStripButton;
        private System.Windows.Forms.ToolStrip firstName_ConsonantsToolStrip;
        private System.Windows.Forms.ToolStripButton firstName_ConsonantsToolStripButton;
    }
}

