﻿/*  20-01732
    Angelica D. Medina

    BSCSSD-2B
    April 07, 2022

This program will display my name from the input.
*/

using System;

namespace InputMyName_Medina
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.Write("Enter your Name (FName LName):   ");
            string name = Console.ReadLine();
            System.Console.WriteLine("");

            System.Console.WriteLine("Hello " + name + " !\n" + "Welcome to OOP Environment  :) !!!");
            System.Console.ReadKey();

        }
    }
}