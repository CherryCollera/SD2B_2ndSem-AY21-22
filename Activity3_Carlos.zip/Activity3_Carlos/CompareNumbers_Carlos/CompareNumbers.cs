﻿/*
 * 20-00382
 * Roiel A. Carlos
 * SD2B
 * April 18, 2022
 * This program will compare numbers and will display which numbers are greater than, less than, or equal.
 */
using System;

namespace CompareNumbers_Carlos
{
    class CompareNumbers
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;
            Console.Write("Enter 1st number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 2nd number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 3rd number: ");
            num3 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();

            if (num1 > num2 && num1 > num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num1, num2, num3);
                Console.WriteLine("{0} is less than {1}", num2, num1);
                Console.WriteLine("{0} is less than {1}", num3, num1);
            }
            else if (num2 > num1 && num2 > num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num2, num1, num3);
                Console.WriteLine("{0} is less than {1}", num1, num2);
                Console.WriteLine("{0} is less than {1}", num3, num2);
            }
            else if (num3 > num1 && num3 > num2)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num3, num1, num2);
                Console.WriteLine("{0} is less than {1}", num1, num3);
                Console.WriteLine("{0} is less than {1}", num2, num3);
            }
            //if all variables are equal
            else if (num1 == num2 && num2 == num3)
            {
                Console.WriteLine("{0}, {1}, and {2} are equal", num1, num2, num3);
            }
            else if (num1 == num2 && num1 > num3)
            {
                Console.WriteLine("{0}, and {1} are equal and greater than {2}", num1, num2, num3);
                Console.WriteLine("{0} is less than {1} and {2}", num3, num1, num2);
            }
            else if (num2==num3 && num3>num1)
            {
                Console.WriteLine("{0}, and {1} are equal and greater than {2}", num2, num3, num1);
                Console.WriteLine("{0} is less than {1} and {2}", num1, num2, num3);
            }
            //if num1 and num3 are equal and greater than num2
            else
            {
                Console.WriteLine("{0}, and {1} are equal and greater than {2}", num1, num3, num2);
                Console.WriteLine("{0} is less than {1} and {2}", num2, num1, num3);
            }
            Console.ReadKey();
        }
    }
}
