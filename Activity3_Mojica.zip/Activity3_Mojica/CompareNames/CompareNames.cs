﻿/*
 * student Id number : 20-05258
 * student full name : Zedrick A. Mojica
 * Section : BSCS-SD2B
 * Date : 17/04/2022
 * Purpose : comparing different names
 */
using System;

namespace CompareNames_Mojica
{
    class CompareNames
    {
        static void Main(string[] args)
        {
            string string1 = "Zed";
            string string2 = "Zed";
            string string3 = "Zedrick";
            string string4 = "zedrick";
            string string5 = "ZEDRICK";

            Console.WriteLine("Using Equals() method");
            Console.WriteLine("Compare {0} to {1} : {2}", string1, string2, String.Equals(string1, string2));
            Console.WriteLine("Compare {0} to {1} : {2}", string1, string3, String.Equals(string1, string2));
            Console.WriteLine("Length of {0} is {1}",string1, string1.Length);
            Console.WriteLine("String {0} Substring(0,3) will return {1}",string5, string5.Substring(0,3));

            Console.WriteLine("Using Compare() method");
            Console.WriteLine("Compare {0} to {1} : {2}", string1, string2, String.Compare(string1, string2));
            Console.WriteLine("Compare {0} to {1} : {2}", string1, string3, String.Compare(string1, string3));
            Console.WriteLine("Compare {0} to {1} : {2}", string3, string1, String.Compare(string3, string1));
            Console.WriteLine("Compare {0} to {1} : {2}", string4, string5, String.Compare(string4, string5));

            Console.WriteLine("Using CompareTo() method");
            Console.WriteLine("Compare {0} to {1} : {2}", string1, string2, string1.CompareTo(string2));
            Console.WriteLine("Compare {0} to {1} : {2}", string1, string3, string1.CompareTo(string3));
            Console.WriteLine("Compare {0} to {1} : {2}", string3, string1, string3.CompareTo(string1));

            Console.ReadKey();
        }
    }
}