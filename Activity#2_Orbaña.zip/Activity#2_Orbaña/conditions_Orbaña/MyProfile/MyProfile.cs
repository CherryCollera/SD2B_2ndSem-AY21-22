﻿using System;

namespace MyProfile
{
    class MyProfile
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\tName:\t\tMaria Sofia S. Orbaña\n");
            Console.WriteLine("\tDate of Birth:\tMarch 20\n");
            Console.WriteLine("\tCourse:\t\tB.S Computer Science Major in Software Ddevelopment\n");
            Console.WriteLine("\tYear:\t\tII\n");
            Console.WriteLine("\tSection:\t2\n");
            Console.ReadKey();
        }
    }
}
