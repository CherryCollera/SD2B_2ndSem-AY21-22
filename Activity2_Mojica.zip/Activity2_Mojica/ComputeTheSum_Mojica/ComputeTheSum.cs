﻿/*
 * student Id number : 20-05258
 * student full name : Zedrick A. Mojica
 * Section : BSCS-SD2B
 * Date : 04/04/2022
 * Purpose : compute the sum of two numbers
 */
using System;

namespace Activity2_Mojica
{
    class ComputeTheSum
    {
        static void Main(string[] args)
        {
            int num1, num2;
            System.Console.Write("Enter first number : ");
            num1 = Convert.ToInt32(Console.ReadLine());
            System.Console.Write("Enter second number : ");
            num2 = Convert.ToInt32(Console.ReadLine());
            System.Console.WriteLine("sum = {0} ", num1 + num2);
            System.Console.ReadKey();
        }
    }
}