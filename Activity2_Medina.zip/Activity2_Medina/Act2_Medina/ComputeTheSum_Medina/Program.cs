﻿/*  20-01732
    Angelica D. Medina

    BSCSSD-2B
    April 07, 2022

This program will compute the sum of 2 input numbers.
*/

using System;

namespace ComputeTheSum_Medina
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("Enter the first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the second number: \n");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Sum={0}  ", num1 + num2);
            System.Console.WriteLine("");

            Console.ReadLine();
        }
    }
}
