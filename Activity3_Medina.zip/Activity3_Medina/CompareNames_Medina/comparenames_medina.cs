﻿/*  20-01732
    Angelica D. Medina

    BSCSSD-2B
    April 17, 2022

This program will compare the given name strings.
*/


using System;

namespace CompareNames_Medina
{
    class comparenames_medina
    {
        static void Main(string[] args)
        {
            string str1 = "angel";
            string str2 = "angel";
            string str3 = "Angelica";
            string str4 = "angelica";
            string str5 = "ANGEL";

            Console.WriteLine("Using Equals() method");

            Console.WriteLine("\n  Compare {0} to {1}: {2}", str1, str2, String.Equals(str1, str2));
            Console.WriteLine("  Compare {0} to {1}: {2}", str1, str3, String.Equals(str1, str3));
            Console.WriteLine("  Length of {0} to {1} ", str1, str1.Length);

            Console.WriteLine("  String {0} Substring (0, 4) will return {1}", str5, str5.Substring(0, 4));

            Console.WriteLine("Using Compare() method");

            Console.WriteLine("\n  Compare {0} to {1}: {2}", str1, str2, String.Compare(str1, str2));
            Console.WriteLine("  Compare {0} to {1}: {2}", str1, str3, String.Compare(str1, str3));
            Console.WriteLine("  Compare {0} to {1}: {2}", str3, str1, String.Compare(str3, str1));
            Console.WriteLine("  Compare {0} to {1}: {2}", str4, str5, String.Equals(str4, str5));

            Console.WriteLine("Using CompareTo() method");

            Console.WriteLine("\n  Compare {0} to {1}: {2}", str1, str2, str1.CompareTo(str2));
            Console.WriteLine("  Compare {0} to {1}: {2}", str1, str3, str1.CompareTo(str3));
            Console.WriteLine("  Compare {0} to {1}: {2}", str3, str1, str3.CompareTo(str1));

            Console.ReadKey();
        }
    }
}
