﻿//This Program will show the basic operations
using System;

namespace BasicOperations_SESE
{
    class BasicOperations
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("\nEnter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("\nSum = {0}. ", num1 + num2);
            Console.Write("\nDifference = {0}. ", num1 - num2);
            Console.Write("\nProduct = {0}. ", num1 * num2);
            Console.Write("\nQoutient = {0}. ", num1 / num2);
            Console.Write("\nRemainder = {0}. ", num1 % num2);
            Console.ReadLine();
        }
    }
}
