﻿/*
 20-01076
Noel M. Gallo Jr.
SD2B
April 7, 2022
This program will display My profile informations
 */
using System;

namespace MyProfile
{

    class MyProfile
    {

        public static void Main(string[] args)
        {
            System.Console.WriteLine("Name:\t\tNoel M. Gallo Jr.\n\n" +
                "Date of Birth:\tNovember 9\n\n" +
                "Course:\t\tBS Computer Science Major in Software Development\n\n" +
                "Year:\t\tII\n\n" +
                "Section:\tSD2B");
            System.Console.ReadKey();
        }

    }
}
