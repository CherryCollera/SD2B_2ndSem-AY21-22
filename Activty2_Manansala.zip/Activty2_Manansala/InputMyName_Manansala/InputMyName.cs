﻿using System;

namespace InputMyName_Manansala
{
    class InputMyName
    {
        static void Main(string[] args)
        {
            String fullname;
            Console.Write("Enter your Name:" +
                "(Firstname Lastname) ");
            fullname = Console.ReadLine();

            Console.WriteLine("\nHello " + fullname
                + "!!!\n" + "Welcome to OOP Environment.");
            Console.ReadKey();
        }
    }
}
