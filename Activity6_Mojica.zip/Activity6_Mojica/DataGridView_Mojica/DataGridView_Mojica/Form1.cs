﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataGridView_Mojica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'myDatabaseDataSet.student' table. You can move, or remove it, as needed.
            this.studentTableAdapter.Fill(this.myDatabaseDataSet.student);
            
       

        }

        private void table1BindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void refreshToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentTableAdapter.Refresh(this.myDatabaseDataSet.student);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void lastname_AToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentTableAdapter.Lastname_A_or_C(this.myDatabaseDataSet.student);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void bSCSToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentTableAdapter.BSCS(this.myDatabaseDataSet.student);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void bSITToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentTableAdapter.BSIT(this.myDatabaseDataSet.student);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void samalToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentTableAdapter.Samal(this.myDatabaseDataSet.student);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void second_yearToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentTableAdapter.second_year(this.myDatabaseDataSet.student);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void section_2BToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentTableAdapter.section_2B(this.myDatabaseDataSet.student);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void section_2BToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void firstname_ConsonantToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentTableAdapter.firstname_Consonant(this.myDatabaseDataSet.student);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
