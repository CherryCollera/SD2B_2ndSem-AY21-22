﻿using System;

namespace DoWhile_Sese
{
    class DoWhile
    {
        static void Main(string[] args)
        {
            int[] ArrayInt = new int[] { 6, 7, 8, 10 };
            int ArraySum = 0;
            int i = 0;
            do
            {
                ArraySum += ArrayInt[i];
                i++;
            } while (i < 4);

            Console.WriteLine(ArraySum);
            Console.ReadKey();
        }
    }
}

