﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACT4_GROUP8
{
    internal class Car
    {
        private string color;
        
        public Car(string color) //assigns the value of "Color" from Declaration class to "color".
        {
            this.color = color; 
        }

        public string Describe() //Describes the color of the car.
        {
            return "This car is " + color;
        }
    }
}
