﻿/*
 * Group number: 2
 * Group Members: Gallo, Noel Jr. 
                  Mojica, Zedrick
                  Enriquez, John Brix
 * Section : BSCS-SD2B
 * Date : 02/06/2022
 * Purpose : linking form to a database
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatabaseConnection_Gallo_Enriquez_Mojica
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
