﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Manansala_Francisco_Cruz
{
    class MyProfile
    {
        public void DisplayProfile()
        {
            System.Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E");
            System.Console.WriteLine("Name:\t\t\tArnie James Manansala");
            System.Console.WriteLine("Birthday:\t\tMay 11, 2002");
            System.Console.WriteLine("Course:\t\t\tBS of Computer Science Major in Software Development");
            System.Console.WriteLine("Year:\t\t\t2nd Year");
            System.Console.WriteLine("Section:\t\tSD2B");
            
            System.Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E");
            System.Console.WriteLine("Name:\t\t\tJan Andrei Francisco");
            System.Console.WriteLine("Birthday:\t\tNov. 13, 2001");
            System.Console.WriteLine("Course:\t\t\tBS of Computer Science Major in Software Development");
            System.Console.WriteLine("Year:\t\t\t2nd Year");
            System.Console.WriteLine("Section:\t\tSD2B");

            System.Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E");
            System.Console.WriteLine("Name:\t\t\tAlexis Emmannuel Cruz");
            System.Console.WriteLine("Birthday:\t\tDec. 04, 2001");
            System.Console.WriteLine("Course:\t\t\tBS of Computer Science Major in Software Development");
            System.Console.WriteLine("Year:\t\t\t2nd Year");
            System.Console.WriteLine("Section:\t\tSD2B");
        }
    }
}
