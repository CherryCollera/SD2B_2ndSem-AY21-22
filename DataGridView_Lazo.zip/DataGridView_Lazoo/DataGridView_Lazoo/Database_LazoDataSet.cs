﻿namespace DataGridView_Lazoo
{


    partial class Database_LazoDataSet
    {
    }
}

namespace DataGridView_Lazoo.Database_LazoDataSetTableAdapters {
    
    
    public partial class Table1TableAdapter {
    }
}
