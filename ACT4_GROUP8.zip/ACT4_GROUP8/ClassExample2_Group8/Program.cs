﻿/*
Mendoza, Carl Joseph
Orbaña, Maria Sofia 
Quitaleg, Jaycee Audrei Mari
This program uses different classes to describe the color of the car.
 */
using System;

namespace ACT4_GROUP8
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car;
            car = new Car("Red");
            Console.WriteLine(car.Describe()); //Outputs the color of the car which is Red.
            car = new Car("Green");
            Console.WriteLine(car.Describe()); //Outputs the color of the car whic is Green.
            Console.ReadLine();
        }
    }
}