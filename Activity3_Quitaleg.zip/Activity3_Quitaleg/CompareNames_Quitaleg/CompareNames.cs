﻿/*
20-02604
Jaycee Audrei Mari M. Quitaleg
SD2B
April 08, 2022
This program will compare different string names to one another using the Equals(), Compare(), and CompareTo() Methods.
 */

using System;

namespace CompareNames_Quitaleg
{
    class CompareNames_Quitaleg
    {
        static void Main(String[] args)
        {
            string string1 = "Jayce";
            string string2 = "Jayci";
            string string3 = "Jaycee";
            string string4 = "jaycee";
            string string5 = "JAYCEE";

            Console.WriteLine("Using Equals() Method");

            Console.WriteLine("\tCompare {0} to {1}: {2}", string1, string2, String.Equals(string1, string2));
            Console.WriteLine("\tCompare {0} to {1}: {2}", string1, string3, String.Equals(string1, string3));
            Console.WriteLine("\tLength of {0} is {1} ", string1, string1.Length);
            Console.WriteLine("\tstring {0} Substring(0,3) will return {1} ", string5, string5.Substring(0, 3));

            Console.WriteLine("\nUsing Compare() Method");

            Console.WriteLine("\tCompare {0} to {1}: {2}", string1, string2, String.Compare(string1, string2));
            Console.WriteLine("\tCompare {0} to {1}: {2}", string1, string3, String.Compare(string1, string3));
            Console.WriteLine("\tCompare {0} to {1}: {2}", string3, string1, String.Compare(string3, string1));
            Console.WriteLine("\tCompare {0} to {1}: {2}", string4, string5, String.Equals(string4, string5));

            Console.WriteLine("\nUsing CompareTo() Method");

            Console.WriteLine("\tCompare {0} to {1}: {2}", string1, string2, string1.CompareTo(string2));
            Console.WriteLine("\tCompare {0} to {1}: {2}", string1, string3, string1.CompareTo(string3));
            Console.WriteLine("\tCompare {0} to {1}: {2}", string3, string1, string3.CompareTo(string1));

            Console.ReadKey();
        }
    }
}

