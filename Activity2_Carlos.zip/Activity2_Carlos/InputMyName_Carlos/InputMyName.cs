﻿/*
 * 20-00382
 * Roiel A. Carlos
 * SD2B
 * April 7, 2022
 * This program will get my name and display a welcome message.
 */
using System;

namespace InputMyName_Carlos
{
    class InputMyName
    {
        static void Main(string[] args)
        {
            string name;
            Console.Write("Enter your name (firstname lastname) ");
            name = Console.ReadLine();
            Console.WriteLine("\nHello! " + name + "!!!\nWelcome to OOP Environment.");
            Console.ReadKey();
        }
    }
}
