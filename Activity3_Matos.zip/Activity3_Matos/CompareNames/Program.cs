﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 16, 2022
 *  Compare strings using different string mmethods
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CompareNames
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string s1 = "Dianne";
            string s2 = "Dianne";
            string s3 = "Grace";
            string s4 = "Grace";
            string s5 = "MATOS";


            Console.WriteLine("Using Equals() method =   ");
            Console.WriteLine("\tCompare {0} to {1}: {2}", s1, s2, String.Equals(s1, s2));
            Console.WriteLine("\tCompare {0} to {1}: {2}", s1, s3, String.Equals(s1, s3));
            Console.WriteLine("\tLength of {0} is {1}: ", s1, s1.Length);
            Console.WriteLine("\tString {0} Substring(0, 3) will return {1}", s5, s5.Substring(0, 3));


            Console.WriteLine("\n\nUsing Compare() method =   ");
            Console.WriteLine("\tCompare {0} to {1}: {2}", s1, s2, String.Compare(s1, s2));
            Console.WriteLine("\tCompare {0} to {1}: {2}", s1, s3, String.Compare(s1, s3));
            Console.WriteLine("\tCompare {0} to {1}: {2}", s3, s1, String.Compare(s3, s1));
            Console.WriteLine("\tCompare {0} to {1}: {2}", s4, s5, String.Compare(s4, s5));


            Console.WriteLine("\n\nUsing CompareTo() method =   ");
            Console.WriteLine("\tCompare {0} to {1}: {2}", s1, s2, s1.CompareTo(s2));
            Console.WriteLine("\tCompare {0} to {1}: {2}", s1, s3, s1.CompareTo(s3));
            Console.WriteLine("\tCompare {0} to {1}: {2}", s3, s1, s3.CompareTo(s1));
        }
    }
}
