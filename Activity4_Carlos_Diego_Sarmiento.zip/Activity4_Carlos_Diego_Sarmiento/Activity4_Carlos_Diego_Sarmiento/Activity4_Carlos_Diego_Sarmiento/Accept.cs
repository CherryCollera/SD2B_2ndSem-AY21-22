﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Carlos_Diego_Sarmiento
{
    class Accept
    {
        public string name;
        public void AcceptDetails()
        {
            System.Console.Write("Enter firstname and lastname:\t");
            name = System.Console.ReadLine();
        }
    }
}
