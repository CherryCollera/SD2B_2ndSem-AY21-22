﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassExample1A_Duran_Fabian_Cruz
{
    class Print
    {
        public void PrintDetails(string firstname, string lastname)
        {

            System.Console.Write("Hello " + firstname + " " + lastname + "!!! \nYou have created classes in OOP");
            
        }
    }
}
