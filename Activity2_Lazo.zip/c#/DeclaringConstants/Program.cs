﻿using System;

namespace DeclaringConstants
{
    class Program
    {
        static void Main(string[] args)
        {
            const double pi = 3.14159;
            double radius;
            Console.Write("Enter Radius: ");
            radius = Convert.ToInt32(Console.ReadLine());

            double AreaCircle = pi * radius * radius;
            Console.WriteLine("Radius: " + radius + " ," + "Area: " + AreaCircle);
        }
    }
}
