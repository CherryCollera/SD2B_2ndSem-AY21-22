﻿/*20-03361
Adrian Fabian
SD2B
April 7, 2022
This prrogram will compute average*/

using System;

namespace ComputeAverage_Fabian
{
    class Average
    {
        static void Main()
        {
            double num1, num2, num3, num4, num5;
            double num6 = 5;
            Console.WriteLine("Enter your grades(5): ");
            Console.Write("");
            num1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("");
            num2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("");
            num3 = Convert.ToDouble(Console.ReadLine());
            Console.Write("");
            num4 = Convert.ToDouble(Console.ReadLine());
            Console.Write("");
            num5 = Convert.ToDouble(Console.ReadLine());

            double avg = num1 + num2 + num3 + num4 + num5;
            double avg2 = avg / num6;
            Console.Write("Your Average is = {0}", avg2);
            Console.ReadLine();
        }
    }
}