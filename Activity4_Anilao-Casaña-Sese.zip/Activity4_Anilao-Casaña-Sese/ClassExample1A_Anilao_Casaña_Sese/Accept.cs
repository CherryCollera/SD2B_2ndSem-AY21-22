﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1A_Anilao_Casaña_Sese
{
    class Accept //Creating first class
    {
        public String firstname, lastname;
        public void AcceptDetails()
        {
            //input your first name and last name
            System.Console.Write("Enter your first name and last name: ");
            firstname = Console.ReadLine();
            lastname = Console.ReadLine();
        }
    }
}
