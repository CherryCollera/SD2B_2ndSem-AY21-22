﻿
/*
 
Jermaine T. Magpoc
SD-2B
March 20,2022
This Program Will Print the phrase "Hello World!"


 
 */

using System;
namespace Sample1_HelloWorld
{
    class HelloWorld
    {
        static void Main(String[] args)
        {

            System.Console.WriteLine("Hello World!");
            System.Console.ReadKey();
        }


    }
}