﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Anilao_Casaña_Sese
{
    class Sum
    {
        public void ComputeSum()
        {
            //Compute the sum of num1 and num2
            DeclareVar.sum = DeclareVar.num1 + DeclareVar.num2;
        }
    }
}
