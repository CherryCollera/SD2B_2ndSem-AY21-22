﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataGridView_Casaña
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'database1DataSet.studentsTable' table. You can move, or remove it, as needed.
            this.studentsTableTableAdapter.Fill(this.database1DataSet.studentsTable);

        }

        private void bSCS_StudentsToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentsTableTableAdapter.BSCS_Students(this.database1DataSet.studentsTable);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void bSIT_StudentsToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentsTableTableAdapter.BSIT_Students(this.database1DataSet.studentsTable);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }


        private void bSIT_StudentsToolStripButton_Click_1(object sender, EventArgs e)
        {
            try
            {
                this.studentsTableTableAdapter.BSIT_Students(this.database1DataSet.studentsTable);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void address_SamalToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentsTableTableAdapter.Address_Samal(this.database1DataSet.studentsTable);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void second_Year_StudentsToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentsTableTableAdapter.Second_Year_Students(this.database1DataSet.studentsTable);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void refreshToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentsTableTableAdapter.Refresh(this.database1DataSet.studentsTable);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void a_and_C_LastNamesToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentsTableTableAdapter.A_and_C_LastNames(this.database1DataSet.studentsTable);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void section_2BToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentsTableTableAdapter.Section_2B(this.database1DataSet.studentsTable);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void firstName_ConsonantToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.studentsTableTableAdapter.FirstName_Consonant(this.database1DataSet.studentsTable);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }

    }

