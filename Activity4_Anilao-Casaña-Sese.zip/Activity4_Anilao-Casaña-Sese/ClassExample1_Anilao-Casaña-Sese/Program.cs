﻿/*Activity 4
  Group 5
  Members:
            Anilao, Jean Claudine D.
            Casaña, Regee D.
            Sese, Regie A.
Program and Section: BSCS SD2B
Date: 24/04/2022
This Program will display Class Example number 1*/

using System;

namespace ClassExample1_Anilao_Casaña_Sese
{
    class Program // Main Class
    {
        static void Main(string[] args)
        {
            Print print = new Print();
            print.PrintDetails();
            Console.ReadLine();
        }
    }
}
