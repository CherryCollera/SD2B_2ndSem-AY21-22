﻿using System;

namespace CompareNames
{
    class Program
    {
        static void Main(string[] args)
        {
           string name1 = "Maxime";
           string name2 = "Maxime";
           string name3 = "Maxx";
           string name4 = "Apen"; 
           string name5 = "MAXIME";

           Console.WriteLine("Using Equals() Method");

           Console.WriteLine("  compare {0} to {1}: {2}", name1, name2, String.Equals(name1,name2));
           Console.WriteLine("  compare {0} to {1}: {2}", name1, name3, String.Equals(name1,name3));
           Console.WriteLine("Length of {0} is {1} ", name1, name1.Length);
           Console.WriteLine("String {0} Substring(0,3) will return {1}",name5, name5.Substring(0,3));

           Console.WriteLine("Using Compare() method");
           Console.WriteLine("  compare {0} to {1}: {2}", name1 , name2, String.Compare(name1, name2));
           Console.WriteLine("  compare {0} to {1}: {2}", name1 , name3, String.Compare(name1, name3));
           Console.WriteLine("  compare {0} to {1}: {2}", name3 , name1, String.Compare(name3, name1));
           Console.WriteLine("  compare {0} to {1}: {2}", name4 , name5, String.Compare(name4, name5));

           Console.WriteLine("Using CompareTo() method");
           Console.WriteLine("  compare {0} to {1}: {2}", name1 , name2, name1.CompareTo(name2));
           Console.WriteLine("  compare {0} to {1}: {2}", name1 , name3, name1.CompareTo(name3));
           Console.WriteLine("  compare {0} to {1}: {2}", name3 , name1, name3.CompareTo(name1));

        }
    }
}
