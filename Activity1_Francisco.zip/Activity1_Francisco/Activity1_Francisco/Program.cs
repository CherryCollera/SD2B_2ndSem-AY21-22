﻿using System;

namespace HelloWorld_Francisco
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            System.Console.ReadKey();
        }
    }
}
