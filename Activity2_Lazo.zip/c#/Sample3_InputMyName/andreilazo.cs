﻿using System;

namespace Sample3_InputMyName
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your <firstname lastname>:  ");
            string name = Console.ReadLine();

            Console.WriteLine("\nHello " + name);
            Console.WriteLine("Welcome to OOP environment\n");
        }
    }
}
