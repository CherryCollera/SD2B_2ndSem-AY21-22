using ClassExample1_Lazo;

class Print{
    public void PrintDetails(){

        Accept a = new Accept();
        a.AcceptDetails();

        System.Console.Write("Hello " + a.firstname + " " + a.lastname + " !!!\nYou have created classes in OOP!");
        myProfile mp = new myProfile();
        mp.DisplayProfile();
    }

}