﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Carlos_Diego_Sarmiento
{
    class Remainder
    {
        public void getRemainder()
        {
            DeclareVar.rem = (DeclareVar.num1 % DeclareVar.num2);
            Console.WriteLine("The remainder is {0}", DeclareVar.rem);
        }
    }
}
