﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Gallo_Mojica_Enriquez
{
    internal class Accept
    {
        public string firstName, lastName;
        public void AcceptDetails()
        {
            Console.Write("Enter your firstname and lastname: \t");
            firstName = Console.ReadLine();
            lastName = Console.ReadLine();
        }
    }
}
