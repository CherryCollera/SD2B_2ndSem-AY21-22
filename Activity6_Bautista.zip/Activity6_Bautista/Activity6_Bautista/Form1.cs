﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity6_Bautista
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'activity6_DatabaseDataSet.Table1' table. You can move, or remove it, as needed.
            this.table1TableAdapter.Fill(this.activity6_DatabaseDataSet.Table1);

        }

        private void refreshToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.Refresh(this.activity6_DatabaseDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void bSCSToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.BSCS(this.activity6_DatabaseDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void bSCSToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void bSITToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.BSIT(this.activity6_DatabaseDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void sAMALToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.SAMAL(this.activity6_DatabaseDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void sECOND_YEARToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.SECOND_YEAR(this.activity6_DatabaseDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void lASTNAME_AandCToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.LASTNAME_AandC(this.activity6_DatabaseDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void sECTION_2BToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.SECTION_2B(this.activity6_DatabaseDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void lASRNAME_CONSONANTToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.LASRNAME_CONSONANT(this.activity6_DatabaseDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
