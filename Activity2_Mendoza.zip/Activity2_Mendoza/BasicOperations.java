using System;

namespace BasicOperations

{
    class BasicOperations
    {
        static void Main(string[] args)
        {
            int num1, num2, sum, diff, prod, div;

            Console.Write("\t \n Enter num1: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("\t \n Enter num2: " );
            num2 = Convert.ToInt32(Console.ReadLine());

            sum = num1 + num2;
            diff = num1 - num2;
            prod = num1 * num2;
            div = num1 / num2;

            Console.WriteLine("\t \n The Sum is " + sum + " \n ");
            Console.WriteLine("\t \n The Difference is " + diff + " \n ");
            Console.WriteLine("\t \n The Product is " + prod + " \n ");
            Console.WriteLine("\t \n The Quotient is " + div + " \n ");

            Console.ReadKey();
        }
    }
}