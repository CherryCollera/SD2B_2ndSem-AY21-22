﻿//This program will display the numbers being compared

using System;

namespace CompareNumbers_Casaña
{
    class CompareNumbers
    {
        static void Main(string[] args)
        {
            //input num1, num2, and num3
            int num1, num2, num3;
            Console.Write("Enter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Third Number: ");
            num3 = Convert.ToInt32(Console.ReadLine());


            //compare if num1 is greater than num2 and num3, return true
            if (num1 > num2 && num1 > num3)
            {
                Console.WriteLine("\n{0} is greater than {1} and {2}", num1, num2, num3);
                Console.WriteLine("{0} is less than {1}", num2, num1);
                Console.WriteLine("{0} is less than {1}", num3, num1);
                Console.ReadLine();
            }

            //compare if num2 is greater than num1 and num3, return true
            else if (num2 > num1 && num2 > num3)
            {
                Console.WriteLine("\n{0} is greater than {1} and {2}", num2, num1, num3);
                Console.WriteLine("{0} is less than {1}", num1, num2);
                Console.WriteLine("{0} is less than {1}", num3, num2);
                Console.ReadLine();
            }

            //compare if num3 is greater than num1 and num2, return true
            else if (num3 > num1 && num3 > num2)
            {
                Console.WriteLine("\n{0} is greater than {1} and {2}", num3, num1, num2);
                Console.WriteLine("{0} is less than {1}", num1, num3);
                Console.WriteLine("{0} is less than {1}", num2, num3);
                Console.ReadLine();
            }

            //else, all of the numbers are equal
            else
            {
                Console.WriteLine("\n{0}, {1}, and {2} are equal", num1, num2, num3);
                Console.ReadLine();
            }
        }
    }
}
