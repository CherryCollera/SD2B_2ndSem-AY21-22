﻿using System;

namespace ComputeAverage
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, num3, num4, num5;
            Console.WriteLine("Enter 5 grades:  ");
            Console.Write("1: ");
            num1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("2: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("3: ");
            num3 = Convert.ToInt32(Console.ReadLine());

            Console.Write("4: ");
            num4 = Convert.ToInt32(Console.ReadLine());

            Console.Write("5: ");
            num5 = Convert.ToInt32(Console.ReadLine());

            int average = (num1 + num2 + num3 + num4 + num5) / 5;

            Console.WriteLine("The average is: " + average);

        }
    }
}
