﻿/*  20-01732
    Angelica D. Medina

    BSCSSD-2B
    April 17, 2022

This program will perform a do-while loop while getting the sum of all the elements in the array. 
*/


using System;

namespace DoWhileLoop_Medina
{
    class dowhileloop_medina
    {
        static void Main(string[] args)
        {
            int[] GEF06_nms = new int[] { 6, 7, 8, 10 };
            int GEF06_sum = 0;
            int k = 0;

            do
            {
                GEF06_sum += GEF06_nms[k];
                k++;
            } while (k < 4);

            Console.WriteLine(GEF06_sum);
            Console.ReadKey();

        }
    }
}
