﻿/*20-03361
Adrian Fabian
SD2B
April 7, 2022
This program will declare constants*/

using System;

namespace DeclaringConstants_Fabian
{
    class DeclaringConstants
    {
        static void Main()
        {
            double num1, AreaCircle;
            Console.Write("Please input the radius: ");
            num1 = Convert.ToDouble(Console.ReadLine());
            const double pi = 3.14159;
            AreaCircle = pi * num1 * num1;
            Console.Write("Radius: {0}", num1);
            Console.Write("\nArea: {0}", AreaCircle);
            Console.ReadLine();
        }
    }
}