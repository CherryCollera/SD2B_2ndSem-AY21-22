﻿namespace MidtermCaseStudy_Monjardin_Jade_Piolo
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.intBtn = new System.Windows.Forms.Button();
            this.FltBtn = new System.Windows.Forms.Button();
            this.dblBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.Csum = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MidtermCaseStudy_Monjardin_Jade_Piolo.Properties.Resources._21;
            this.pictureBox1.Location = new System.Drawing.Point(-31, -3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(833, 458);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // intBtn
            // 
            this.intBtn.BackColor = System.Drawing.Color.YellowGreen;
            this.intBtn.Location = new System.Drawing.Point(221, 67);
            this.intBtn.Name = "intBtn";
            this.intBtn.Size = new System.Drawing.Size(99, 45);
            this.intBtn.TabIndex = 2;
            this.intBtn.Text = "Integer";
            this.intBtn.UseVisualStyleBackColor = false;
            this.intBtn.Click += new System.EventHandler(this.intBtn_Click);
            // 
            // FltBtn
            // 
            this.FltBtn.BackColor = System.Drawing.Color.YellowGreen;
            this.FltBtn.Location = new System.Drawing.Point(358, 66);
            this.FltBtn.Name = "FltBtn";
            this.FltBtn.Size = new System.Drawing.Size(99, 45);
            this.FltBtn.TabIndex = 3;
            this.FltBtn.Text = "Flaot";
            this.FltBtn.UseVisualStyleBackColor = false;
            this.FltBtn.Click += new System.EventHandler(this.FltBtn_Click);
            // 
            // dblBtn
            // 
            this.dblBtn.BackColor = System.Drawing.Color.YellowGreen;
            this.dblBtn.Location = new System.Drawing.Point(502, 66);
            this.dblBtn.Name = "dblBtn";
            this.dblBtn.Size = new System.Drawing.Size(99, 45);
            this.dblBtn.TabIndex = 4;
            this.dblBtn.Text = "Double";
            this.dblBtn.UseVisualStyleBackColor = false;
            this.dblBtn.Click += new System.EventHandler(this.dblBtn_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Oxygen", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(239, 189);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 23);
            this.label1.TabIndex = 5;
            this.label1.Text = "Enter first number:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Oxygen", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(238, 255);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(176, 23);
            this.label2.TabIndex = 6;
            this.label2.Text = "Enter second number:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(426, 189);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(125, 23);
            this.textBox1.TabIndex = 7;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(426, 255);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(125, 23);
            this.textBox2.TabIndex = 8;
            // 
            // Csum
            // 
            this.Csum.BackColor = System.Drawing.Color.LightSlateGray;
            this.Csum.Location = new System.Drawing.Point(358, 314);
            this.Csum.Name = "Csum";
            this.Csum.Size = new System.Drawing.Size(99, 42);
            this.Csum.TabIndex = 9;
            this.Csum.Text = "Compute";
            this.Csum.UseVisualStyleBackColor = false;
            this.Csum.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.BurlyWood;
            this.button2.Location = new System.Drawing.Point(695, 386);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(93, 52);
            this.button2.TabIndex = 10;
            this.button2.Text = "HIDE";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Csum);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dblBtn);
            this.Controls.Add(this.FltBtn);
            this.Controls.Add(this.intBtn);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button intBtn;
        private System.Windows.Forms.Button FltBtn;
        private System.Windows.Forms.Button dblBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button Csum;
        private System.Windows.Forms.Button button2;
    }
}