﻿/*20-0332
Regee D. Casaña
SD2B
April 2, 2022
This Program will display the name that I inputted*/

using System;

namespace InputMyName_Casaña
{
    class InputMyName
    {
        static void Main(string[] args)
        {
            //Enter your firstname and lastname
            String firstname, lastname;
            Console.Write("Enter your Name:" + 
                "(Firstname Lastname) ");
            firstname = Console.ReadLine();
            lastname = Console.ReadLine();

            //Display your name
            Console.WriteLine("\nHello " + firstname 
                + " " + lastname + "!!!"
                + "\nWelcome to OOP Environment.");
            Console.ReadKey();
        }
    }
}