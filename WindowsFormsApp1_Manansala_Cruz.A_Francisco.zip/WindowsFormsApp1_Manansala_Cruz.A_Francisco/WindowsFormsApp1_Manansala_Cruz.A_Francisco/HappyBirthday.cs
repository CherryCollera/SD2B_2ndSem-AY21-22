﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1_Manansala_Cruz.A_Francisco
{
    class HappyBirthday
    {
        public string GetMessage(string firstname)
        {
            return "Happy Bithday " + firstname;
        }

    }
}
