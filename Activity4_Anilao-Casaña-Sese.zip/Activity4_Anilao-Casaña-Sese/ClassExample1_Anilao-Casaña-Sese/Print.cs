﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Anilao_Casaña_Sese
{
    class Print //2nd class created
    {
        public void PrintDetails()
        {
            Accept accept = new Accept();   //Object creation of the class Accept
            accept.AcceptDetails();         //Calling the method from the class Accept
            
            //Printing the value collected from method AcceptDetails()
            System.Console.Write("\nHello " + accept.firstname + " " + accept.lastname 
                + "!!!\nYou have created a class in OOP!");

            //Object creation of the class MyProfile
            MyProfile profile = new MyProfile();
            profile.DisplayProfile(); // Calling the method DisplayProfile() from the class MyProfile

        }
    }
}
