﻿/*
20-02604
Jaycee Audrei Mari M. Quitaleg
SD2B
April 08, 2022
This program will use the do-while loop.
 */

using System;

namespace Quitaleg
{
    class Quitaleg
    {
        static void Main(string[] args)
        {
            int[] num = new int[] { 6, 7, 8, 10 };
            int sum = 0;
            int i = 0;

            do
            {
                sum += num[i];
                i++;
            }
            while (i < 4);

            Console.WriteLine(sum);
            Console.ReadKey();
        }
    }
}
