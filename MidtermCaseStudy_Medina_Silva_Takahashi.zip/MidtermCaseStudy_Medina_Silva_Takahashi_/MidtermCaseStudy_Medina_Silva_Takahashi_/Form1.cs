﻿/* Midterm Case Study Group 9
		<Members>
	Medina, Angelica
	Silva, Alyssa Mae
	Takahashi, Aira

<BSCS SD2B> **/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidtermCaseStudy_Medina_Silva_Takahashi_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMessage_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hello", "My Message", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            Calculatorr calculator = new Calculatorr();
            calculator.Show();
            this.Hide();
        }
    }
}
