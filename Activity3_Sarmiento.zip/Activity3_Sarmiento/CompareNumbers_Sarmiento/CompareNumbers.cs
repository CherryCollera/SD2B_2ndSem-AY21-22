﻿/*20-00613
Marian Gillian G. Sarmiento
SD2B
April 19, 2022
This program will compare numbers*/

using System;

namespace CompareNumbers_Sarmiento
{
    class CompareNumbers
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;
            Console.Write("Enter 1st number ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 2nd number ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 3rd number ");
            num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2 && num1 > num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num1, num2, num3);
                Console.WriteLine("{0} is less than {1}", num2, num1);
                Console.WriteLine("{0} is less than {1}", num3, num1);
                Console.ReadLine();
            }
            else if (num2 > num1 && num2 > num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num2, num1, num3);
                Console.WriteLine("{0} is less than {1}", num1, num2);
                Console.WriteLine("{0} is less than {1}", num3, num2);
                Console.ReadLine();
            }
            else if (num3 > num1 && num3 > num2)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num3, num1, num2);
                Console.WriteLine("{0} is less than {1}", num1, num3);
                Console.WriteLine("{0} is less than {1}", num2, num3);
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("{0}, {1}, and {2} are equal", num1, num2, num3);
                Console.ReadLine();
            }
        }
    }
}