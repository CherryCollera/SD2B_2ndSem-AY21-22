﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace MidtermCaseStudy_Matos_Dianna_Grace
    {
        public partial class Menu : Form
            {
                public Menu()
                    {
                        InitializeComponent();
                    }

                private void button1_Click(object sender, EventArgs e)
                    {
                        MessageBox.Show("Hello, Philippines!", "My Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                private void Form1_Load(object sender, EventArgs e)
                    {

                    }

                private void button2_Click(object sender, EventArgs e)
                    {
                        MessageBox.Show("Made by Dianna Grace Matos ", "My Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                private void button3_Click(object sender, EventArgs e)
                    {
                        new Sum().Show();
                        this.Hide();
                    }

                private void button4_Click(object sender, EventArgs e)
                    {
                        new Calculator().Show();
                        this.Hide();
                    }
            }
    }
