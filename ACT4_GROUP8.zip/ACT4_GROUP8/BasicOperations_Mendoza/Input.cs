﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Mendoza
{
     class Input
    {
        public void InputValues()
        {
            Console.Write("Enter First Number: ");
            DeclareVar.num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            DeclareVar.num2 = Convert.ToInt32(Console.ReadLine());
        }
    }
}
