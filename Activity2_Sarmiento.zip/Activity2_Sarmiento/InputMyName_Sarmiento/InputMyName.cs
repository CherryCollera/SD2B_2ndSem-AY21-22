﻿/*20-00613
Marian Gillian G. Sarmiento
SD2B
April 5, 2022
This program will ask to input my name*/

using System;

namespace InputMyName_Sarmiento
{
    class InputMyName
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your name (firstname lastname) ");
            string fullName = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("Hello " + fullName + "!!!" 
                + "\nWelcome to OOP environment.");
            Console.ReadKey();
        }
    }
}
