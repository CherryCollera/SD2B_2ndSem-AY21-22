﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Medina
{
    class Accept
    {
        public string firstname, lastname;
        public void AcceptDetails()
        {
            //input first and last name of the user. 

            System.Console.Write("Enter your firstname and lastname: \t");
            firstname = System.Console.ReadLine();
            lastname = System.Console.ReadLine();

        }
    }
}
