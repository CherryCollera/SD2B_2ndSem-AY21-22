﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Carlos_Diego_Sarmiento
{
    class Quotient
    {
        public void computeQuotient()
        {
            DeclareVar.quot = Convert.ToDouble(DeclareVar.num1) / Convert.ToDouble(DeclareVar.num2);
            Console.WriteLine("The quotient is {0:0.00}", DeclareVar.quot);
        }
    }
}
