﻿/* Creating classes in OOP
 * Group Members : Roiel A. Carlos
 *                 Angelo R. Diego
 *                 Marian Gillian G. Sarmiento
 * Date: April 25, 2022
 */

using System;

namespace ClassExample2_Carlos_Diego_Sarmiento
{
    class ClassExample2
    {
        static void Main(string[] args)
        {
            Car car;
            car = new Car("Black");
            Console.WriteLine(car.Describe());
            car = new Car("White");
            Console.WriteLine(car.Describe());
            Console.ReadKey();
        }
    }
}
