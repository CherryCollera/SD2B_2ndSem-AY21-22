﻿using System;

namespace IfElse1_Casaña
{
    class IfElse1
    {
        static void Main(string[] args)
        {
            //Declare Variables
            int num1, num2;

            //Input data to num1 and num2
            Console.Write("Enter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();

            //Display if the first number is greater than the Second number
            if (num1 > num2)
            {
                Console.WriteLine(num1 + " is greater than {0}.", num2);               
            }

            //Display if the first number is less than the Second number
            else if (num1 < num2)
            {
                Console.WriteLine(num2 + " is greater than {0}.", num1);               
            }

            //Display if the first number is equal to the Second number
            else
                Console.WriteLine(num1 + " is equal to {0}.", num2);
                Console.ReadKey();
        }
    }
}
