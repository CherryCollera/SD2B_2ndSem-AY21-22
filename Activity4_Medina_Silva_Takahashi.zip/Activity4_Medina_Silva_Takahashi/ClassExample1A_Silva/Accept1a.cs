﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1A_Silva
{
    class Accept1a
    {
        public string firstname, lastname;
        public void AcceptDetails()
        {
            //input first and last name of the user. 

            System.Console.Write("Enter your firstname and lastname: \t");
            firstname = System.Console.ReadLine();
            lastname = System.Console.ReadLine();

        }
    }
}
