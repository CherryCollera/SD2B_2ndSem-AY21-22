﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicOperations_Duran_Fabian_Cruz
{
    class Input
    {
        public void InputValues()
        {
            System.Console.Write("Enter first number:\t");
            DeclareVar.num1 = Convert.ToInt32(Console.ReadLine());
            System.Console.Write("Enter second number:\t");
            DeclareVar.num2 = Convert.ToInt32(Console.ReadLine());
        }
    }
}
