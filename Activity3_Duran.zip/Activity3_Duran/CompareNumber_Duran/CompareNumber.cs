﻿using System;

namespace CompareNumber_Duran
{
    class CompareNumber
    {
        static void Main(string[] args)
        {
            int n1, n2, n3;
            Console.WriteLine("Comparing Numbers: ");
            Console.WriteLine("\n Enter the first number: ");
            n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\n Enter the second number: ");
            n2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\n Enter the third number: ");
            n3 = Convert.ToInt32(Console.ReadLine());

            if (n1 > n2 && n1 > n3)
            {
                Console.WriteLine("\n{0} is greater than {1 and {2}", n1, n2, n3);
                Console.WriteLine("{0} is less than {1}", n2, n1);
                Console.WriteLine("{0} is less than {1}", n3, n1);
                Console.ReadLine();
            }
            else if (n2 > n1 && n2 > n3)
            {
                Console.WriteLine("\n{0} is greater than {1 and {2}", n2, n1, n3);
                Console.WriteLine("{0} is less than {1}", n1, n2);
                Console.WriteLine("{0} is less than {1}", n3, n2);
                Console.ReadLine();
            }
            else if (n3 > n1 && n3 > n2)
            {
                Console.WriteLine("\n{0} is greater than {1} and {2}", n3, n1, n2);
                Console.WriteLine("{0} is less than {1}", n1, n3);
                Console.WriteLine("{0} is less than {1}", n2, n3);
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("\nThe numbers {0}, {1}, and {2} are equal", n1, n2, n3);
                Console.ReadLine();
            }
        }
    }
}
