﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 15, 2022
 *  Display the input name by the user
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Sample3_InputMyName
    {
        internal class Program
            {
                static void Main(string[] args)
                    {
                        // Get input name
                        Console.WriteLine("Enter your name [FN LN]:  ");
                        string name = Console.ReadLine();           // Read and store input in a string

                    
                        // Display
                        Console.WriteLine("\n\nHello " + name + "!");
                        Console.WriteLine("Welcome to OOP environment.");
                        Console.ReadKey();
                    }
            }
    }
