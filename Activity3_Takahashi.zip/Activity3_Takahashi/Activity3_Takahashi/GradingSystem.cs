﻿using System;

namespace Activity3_Takahashi
{
    class GradingSystem
    {
        static void Main(string[] args)
        {
            int number1;
            int number2;
            int number3;
       
            Console.WriteLine("Enter 1st number:");
            number1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter 2nd number:");
            number2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter 3rd number:");
            number3 = Convert.ToInt32(Console.ReadLine());

            if (number1 > number2 && number1 > number3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", number1, number2, number3);
                Console.WriteLine("{0} is less than {1} ", number2, number1);
                Console.WriteLine("{0} is less than {1} ", number3, number1);
            }
        }
    }
}
