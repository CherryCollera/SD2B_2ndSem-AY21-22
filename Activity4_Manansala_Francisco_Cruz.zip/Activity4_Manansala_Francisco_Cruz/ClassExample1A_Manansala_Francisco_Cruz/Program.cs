﻿using System;

namespace ClassExample1A_Manansala_Francisco_Cruz
{
    class Program
    {
        static void Main(string[] args)
        {
            Accept accept = new Accept();
            accept.AcceptDetails();

            Print print = new Print();
            print.PrintDetails(accept.firstname, accept.lastname);

            MyProfile profile = new MyProfile();
            profile.DisplayProfile();
            Console.ReadLine();
        }
    }
}
