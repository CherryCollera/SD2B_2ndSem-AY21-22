﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Group8_Mendoza
{
     class MyProfile
    {
        public void DisplayProfile()
        {
            Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E");
            Console.WriteLine("Name:\t\t\tCarl Joseph Mendoza ");
            Console.WriteLine("Birthday:\t\tOctober 23, 2002 ");
            Console.WriteLine("Course:\t\t\tBS in Computer Science Major in Software Development");
            Console.WriteLine("Year:\t\t\t2nd Year");
            Console.WriteLine("Section:\t\tB ");
        }
    }
}
