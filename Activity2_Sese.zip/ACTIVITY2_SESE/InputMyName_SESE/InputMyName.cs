﻿//This Program will display the name that I inputted

using System;

namespace InputMyName_SESE
{
    class InputMyName
    {
        static void Main(string[] args)
        {
            String firstname, lastname;
            Console.Write("Enter your Name:" +
                "(Firstname Lastname) ");
            firstname = Console.ReadLine();
            lastname = Console.ReadLine();

            Console.WriteLine("\nHello " + firstname
                + " " + lastname + "!!!"
                + "\nWelcome to OOP Environment.");
            Console.ReadKey();
        }
    }
}
