﻿//This Program will show for loop

using System;

namespace For_Casaña
{
    class For
    {
        static void Main(string[] args)
        {
            //for i = 10 minus 1 loop stop until i is equal to zero
            for (int i = 10 - 1; i >= 0; i--)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
