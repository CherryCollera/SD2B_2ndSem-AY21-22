﻿/*
 * student Id number : 20-05258
 * student full name : Zedrick A. Mojica
 * Section : BSCS-SD2B
 * Date : 17/04/2022
 * Purpose : getting final grade, grade equivalent and remarks.
 */
using System;

namespace GradingSystem_Mojica
{
    class GradingSystem
    {
        static void Main()
        {
            Console.Write("Enter your final grade: ");
            string input = Console.ReadLine();


            if (input.ToLower() == "inc")
            {
                Console.WriteLine("Grade Equivalent: Incomplete");
            }
            else
            {
                int grade = Convert.ToInt32(input);
                if (grade >= 98 && grade <= 100)
                {
                    Console.WriteLine("Grade Equivalent: 1.00");
                    Console.WriteLine("Remarks: Excellent");
                }
                else if (grade >= 95 && grade <= 97)
                {
                    Console.WriteLine("Grade Equivalent: 1.25");
                    Console.WriteLine("Remarks: Very Good");
                }
                else if (grade >= 92 && grade <= 94)
                {
                    Console.WriteLine("Grade Equivalent: 1.50");
                    Console.WriteLine("Remarks: Very Good");
                }
                else if (grade >= 89 && grade <= 91)
                {
                    Console.WriteLine("Grade Equivalent: 1.75");
                    Console.WriteLine("Remarks: Very Good");
                }
                else if (grade >= 86 && grade <= 88)
                {
                    Console.WriteLine("Grade Equivalent: 2.00");
                    Console.WriteLine("Remarks: Good");
                }
                else if (grade >= 83 && grade <= 85)
                {
                    Console.WriteLine("Grade Equivalent: 2.25");
                    Console.WriteLine("Remarks: Good");
                }
                else if (grade >= 80 && grade <= 82)
                {
                    Console.WriteLine("Grade Equivalent: 2.50");
                    Console.WriteLine("Remarks: Fair");
                }
                else if (grade >= 77 && grade <= 79)
                {
                    Console.WriteLine("Grade Equivalent: 2.75");
                    Console.WriteLine("Remarks: Passed");
                }
                else if (grade >= 75 && grade <= 76)
                {
                    Console.WriteLine("Grade Equivalent: 3.00");
                    Console.WriteLine("Remarks: Passed");
                }
                else if (grade >= 72 && grade <= 74)
                {
                    Console.WriteLine("Grade Equivalent: 4.00");
                    Console.WriteLine("Remarks: Conditional");
                }
                else if (grade >= 60 && grade <= 71)
                {
                    Console.WriteLine("Grade Equivalent: 5.00");
                    Console.WriteLine("Remarks: Failed");
                }
                else
                {
                    Console.WriteLine("Invalid Input!");
                }
            }
            
            Console.ReadKey();
        }
    }
}