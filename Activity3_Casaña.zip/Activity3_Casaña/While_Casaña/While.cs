﻿//This Program will show while loop

using System;

namespace While_Casaña
{
    class While
    {
        static void Main(string[] args)
        {
            int i = 0;

            //While i is less than 10, variable i increments
            while (i < 10)
            {
                Console.Write("While Statement ");
                Console.WriteLine(i);
                i++;
            }
            Console.ReadLine();
        }
    }
}
