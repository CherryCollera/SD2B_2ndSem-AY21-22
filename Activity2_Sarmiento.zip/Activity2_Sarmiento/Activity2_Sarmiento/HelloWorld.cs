﻿/*20-00613
Marian Gillian G. Sarmiento
SD2B
April 5, 2022
This program will display the phrase "Hello World"*/

using System;

namespace Activity2_Sarmiento
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.ReadKey();
        }
    }
}
