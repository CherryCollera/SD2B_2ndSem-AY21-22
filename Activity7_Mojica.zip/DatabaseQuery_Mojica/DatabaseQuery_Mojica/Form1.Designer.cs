﻿namespace DatabaseQuery_Mojica
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cartmanCollegeDataSet = new DatabaseQuery_Mojica.CartmanCollegeDataSet();
            this.tblStudentsTableAdapter = new DatabaseQuery_Mojica.CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter();
            this.Btn_HighGPA = new System.Windows.Forms.Button();
            this.Btn_ShowRecords = new System.Windows.Forms.Button();
            this.btnGradeStats = new System.Windows.Forms.Button();
            this.labelCount = new System.Windows.Forms.Label();
            this.labelMin = new System.Windows.Forms.Label();
            this.labelMax = new System.Windows.Forms.Label();
            this.labelAverage = new System.Windows.Forms.Label();
            this.btn_GroupRecords = new System.Windows.Forms.Button();
            this.listBox_HighGPA = new System.Windows.Forms.ListBox();
            this.listBox_MinGPA = new System.Windows.Forms.ListBox();
            this.listBox_GroupGPA = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textbox_MinGPA = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(834, 280);
            this.dataGridView1.TabIndex = 0;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.Width = 125;
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            this.lastNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            this.firstNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            this.gradePointAverageDataGridViewTextBoxColumn.Width = 125;
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet;
            // 
            // cartmanCollegeDataSet
            // 
            this.cartmanCollegeDataSet.DataSetName = "CartmanCollegeDataSet";
            this.cartmanCollegeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // Btn_HighGPA
            // 
            this.Btn_HighGPA.Location = new System.Drawing.Point(40, 307);
            this.Btn_HighGPA.Name = "Btn_HighGPA";
            this.Btn_HighGPA.Size = new System.Drawing.Size(222, 45);
            this.Btn_HighGPA.TabIndex = 1;
            this.Btn_HighGPA.Text = "Show Students With High GPA";
            this.Btn_HighGPA.UseVisualStyleBackColor = true;
            this.Btn_HighGPA.Click += new System.EventHandler(this.BtnHighGPA_Click);
            // 
            // Btn_ShowRecords
            // 
            this.Btn_ShowRecords.Location = new System.Drawing.Point(377, 307);
            this.Btn_ShowRecords.Name = "Btn_ShowRecords";
            this.Btn_ShowRecords.Size = new System.Drawing.Size(200, 45);
            this.Btn_ShowRecords.TabIndex = 2;
            this.Btn_ShowRecords.Text = "Show Records";
            this.Btn_ShowRecords.UseVisualStyleBackColor = true;
            this.Btn_ShowRecords.Click += new System.EventHandler(this.Btn_ShowRecords_Click);
            // 
            // btnGradeStats
            // 
            this.btnGradeStats.Location = new System.Drawing.Point(884, 32);
            this.btnGradeStats.Name = "btnGradeStats";
            this.btnGradeStats.Size = new System.Drawing.Size(169, 36);
            this.btnGradeStats.TabIndex = 3;
            this.btnGradeStats.Text = "View Grade Statistics";
            this.btnGradeStats.UseVisualStyleBackColor = true;
            this.btnGradeStats.Click += new System.EventHandler(this.btnGradeStats_Click);
            // 
            // labelCount
            // 
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new System.Drawing.Point(881, 89);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new System.Drawing.Size(44, 16);
            this.labelCount.TabIndex = 4;
            this.labelCount.Text = "label1";
            // 
            // labelMin
            // 
            this.labelMin.AutoSize = true;
            this.labelMin.Location = new System.Drawing.Point(881, 130);
            this.labelMin.Name = "labelMin";
            this.labelMin.Size = new System.Drawing.Size(44, 16);
            this.labelMin.TabIndex = 5;
            this.labelMin.Text = "label2";
            // 
            // labelMax
            // 
            this.labelMax.AutoSize = true;
            this.labelMax.Location = new System.Drawing.Point(881, 171);
            this.labelMax.Name = "labelMax";
            this.labelMax.Size = new System.Drawing.Size(44, 16);
            this.labelMax.TabIndex = 6;
            this.labelMax.Text = "label3";
            // 
            // labelAverage
            // 
            this.labelAverage.AutoSize = true;
            this.labelAverage.Location = new System.Drawing.Point(881, 211);
            this.labelAverage.Name = "labelAverage";
            this.labelAverage.Size = new System.Drawing.Size(44, 16);
            this.labelAverage.TabIndex = 7;
            this.labelAverage.Text = "label4";
            // 
            // btn_GroupRecords
            // 
            this.btn_GroupRecords.Location = new System.Drawing.Point(1059, 32);
            this.btn_GroupRecords.Name = "btn_GroupRecords";
            this.btn_GroupRecords.Size = new System.Drawing.Size(182, 36);
            this.btn_GroupRecords.TabIndex = 8;
            this.btn_GroupRecords.Text = "Group Records by GPA";
            this.btn_GroupRecords.UseVisualStyleBackColor = true;
            this.btn_GroupRecords.Click += new System.EventHandler(this.btn_GroupRecordsGPA_Click);
            // 
            // listBox_HighGPA
            // 
            this.listBox_HighGPA.FormattingEnabled = true;
            this.listBox_HighGPA.ItemHeight = 16;
            this.listBox_HighGPA.Location = new System.Drawing.Point(40, 358);
            this.listBox_HighGPA.Name = "listBox_HighGPA";
            this.listBox_HighGPA.Size = new System.Drawing.Size(222, 132);
            this.listBox_HighGPA.TabIndex = 9;
            // 
            // listBox_MinGPA
            // 
            this.listBox_MinGPA.FormattingEnabled = true;
            this.listBox_MinGPA.ItemHeight = 16;
            this.listBox_MinGPA.Location = new System.Drawing.Point(377, 358);
            this.listBox_MinGPA.Name = "listBox_MinGPA";
            this.listBox_MinGPA.Size = new System.Drawing.Size(200, 132);
            this.listBox_MinGPA.TabIndex = 10;
            // 
            // listBox_GroupGPA
            // 
            this.listBox_GroupGPA.FormattingEnabled = true;
            this.listBox_GroupGPA.ItemHeight = 16;
            this.listBox_GroupGPA.Location = new System.Drawing.Point(1059, 95);
            this.listBox_GroupGPA.Name = "listBox_GroupGPA";
            this.listBox_GroupGPA.Size = new System.Drawing.Size(200, 276);
            this.listBox_GroupGPA.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(586, 307);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 16);
            this.label5.TabIndex = 12;
            this.label5.Text = "Enter Minimum GPA : ";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // textbox_MinGPA
            // 
            this.textbox_MinGPA.Location = new System.Drawing.Point(718, 304);
            this.textbox_MinGPA.Name = "textbox_MinGPA";
            this.textbox_MinGPA.Size = new System.Drawing.Size(128, 22);
            this.textbox_MinGPA.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1274, 564);
            this.Controls.Add(this.textbox_MinGPA);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.listBox_GroupGPA);
            this.Controls.Add(this.listBox_MinGPA);
            this.Controls.Add(this.listBox_HighGPA);
            this.Controls.Add(this.btn_GroupRecords);
            this.Controls.Add(this.labelAverage);
            this.Controls.Add(this.labelMax);
            this.Controls.Add(this.labelMin);
            this.Controls.Add(this.labelCount);
            this.Controls.Add(this.btnGradeStats);
            this.Controls.Add(this.Btn_ShowRecords);
            this.Controls.Add(this.Btn_HighGPA);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CartmanCollegeDataSet cartmanCollegeDataSet;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button Btn_HighGPA;
        private System.Windows.Forms.Button Btn_ShowRecords;
        private System.Windows.Forms.Button btnGradeStats;
        private System.Windows.Forms.Label labelCount;
        private System.Windows.Forms.Label labelMin;
        private System.Windows.Forms.Label labelMax;
        private System.Windows.Forms.Label labelAverage;
        private System.Windows.Forms.Button btn_GroupRecords;
        private System.Windows.Forms.ListBox listBox_HighGPA;
        private System.Windows.Forms.ListBox listBox_MinGPA;
        private System.Windows.Forms.ListBox listBox_GroupGPA;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textbox_MinGPA;
    }
}

