﻿/*
 * student Id number : 20-05258
 * student full name : Zedrick A. Mojica
 * Section : BSCS-SD2B
 * Date : 04/04/2022
 * Purpose : compute the area of the radius
 */
using System;

namespace Activity2_Mojica
{
    class DeclaringConstants
    {
        static void Main(string[] args)
        {
            const double pi = 3.14159;
            double radius;
            System.Console.Write("Enter radius: ");
            radius = Convert.ToDouble(Console.ReadLine());
            System.Console.WriteLine("Radius: "+ radius + ", Area: "+ pi*radius*radius);
            System.Console.ReadKey();
        }
    }
}