﻿/*
 * student Id number : 20-05258
 * student full name : Zedrick A. Mojica
 * Section : BSCS-SD2B
 * Date : 04/04/2022
 * Purpose : compare three numbers to check what is larger
 */
using System;

namespace Activity2_Mojica
{
    class IfElse2
    {
        static void Main(string[] args)
        {
            int num1, num2 ,num3;
            System.Console.Write("Enter first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            System.Console.Write("Enter second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            System.Console.Write("Enter third number: ");
            num3 = Convert.ToInt32(Console.ReadLine());
            if ((num1 > num2) && (num1 > num3))
            {
                System.Console.Write(num1 + " is greater than " + num2 + " and " + num3);
            }
            else if ((num2 > num1) && (num2 > num3))
            {
                System.Console.Write(num2 + " is greater than " + num1 + " and " + num3);
            }
            else if ((num3 > num1) && (num3 > num2))
            {
                System.Console.Write(num3 + " is greater than " + num1 + " and " + num2);
            }
            else
            {
                System.Console.Write(num3 + " is equal to " + num1 + " and " + num2);
            }
            System.Console.ReadKey();
        }
    }
}