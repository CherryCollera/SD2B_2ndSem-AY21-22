﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 15, 2022
 * Program to determine if a is greater/lower/equal to b
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace IfElse1
    {
        internal class Program
            {
                static void Main(string[] args)
                    {
                        Console.WriteLine("Enter first number: ");
                        int num1 = int.Parse(Console.ReadLine());           // Read and store input 

                        Console.WriteLine("Enter second number: ");
                        int num2 = int.Parse(Console.ReadLine());           // Read and store input 


                        // Determine their relationship
                        if (num1 < num2)                        
                            Console.WriteLine("A is less than B");                             

                        else if (num1 > num2)                        
                            Console.WriteLine("A is greater than B");     
                        else if (num1 == num2)
                            Console.WriteLine("A is equal than B");     
                        else
                            Console.WriteLine("ERROR");
                    }
            }
    }
