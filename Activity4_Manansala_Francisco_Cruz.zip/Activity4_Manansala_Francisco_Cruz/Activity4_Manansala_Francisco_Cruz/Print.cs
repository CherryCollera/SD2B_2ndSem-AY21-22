﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Manansala_Francisco_Cruz
{
    class Print
    { 
        public void PrintDetails()
        {
            Accept accept = new Accept();
            accept.AcceptDetails();

            System.Console.Write("\nHello " + accept.firstname + " " + accept.lastname
                + "!!!\nYou have created a class in OOP!");

            MyProfile profile = new MyProfile();
            profile.DisplayProfile();
        }
    }
}

