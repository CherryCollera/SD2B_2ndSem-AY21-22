﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Medina
{
    class Remainder
    {
        public void ComputeRemainder()
        {
            DeclareVar.r = DeclareVar.num1 % DeclareVar.num2; //compute the remainder of two input values
        }
    }
}
