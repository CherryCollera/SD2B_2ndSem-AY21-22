﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 15, 2022
 *  Display "Hello world! I am Dianna!"
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Sample1_HelloWorld
    {
        internal class Program
            {
                static void Main(string[] args)
                    {
                        // Display
                        Console.WriteLine("Hello world! I am Dianna!");
                        Console.ReadKey();
                    }
            }
    }
