﻿using System;

namespace Switch_Casaña
{
    class Switch
    {
        static void Main(string[] args)
        {
            String name;
            char gender;

            //Enter name and gender
            Console.Write("Enter your name: ");
            name = Console.ReadLine();
            Console.Write("Enter your gender M/F: ");
            gender = Convert.ToChar(Console.ReadLine());

            //Display based on your gender input
            switch (gender)
            {
                case 'M': case 'm':
                    Console.WriteLine("\nHi " + name + "!"
                        + (" Your gender is Male!"));
                    break;

                case 'F': case 'f':
                    Console.WriteLine("\nHi " + name + "!"
                        + (" Your gender is Female!"));
                    break;
                default:
                    Console.WriteLine("\nInvalid Input... Try Again...");
                    break;
            }
            Console.ReadKey();
        }
    }
}
