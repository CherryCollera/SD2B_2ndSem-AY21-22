﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACT4_GROUP8
{
    internal class Declaration
    {
        public string Color //Gets the value of "Color" from Program class.
        {
            get
            {
                return Color;
            }
            set
            {
                Color = value;
            }
        }
    }
}
