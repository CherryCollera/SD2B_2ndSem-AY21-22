﻿/* Creating classes in OOP
 * Author: Carl Joseph Mendoza
 * Date: April 27, 2022
 */
using System;
namespace ClassExample1_Group8_Mendoza
{
    class Program
{
    static void Main(string[] args)
    {
        Print p = new Print();  
        p.PrintDetails();
        Console.ReadLine();

    }
}
}