﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Mendoza
{
     class Sum
    {
        public void ComputeSum()
        {
            DeclareVar.sum = DeclareVar.num1 + DeclareVar.num2;

        }
    }
}
