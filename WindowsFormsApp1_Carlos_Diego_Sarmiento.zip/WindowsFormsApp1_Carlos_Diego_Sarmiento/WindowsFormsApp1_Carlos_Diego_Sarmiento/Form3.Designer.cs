﻿
namespace WindowsFormsApp1_Carlos_Diego_Sarmiento
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_MyProfile = new System.Windows.Forms.Label();
            this.lbl_Firstname = new System.Windows.Forms.Label();
            this.lbl_Lastname = new System.Windows.Forms.Label();
            this.txt_Firstname = new System.Windows.Forms.TextBox();
            this.txt_Lastname = new System.Windows.Forms.TextBox();
            this.btn_GetMyProfile = new System.Windows.Forms.Button();
            this.btn_Hide = new System.Windows.Forms.Button();
            this.btn_Back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_MyProfile
            // 
            this.lbl_MyProfile.AutoSize = true;
            this.lbl_MyProfile.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.lbl_MyProfile.Location = new System.Drawing.Point(310, 42);
            this.lbl_MyProfile.Name = "lbl_MyProfile";
            this.lbl_MyProfile.Size = new System.Drawing.Size(151, 32);
            this.lbl_MyProfile.TabIndex = 0;
            this.lbl_MyProfile.Text = "My Profile";
            // 
            // lbl_Firstname
            // 
            this.lbl_Firstname.AutoSize = true;
            this.lbl_Firstname.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.lbl_Firstname.Location = new System.Drawing.Point(62, 138);
            this.lbl_Firstname.Name = "lbl_Firstname";
            this.lbl_Firstname.Size = new System.Drawing.Size(157, 32);
            this.lbl_Firstname.TabIndex = 1;
            this.lbl_Firstname.Text = "Firstname:";
            // 
            // lbl_Lastname
            // 
            this.lbl_Lastname.AutoSize = true;
            this.lbl_Lastname.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.lbl_Lastname.Location = new System.Drawing.Point(66, 183);
            this.lbl_Lastname.Name = "lbl_Lastname";
            this.lbl_Lastname.Size = new System.Drawing.Size(153, 32);
            this.lbl_Lastname.TabIndex = 2;
            this.lbl_Lastname.Text = "Lastname:";
            // 
            // txt_Firstname
            // 
            this.txt_Firstname.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.txt_Firstname.Location = new System.Drawing.Point(236, 138);
            this.txt_Firstname.Name = "txt_Firstname";
            this.txt_Firstname.Size = new System.Drawing.Size(312, 39);
            this.txt_Firstname.TabIndex = 3;
            // 
            // txt_Lastname
            // 
            this.txt_Lastname.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.txt_Lastname.Location = new System.Drawing.Point(236, 183);
            this.txt_Lastname.Name = "txt_Lastname";
            this.txt_Lastname.Size = new System.Drawing.Size(312, 39);
            this.txt_Lastname.TabIndex = 4;
            // 
            // btn_GetMyProfile
            // 
            this.btn_GetMyProfile.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.btn_GetMyProfile.Location = new System.Drawing.Point(68, 260);
            this.btn_GetMyProfile.Name = "btn_GetMyProfile";
            this.btn_GetMyProfile.Size = new System.Drawing.Size(231, 63);
            this.btn_GetMyProfile.TabIndex = 5;
            this.btn_GetMyProfile.Text = "Get My Profile";
            this.btn_GetMyProfile.UseVisualStyleBackColor = true;
            this.btn_GetMyProfile.Click += new System.EventHandler(this.btn_GetMyProfile_Click);
            // 
            // btn_Hide
            // 
            this.btn_Hide.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.btn_Hide.Location = new System.Drawing.Point(331, 260);
            this.btn_Hide.Name = "btn_Hide";
            this.btn_Hide.Size = new System.Drawing.Size(130, 63);
            this.btn_Hide.TabIndex = 6;
            this.btn_Hide.Text = "Hide";
            this.btn_Hide.UseVisualStyleBackColor = true;
            this.btn_Hide.Click += new System.EventHandler(this.btn_Hide_Click);
            // 
            // btn_Back
            // 
            this.btn_Back.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.btn_Back.Location = new System.Drawing.Point(502, 260);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(130, 63);
            this.btn_Back.TabIndex = 7;
            this.btn_Back.Text = "Back";
            this.btn_Back.UseVisualStyleBackColor = true;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(701, 421);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.btn_Hide);
            this.Controls.Add(this.btn_GetMyProfile);
            this.Controls.Add(this.txt_Lastname);
            this.Controls.Add(this.txt_Firstname);
            this.Controls.Add(this.lbl_Lastname);
            this.Controls.Add(this.lbl_Firstname);
            this.Controls.Add(this.lbl_MyProfile);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_MyProfile;
        private System.Windows.Forms.Label lbl_Firstname;
        private System.Windows.Forms.Label lbl_Lastname;
        private System.Windows.Forms.TextBox txt_Firstname;
        private System.Windows.Forms.TextBox txt_Lastname;
        private System.Windows.Forms.Button btn_GetMyProfile;
        private System.Windows.Forms.Button btn_Hide;
        private System.Windows.Forms.Button btn_Back;
    }
}