﻿/*MIDTERMS CASE STUDY
 * MEMBERS: CARLOS, ROIEL A.
 *          DIEGO, ANGELO R.
 *          SARMIENTO, MARIAN GILLIAN G.
 * 
 * This form will display a message box and then go to calculator form.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidtermCaseStudy_Carlos_Diego_Sarmiento
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnMessage_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hello", "My Message", MessageBoxButtons.YesNo,
                MessageBoxIcon.Information);
            Calculator calc = new Calculator();
            calc.Show();
            this.Hide();
        }
    }
}
