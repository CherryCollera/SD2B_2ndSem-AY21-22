﻿/*
 20-01076
Noel M. Gallo Jr.
SD2B
April 7, 2022
This program will Compute the area of a circle
 */
using System;

namespace DeclaringConstant
{

    class DeclaringConstant
    {

        public static void Main(string[] args)
        {
            int rad;
            System.Console.Write("Enter Radius: ");
            rad = Convert.ToInt32(Console.ReadLine());
            double Area = 3.14159 * rad*rad;
            System.Console.WriteLine("\nRadius: {0}, Area: {1}",rad.ToString("0.0000"), Area.ToString("##.####"));
            System.Console.ReadKey();
        }
    }
}

