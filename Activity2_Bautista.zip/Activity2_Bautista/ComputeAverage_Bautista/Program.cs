﻿/** ===========================
 Name: Reywen Lee Bautista
 Course & Section: BSCS-SD2B
 Date: April 1, 2022
=============================*/

using System;

namespace ComputeAverage_Bautista
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] nums = new double[6]; nums[5] = 0;

            Console.WriteLine("Enter 5 grades");

            for (int i = 0; i < 5; i++)
            {
                nums[i] = Convert.ToInt32(Console.ReadLine());
                nums[5] += nums[i];
            }

            Console.WriteLine("The Average is {0:0.000}", nums[5] / 5);
            Console.ReadKey();
        }
    }
}
