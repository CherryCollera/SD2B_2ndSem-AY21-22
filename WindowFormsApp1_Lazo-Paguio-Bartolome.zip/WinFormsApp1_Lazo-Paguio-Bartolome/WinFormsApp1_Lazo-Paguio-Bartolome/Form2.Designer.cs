﻿namespace WinFormsApp1_Lazo_Paguio_Bartolome
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.fname = new System.Windows.Forms.Label();
            this.lname = new System.Windows.Forms.Label();
            this.tbFname = new System.Windows.Forms.TextBox();
            this.tbLname = new System.Windows.Forms.TextBox();
            this.getMessage = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(236, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Firsname";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 0;
            // 
            // fname
            // 
            this.fname.AutoSize = true;
            this.fname.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fname.Location = new System.Drawing.Point(160, 89);
            this.fname.Name = "fname";
            this.fname.Size = new System.Drawing.Size(94, 25);
            this.fname.TabIndex = 0;
            this.fname.Text = "Firstname";
            // 
            // lname
            // 
            this.lname.AutoSize = true;
            this.lname.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lname.Location = new System.Drawing.Point(160, 133);
            this.lname.Name = "lname";
            this.lname.Size = new System.Drawing.Size(92, 25);
            this.lname.TabIndex = 1;
            this.lname.Text = "Lastname";
            this.lname.Click += new System.EventHandler(this.lname_Click);
            // 
            // tbFname
            // 
            this.tbFname.Location = new System.Drawing.Point(274, 91);
            this.tbFname.Name = "tbFname";
            this.tbFname.Size = new System.Drawing.Size(150, 23);
            this.tbFname.TabIndex = 2;
            this.tbFname.TextChanged += new System.EventHandler(this.tbFname_TextChanged);
            // 
            // tbLname
            // 
            this.tbLname.Location = new System.Drawing.Point(274, 138);
            this.tbLname.Name = "tbLname";
            this.tbLname.Size = new System.Drawing.Size(150, 23);
            this.tbLname.TabIndex = 3;
            // 
            // getMessage
            // 
            this.getMessage.Location = new System.Drawing.Point(214, 206);
            this.getMessage.Name = "getMessage";
            this.getMessage.Size = new System.Drawing.Size(130, 44);
            this.getMessage.TabIndex = 4;
            this.getMessage.Text = "Get Message";
            this.getMessage.UseVisualStyleBackColor = true;
            this.getMessage.Click += new System.EventHandler(this.getMessage_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(475, 259);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "Hide";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.ClientSize = new System.Drawing.Size(637, 361);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.getMessage);
            this.Controls.Add(this.tbLname);
            this.Controls.Add(this.tbFname);
            this.Controls.Add(this.lname);
            this.Controls.Add(this.fname);
            this.Name = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Label fname;
        private Label lname;
        private TextBox tbFname;
        private TextBox tbLname;
        private Button getMessage;
        private Button button1;
    }
}