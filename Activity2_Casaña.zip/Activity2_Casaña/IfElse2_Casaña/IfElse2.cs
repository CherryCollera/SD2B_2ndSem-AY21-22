﻿using System;

namespace IfElse2_Casaña
{
    class IfElse2
    {
        static void Main(string[] args)
        {
            //Declare Variables
            int num1, num2, num3;

            //Input data to num1, num2, and num3
            Console.Write("\nEnter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Third Number: ");
            num3 = Convert.ToInt32(Console.ReadLine());

            //Display if the first number is greater than the Second number and the third number
            if (num1 > num2 && num1 > num3)
            {
                Console.WriteLine(num1 + " is greater than "
                    + num2 + " and " + num3);
                Console.ReadLine();
            }

            //Display if the second number  is greater than the first number and the third number
            else if (num2 > num1 && num2 > num3)
            {
                Console.WriteLine(num2 + " is greater than "
                    + num1 + " and " + num3);
                Console.ReadLine();
            }

            //Display if the third number  is greater than the first number and the second number
            else
            {
                Console.WriteLine(num3 + " is greater than "
                    + num1 + " and " + num2);
                Console.ReadLine();
            }
        }
    }
}
