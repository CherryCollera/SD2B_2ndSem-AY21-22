﻿/*20-03361
 Adrian D. Fabian
SD2B
April 7, 2022
This Program will display My Profile*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyProfile_Fabian
{
    class MyProfile
    {
        static void Main(string[] args)
        {
            string Name;
            Console.WriteLine("Name: ");
            Name = Console.ReadLine();
            string birthday;
            Console.WriteLine("Date of Birth: ");
            birthday = Console.ReadLine();
            string course;
            Console.WriteLine("Course: ");
            course = Console.ReadLine();
            string Year;
            Console.WriteLine("Year: ");
            Year = Console.ReadLine();
            string Section;
            Console.WriteLine("Section:  ");
            Section = Console.ReadLine();
            System.Console.ReadKey();
        }
    }
}
