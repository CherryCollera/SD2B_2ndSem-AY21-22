﻿/*
20-02190 
Borboran, Keanu Dave
This program will compute for the sum of 2 numbers*/



namespace ComputeTheSum_Borboran
{
    class ComputeTheSum
    {
        static void Main(string[] args)
        {
            int num1, num2;

            Console.Write("Enter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Sum = {0} ", num1 + num2);
            Console.ReadLine();
        }
    }
}