﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample2_Anilao_Casaña_Sese
{
    class Declaration
    {
        private static string color;
        public static String Color
        {
            get
                { return color; }
            set
                { color = value; }
        }
    }
}
