﻿/*  ACTIVITY 8 : DATABASE CONNECTION 
 *  GRP 9
 *  Members:    Medina, Angelica D.
 *              Silva, Alyssa Mae T.
 *              Takahashi, Aira M. 
 */


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.Common;

namespace DatabaseConnection_Medina_Silva_Takahashi
{
    public partial class Form1 : Form
    {

        private OleDbConnection bookConn;
        private OleDbCommand oleDbCmd = new OleDbCommand();

        //private String connParam = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\admin\source\repos\DatabaseConnection_Medina_Silva_Takahashi\book3.mdb;Persist Security Info=False";
        private String connParam = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\admin\source\repos\DatabaseConnection_Medina_Silva_Takahashi\book3.mdb;Persist Security Info=False";

        private int bookID;

        public Form1()
        {
            bookConn = new OleDbConnection(connParam);

            InitializeComponent();

            //Disabling the save button and having datagridview on read only.
            btnSave.Enabled = false;
            dataGridView1.ReadOnly = true;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'book3DataSet1.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter1.Fill(this.book3DataSet1.bookrecords);
            // TODO: This line of code loads data into the 'book3DataSet.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter.Fill(this.book3DataSet.bookrecords);

            Graphics g = this.CreateGraphics();
            double fw = this.Width; // form width
            double tw = g.MeasureString(this.Text.Trim(), this.Font).Width;
            double rp = (fw - tw) / 2.5;
            int tt = Convert.ToInt32(rp);
            string st = " ";
            st = st.PadRight(tt / 3);
            this.Text = st + this.Text.Trim();
        }

        private void clearAll()
        {
            txtTitle.Clear();
            txtDescription.Clear();
            txtBookNo.Clear();
            bookID = 0;
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            if (txtTitle.Text != "" && txtBookNo.Text != "" && txtDescription.Text != "")
            {
                bookConn.Open();
                oleDbCmd.Connection = bookConn;
                oleDbCmd.CommandText = "Insert into bookrecords (booktitle, description, bookno) " +
                    "values ('" + this.txtTitle.Text + "' , '" + this.txtDescription.Text + "' , '" + this.txtBookNo.Text + "');";
                int temp = oleDbCmd.ExecuteNonQuery();
                if (temp > 0)
                {
                    clearAll();

                    MessageBox.Show("You've Successfully Added a New Record!!");

                }
                else
                {
                    MessageBox.Show("You've FAILED to Add a New Record :( ");
                }
                bookConn.Close();
            }
            else
            {
                MessageBox.Show("Please fill out every field!");
            }
        }

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            bookID = 0;

            txtTitle.Clear();
            txtDescription.Clear();
            txtBookNo.Clear();

            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("SELECT * FROM bookrecords", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("UDPATE * FROM bookrecords", connParam);
            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0], dataTable.Rows[i][1],
                    dataTable.Rows[i][2], dataTable.Rows[i][3]);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (bookID != 0)
            {
                DialogResult del;
                del = MessageBox.Show("Are you sure you want to delete " + txtTitle.Text + "?" , "Delete " + txtTitle.Text + "?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (del == DialogResult.Yes)
                {
                    bookConn.Open();
                    oleDbCmd.Connection = bookConn;
                    oleDbCmd.CommandText = "DELETE FROM bookrecords WHERE ID = " + bookID + ";";
                    int temp = oleDbCmd.ExecuteNonQuery();
                    bookConn.Close();

                    MessageBox.Show(txtTitle.Text + " has been deleted!");

                    txtTitle.Text = null;
                    txtDescription.Text = null;
                    txtBookNo.Text = null;

                    
                }
                else
                {
                    MessageBox.Show("Cancelled");
                    clearAll();
                }
            }
            else
            {
                MessageBox.Show("Please Choose a Record You Want to Delete.");
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (txtTitle.Text != "" || txtDescription.Text != "" || txtBookNo.Text != "")
            {
             
                btnSave.Enabled = true;
                dataGridView1.ReadOnly = false;
                btnAddNew.Enabled = false;
                btnDelete.Enabled = false;
                dataGridView1.Enabled = false;
                btnEdit.Enabled = false;
                btnViewAll.Enabled = false;

                
            }
            else
            {
                MessageBox.Show("Please Choose a Record You Want to Edit.");
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbCmd.Connection = bookConn;
            oleDbCmd.CommandText = "UPDATE bookrecords SET booktitle = '" + this.txtTitle.Text + "' , " +
                "description = '" + txtDescription.Text + "' , bookno = '" + txtBookNo.Text + "' " +
                "WHERE ID = " + bookID + ";";
            int temp = oleDbCmd.ExecuteNonQuery();
            bookConn.Close();

            MessageBox.Show("Successfully SAVED a Record.");

            
            btnSave.Enabled = false;
            btnDelete.Enabled = true;
            btnAddNew.Enabled = true;
            dataGridView1.Enabled = true;
            btnEdit.Enabled = true;
            btnViewAll.Enabled = true;

           
            clearAll();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            bookID = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            txtTitle.Text = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[1].Value);
            txtDescription.Text = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[2].Value);
            txtBookNo.Text = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[3].Value);
        }

       
    }
}

    