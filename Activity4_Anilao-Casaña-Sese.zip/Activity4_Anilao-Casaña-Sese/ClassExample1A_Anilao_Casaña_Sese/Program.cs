﻿/*Activity 4
  Group 5
  Members:
            Anilao, Jean Claudine D.
            Casaña, Regee D.
            Sese, Regie A.
Program and Section: BSCS SD2B
Date: 24/04/2022
This Program will display Class Example number 1A*/

using System;

namespace ClassExample1A_Anilao_Casaña_Sese
{
    class Program
    {
        static void Main(string[] args)
        {
            //Object creation of the class Accept
            Accept accept = new Accept();
            accept.AcceptDetails();     //Calling the method AcceptDetails() from the class Accept

            //Object creation of the class Print
            Print print = new Print();
            print.PrintDetails(accept.firstname, accept.lastname);  //Calling the method PrintDetails() from the class Print

            //Object creation of the class MyProfile
            MyProfile profile = new MyProfile();
            profile.DisplayProfile();   //Calling the method DisplayProfile() from the class MyProfile
            Console.ReadLine();
        }
    }
}
