﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 15, 2022
 *  Display different basic operations using two given numbers
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations
    {
        internal class Program
            {
                static void Main(string[] args)
                    {
                        int result;
                        int x = 50, y = 40;
             
                        // Addition
                        result = (x + y);
                        Console.WriteLine(x + " + " + y + " = " + result);
             
                        // Subtraction
                        result = (x - y);
                        Console.WriteLine(x + " - " + y + " = " + result);
             
                        // Multiplication
                        result = (x * y);
                        Console.WriteLine(x + " * " + y + " = "  + result);
             
                        // Division
                        result = (x / y);
                        Console.WriteLine(x + " / " + y + " = " + result);
             
                        // Modulo
                        // Get the remainder
                        result = (x % y);
                        Console.WriteLine(x + " % " + y + " = " + result);
                    }
            }
    }
