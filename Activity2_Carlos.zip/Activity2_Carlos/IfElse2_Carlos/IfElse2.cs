﻿/*
 * 20-00382
 * Roiel A. Carlos
 * SD2B
 * April 7, 2022
 * This program will compare 3 numbers and display the greatest number.
 */
using System;

namespace IfElse2_Carlos
{
    class IfElse2
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;
            Console.Write("Enter first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter third number: ");
            num3 = Convert.ToInt32(Console.ReadLine());

            //if num1 is greates
            if ((num1 > num2) && (num1 > num3))
                Console.WriteLine(num1 + " is greater than " + num2 + " and " + num3);
            
            //if num2 is greates
            else if ((num2 > num1) && (num2 > num3))
                Console.WriteLine(num2 + " is greater than " + num1 + " and " + num3);
            
            //else num3 is greatest
            else
                Console.WriteLine(num3 + " is greater than " + num1 + " and " + num2);
            Console.ReadKey();
        }
    }
}
