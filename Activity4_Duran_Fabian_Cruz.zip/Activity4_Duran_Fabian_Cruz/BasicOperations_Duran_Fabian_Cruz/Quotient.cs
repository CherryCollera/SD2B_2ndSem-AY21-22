﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicOperations_Duran_Fabian_Cruz
{
    class Quotient
    {
        public void ComputeQuotient()
        {
            DeclareVar.quotient = DeclareVar.num1 / DeclareVar.num2;
        }
    }
}
