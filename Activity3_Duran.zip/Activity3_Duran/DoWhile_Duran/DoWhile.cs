﻿using System;

namespace DoWhile_Duran
{
    class DoWhile
    {
        static void Main(string[] args)
        {
            int[] ArrInt = new int[] { 6, 7, 8, 10 };
            int ArrSum = 0;
            int i = 0;
            do
            {
                ArrSum += ArrInt[i];
                i++;
            } while (i < 4);

            Console.WriteLine(ArrSum);
            Console.ReadKey();
        }
    }
}
