﻿using System;

namespace ClassExample2_Manansala_Francisco_Cruz
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car;
            car = new Car("black");
            Console.WriteLine(car.Describe());
            car = new Car("white");
            Console.WriteLine(car.Describe());
            Console.ReadLine();
        }
    }
}
