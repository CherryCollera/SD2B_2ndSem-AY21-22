﻿using System;

namespace ClassExample1A_Duran_Fabian_Cruz
{
    class Program
    {
        static void Main(string[] args)
        {
            Accept a = new Accept();
            a.AcceptDetails();
            Print p = new Print();
            p.PrintDetails(a.firstname, a.lastname);
            MyProfile mp = new MyProfile();
            mp.DisplayProfile();
        }
    }
}
