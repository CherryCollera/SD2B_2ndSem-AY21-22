﻿/*
 * Group number: 2
 * Group Members: Gallo, Noel Jr. 
                  Mojica, Zedrick
                  Enriquez, John Brix
 * Section : BSCS-SD2B
 * Date : 26/04/2022
 * Purpose : using methods to get an input and print it 
 */
using System;

namespace ClassExample1_Gallo_Mojica_Enriquez
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Accept accept = new Accept();
            accept.AcceptDetails();     
           
            Print print = new Print();
            print.PrintDetails(accept.firstName, accept.lastName); 
            
            MyProfile profile = new MyProfile();
            profile.DisplayProfile();   
            Console.ReadLine();
        }
    }
}
