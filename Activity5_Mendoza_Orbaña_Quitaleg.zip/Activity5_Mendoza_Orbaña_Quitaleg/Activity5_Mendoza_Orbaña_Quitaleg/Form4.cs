﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity5_Mendoza_Orbaña_Quitaleg
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            int firstnum = Convert.ToInt32(fnumTxt.Text);
            int secondnum = Convert.ToInt32(secnumTxt.Text);

            ansTxt.Text = (firstnum + secondnum).ToString();

        }

        private void subBtn_Click(object sender, EventArgs e)
        {
            int firstnum = Convert.ToInt32(fnumTxt.Text);
            int secondnum = Convert.ToInt32(secnumTxt.Text);

            ansTxt.Text = (firstnum - secondnum).ToString();
        }

        private void mulBtn_Click(object sender, EventArgs e)
        {
            int firstnum = Convert.ToInt32(fnumTxt.Text);
            int secondnum = Convert.ToInt32(secnumTxt.Text);

            ansTxt.Text = (firstnum * secondnum).ToString();
        }

        private void divBtn_Click(object sender, EventArgs e)
        {
            int firstnum = Convert.ToInt32(fnumTxt.Text);
            int secondnum = Convert.ToInt32(secnumTxt.Text);

            ansTxt.Text = (firstnum / secondnum).ToString();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            Form3 form = new Form3();
            form.Show();
            this.Hide();
        }
    }
}
