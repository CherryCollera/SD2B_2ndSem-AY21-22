﻿/* 20 - 01484
 John Brix B. Enriquez
 SD2B
 April 5, 2022
 This program will compute basic operations*/

using System;
namespace BaiscOperations
{
    class BasicOperations
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("Enter the first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\nSum: {0}", num1 + num2);
            Console.WriteLine("Difference = {0}", num1 - num2);
            Console.WriteLine("Product = {0}", num1 * num2);
            Console.WriteLine("Quotient = {0}", num1 / num2);
            Console.WriteLine("Remainder = {0}", num1 % num2);
            Console.ReadKey();

        }
    }
}
