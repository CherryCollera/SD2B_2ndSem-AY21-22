﻿using System;

namespace While_Manansala
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            while (i < 10)
            {
                Console.Write("While Statement ");
                Console.WriteLine(i);
                i++;
            }
            Console.ReadLine();
        }
    }
}
