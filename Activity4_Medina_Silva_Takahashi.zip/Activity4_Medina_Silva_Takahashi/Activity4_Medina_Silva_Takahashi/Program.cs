﻿using System;

namespace Activity4_Medina_Silva_Takahashi
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
