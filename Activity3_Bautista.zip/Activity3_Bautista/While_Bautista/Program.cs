﻿/** ===========================
 Name: Reywen Lee Bautista
 Course & Section: BSCS-SD2B
 Date: April 17, 2021
=============================*/
using System;

namespace While_Bautista
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            while (i <= 10)
            {
                Console.Write("While statement ");
                Console.WriteLine(i);
                i++;
            }
        }
    }
}
