﻿/*
 * student Id number : 20-05258
 * student full name : Zedrick A. Mojica
 * Section : BSCS-SD2B
 * Date : 16/05/2022
 * Purpose : linking database to program
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataGridView_Mojica
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
