﻿/*20-03361
 Adrian D. Fabian
SD2B
April 7, 2022
This Program will display My Profile*/

using System;

namespace HelloWorld_Fabian
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            System.Console.ReadKey();
        }
    }
}