﻿/* Creating classes in OOP
 * Group Members : Roiel A. Carlos
 *                 Angelo R. Diego
 *                 Marian Gillian G. Sarmiento
 * Date: April 25, 2022
 * This program will accept a first name and last name then print a welcome message with it by calling one class.
 * This program will also display the profiles of the group members.
 */

using System;

namespace ClassExample1_Carlos_Diego_Sarmiento
{
    class ClassExample1
    {
        static void Main(string[] args)
        {
            Print p = new Print();
            p.PrintDetails();
            Console.ReadKey();
        }
    }
}
