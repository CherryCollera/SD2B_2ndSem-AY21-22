﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1A_Silva
{
    class Print1a
    {
        public void PrintDetails(string firstname, string lastname)
        {

            //display the string values of firstname and lastname 
            System.Console.WriteLine("Hello " + firstname + " " + lastname + "!!!\n You have now created classes in OOP ");

        }
    }
}