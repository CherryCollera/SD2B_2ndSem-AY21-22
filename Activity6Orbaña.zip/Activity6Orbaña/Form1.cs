﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity6Orbaña
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'information_1DataSet.InformationOfStudent' table. You can move, or remove it, as needed.
            this.informationOfStudentTableAdapter.Fill(this.information_1DataSet.InformationOfStudent);

        }

        private void bSCSToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.informationOfStudentTableAdapter.BSCS(this.information_1DataSet.InformationOfStudent);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void bSITToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.informationOfStudentTableAdapter.BSIT(this.information_1DataSet.InformationOfStudent);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void address_SamalToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.informationOfStudentTableAdapter.Address_Samal(this.information_1DataSet.InformationOfStudent);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void secondYearStudentToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.informationOfStudentTableAdapter.SecondYearStudent(this.information_1DataSet.InformationOfStudent);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void refreshToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.informationOfStudentTableAdapter.Refresh(this.information_1DataSet.InformationOfStudent);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void lastname_A_and_CToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.informationOfStudentTableAdapter.Lastname_A_and_C(this.information_1DataSet.InformationOfStudent);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void section_2BToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.informationOfStudentTableAdapter.Section_2B(this.information_1DataSet.InformationOfStudent);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void firstname_ConsonantToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.informationOfStudentTableAdapter.Firstname_Consonant(this.information_1DataSet.InformationOfStudent);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
