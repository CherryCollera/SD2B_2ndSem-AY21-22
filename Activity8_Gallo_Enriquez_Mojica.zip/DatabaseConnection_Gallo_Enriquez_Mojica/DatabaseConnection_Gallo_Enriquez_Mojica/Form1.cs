﻿using System;
using System.Data;
using System.Data.OleDb;//2
using System.Drawing;
using System.Windows.Forms;

namespace DatabaseConnection_Gallo_Enriquez_Mojica
{
    public partial class Form1 : Form
    {
        int counter;
        int row;
        private int bookID;
        private string Title, Description, BookNum;
        private OleDbConnection bookConn;
        private OleDbCommand oleDbCmd = new OleDbCommand();

        //3 parameter from udl
        private String connParam = @"Provider=Microsoft.ACE.OLEDB.12.0;
                                Data Source = book3.accdb;
                                Persist Security Info = False";  

        public Form1()
        {
            //4 create connection using parameter from udl
            bookConn = new OleDbConnection(connParam);
            InitializeComponent();

            Graphics g = this.CreateGraphics();
            double fw = this.Width; // form width
            double tw = g.MeasureString(this.Text.Trim(), this.Font).Width;
            double rp = (fw - tw) / 2;
            int tt = Convert.ToInt32(rp);
            string st = "";
            st = st.PadRight((tt / 3)-20);
            this.Text = st + this.Text.Trim();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'book3DataSet.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter.Fill(this.book3DataSet.bookrecords);
        }

        private void btnAdd_MouseClick(object sender, MouseEventArgs e)
        {
            if (txtTitle.Text == "" && txtDescription.Text == "" && txtDescription.Text == "")
            {
                MessageBox.Show("Fill in all the textbox.", "Error",
                                 MessageBoxButtons.OK);
            }
            else
            {
                bookConn.Open();
                oleDbCmd.Connection = bookConn;
                //retrieve data from the database using SQL command
                oleDbCmd.CommandText = "insert into bookrecords (booktitle , description, bookno)" +
                                        " values ('" + this.txtTitle.Text + "','"
                                                     + this.txtDescription.Text + "','"
                                                     + this.txtBookNo.Text + "')";

                int temp = oleDbCmd.ExecuteNonQuery();
                if (temp > 0)
                {
                    empty();
                    MessageBox.Show("Record Successfully Added");
                }
                else
                {
                    MessageBox.Show("Record Fail to Added");
                }
                refresh();
                bookConn.Close();
            }
        }

        private void button1_view_Click(object sender, EventArgs e)
        {
            refresh();
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            OleDbDataAdapter dAdapter;
            DataTable dataTable = new DataTable();
            DataSet ds;
            bookConn.Open();
            oleDbCmd.Connection = bookConn;

            getData(row);
            string updateQuery = "update bookrecords set booktitle='" + Title + "', description='" + Description + "', bookno='" + BookNum + "' WHERE ID = " + bookID + "";
            oleDbCmd.Parameters.AddWithValue("@Title", txtTitle.Text);
            oleDbCmd.Parameters.AddWithValue("@Description", txtDescription.Text);
            oleDbCmd.Parameters.AddWithValue("@Booknum", txtBookNo.Text);
            oleDbCmd.Parameters.AddWithValue("@bookID", bookID);

            dAdapter = new OleDbDataAdapter(updateQuery, bookConn);
            ds = new DataSet();

            dAdapter.Fill(ds);
            dAdapter.Fill(dataTable);
            dAdapter.Dispose();

            bookConn.Close();

            MessageBox.Show("Record Updated");
            refresh();
            txtEnabled(true);
            btn_save.Enabled = false;
            btnAdd.Enabled = true;
            button1_view.Enabled = true;
            btn_delete.Enabled = true;
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            txtEnabled(false);
            btnAdd.Enabled = false;
            button1_view.Enabled = false;
            btn_edit.Enabled = false;
            btn_save.Enabled = false;
        }

        private void btn_edit_MouseClick(object sender, MouseEventArgs e)
        {
            txtEnabled(false);
            dataGridView1.ReadOnly = false;
            btnAdd.Enabled = false;
            button1_view.Enabled = false;
            btn_delete.Enabled = false;
        }
        private void refresh()
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("SELECT * FROM bookrecords", connParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("UPDATE * FROM bookrecords", connParam);
            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();

            dAdapter.Fill(dataTable);
            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0], dataTable.Rows[i][1], dataTable.Rows[i][2], dataTable.Rows[i][3]);
            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (!dataGridView1.ReadOnly)
            {
                counter++;
                row = dataGridView1.CurrentRow.Index;
                getData(row);
            }
        }

        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (btn_edit.Enabled)
            {
                if (counter == 1)
                {
                    btn_save.Enabled = true;
                    counter = 0;
                }
            }
            else
            {
                var decision = MessageBox.Show("Are you Sure to Delete This Record?", "Confirm",
                                 MessageBoxButtons.YesNoCancel,
                                 MessageBoxIcon.Question);
                if (decision == DialogResult.Yes)
                {
                    bookConn.Open();
                    oleDbCmd.Connection = bookConn;
                    getData(row);
                    //retrieve data from the database using SQL command
                    oleDbCmd.CommandText = "DELETE FROM bookrecords WHERE ID = " + bookID + "";

                    int temp = oleDbCmd.ExecuteNonQuery();
                    if (temp > 0)
                    {
                        empty();
                        MessageBox.Show("Record Successfully Deleted");
                    }
                    else
                    {
                        MessageBox.Show("Record Fail to be Deleted");
                    }
                    bookConn.Close();
                    btnAdd.Enabled = true;
                    button1_view.Enabled = true;
                    btn_edit.Enabled = true;
                    refresh();
                }
                else if(decision == DialogResult.Cancel)
                {
                    btnAdd.Enabled = true;
                    button1_view.Enabled = true;
                    btn_edit.Enabled = true;
                }
            }
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (counter == 1)
            {
                btn_save.Enabled = true;
                counter--;
            }
        }

        private void empty()
        {
            bookID = 0;
            Title = "";
            Description = "";
            BookNum = "";
            txtTitle.Text = null;
            txtDescription.Text = null;
            txtBookNo.Text = null;
        }
        public void getData(int row)
        {
            bookID = Convert.ToInt32(dataGridView1.Rows[row].Cells[0].Value.ToString());
            Title = dataGridView1.Rows[row].Cells[1].Value.ToString();
            Description = dataGridView1.Rows[row].Cells[2].Value.ToString();
            BookNum = dataGridView1.Rows[row].Cells[3].Value.ToString();
        }

        void txtEnabled(bool condition)
        {
            if (condition)
            {
                txtTitle.Enabled = true;
                txtDescription.Enabled = true;
                txtBookNo.Enabled = true;
            }
            else
            {
                txtTitle.Enabled = false;
                txtDescription.Enabled = false;
                txtBookNo.Enabled = false;
            }
        }
    }
}
