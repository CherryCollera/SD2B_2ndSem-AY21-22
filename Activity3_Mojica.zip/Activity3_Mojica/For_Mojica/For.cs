﻿/*
 * student Id number : 20-05258
 * student full name : Zedrick A. Mojica
 * Section : BSCS-SD2B
 * Date : 17/04/2022
 * Purpose : for loop 
 */
using System;

namespace For_Mojica
{
    class For
    {
        static void Main(string[] args)
        {
            //loop until i is less than 0
            for (int i = 10 - 1; i >= 0; i--)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
