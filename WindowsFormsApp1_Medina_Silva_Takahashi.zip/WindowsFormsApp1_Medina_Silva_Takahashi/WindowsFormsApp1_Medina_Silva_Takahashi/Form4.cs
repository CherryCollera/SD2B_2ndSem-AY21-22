﻿/* 		Activity #5
 * 		Grp 9
 * 	Members: Medina, Angelica
	   	 Silva, Alyssa Mae
	   	 Takahashi, Aira
 * BSCS-SD2B
 * 05/04/2022*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1_Medina_Silva_Takahashi
{
    public partial class Form4 : Form
    {
        double a, b;

        public Form4()
        {
            InitializeComponent();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(txt_firstNumber.Text);
            b = Convert.ToDouble(txt_secondNumber.Text);
            txt_answer.Text = (a + b).ToString();
        }

        private void btn_subtract_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(txt_firstNumber.Text);
            b = Convert.ToDouble(txt_secondNumber.Text);
            txt_answer.Text = (a - b).ToString();
        }

        private void btn_multiply_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(txt_firstNumber.Text);
            b = Convert.ToDouble(txt_secondNumber.Text);
            txt_answer.Text = (a * b).ToString();
        }

        private void btn_divide_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(txt_firstNumber.Text);
            b = Convert.ToDouble(txt_secondNumber.Text);
            txt_answer.Text = (a / b).ToString();
        }

        private void btn_back4_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
            this.Hide();
        }

       
    }
}
