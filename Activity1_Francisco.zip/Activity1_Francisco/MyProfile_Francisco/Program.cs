﻿using System;

namespace MyProfile_Francisco
{
    class MyProfile
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\tName: " + "Jan Andrei M. Francisco\n");
            Console.WriteLine("\tDate of Birth: " + "November 13, 2001\n");
            Console.WriteLine("\tCourse: " + "Bachelor of Science in Computer Science Major in Software Development\n");
            Console.WriteLine("\tYear: " + "2\n");
            Console.WriteLine("\tSection: " + "2B\n");
            Console.ReadKey();
        }
    }
}
