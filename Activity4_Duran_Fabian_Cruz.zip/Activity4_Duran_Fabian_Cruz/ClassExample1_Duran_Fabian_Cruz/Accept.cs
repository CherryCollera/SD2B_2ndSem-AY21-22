﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassExample1_Duran_Fabian_Cruz
{
    class Accept
    {
        public string firstname, lastname;
        public void AcceptDetails()
        {
            System.Console.Write("Enter your first and last name:\t");
            firstname = System.Console.ReadLine();
            lastname = System.Console.ReadLine();
        }
    }
}
