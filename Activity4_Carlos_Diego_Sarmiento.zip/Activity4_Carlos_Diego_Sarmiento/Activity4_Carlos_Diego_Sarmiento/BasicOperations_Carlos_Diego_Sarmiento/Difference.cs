﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Carlos_Diego_Sarmiento
{
    class Difference
    {
        public void computeDiff()
        {
            DeclareVar.diff = DeclareVar.num1 - DeclareVar.num2;
            Console.WriteLine("The difference is {0}", DeclareVar.diff);
        }
    }
}
