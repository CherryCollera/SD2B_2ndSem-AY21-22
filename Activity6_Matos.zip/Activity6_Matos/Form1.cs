﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity6_Matos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'studentsDBDataSet.users' table. You can move, or remove it, as needed.
            this.usersTableAdapter.Fill(this.studentsDBDataSet.users);

        }

        private void refreshToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.usersTableAdapter.Refresh(this.studentsDBDataSet.users);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void lastName_AToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.usersTableAdapter.LastName_A(this.studentsDBDataSet.users);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void bSCSToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.usersTableAdapter.BSCS(this.studentsDBDataSet.users);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void bSITToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.usersTableAdapter.BSIT(this.studentsDBDataSet.users);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void resident_EnglandToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.usersTableAdapter.Resident_England(this.studentsDBDataSet.users);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void section_2BToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.usersTableAdapter.Section_2B(this.studentsDBDataSet.users);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void sect_2BToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.usersTableAdapter.Sect_2B(this.studentsDBDataSet.users);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void residence_SamalToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.usersTableAdapter.Residence_Samal(this.studentsDBDataSet.users);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void residence_Samal1ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.usersTableAdapter.Residence_Samal1(this.studentsDBDataSet.users);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void new_YorkToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.usersTableAdapter.New_York(this.studentsDBDataSet.users);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void newYorkToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.usersTableAdapter.NewYork(this.studentsDBDataSet.users);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void sec2DToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.usersTableAdapter.sec2D(this.studentsDBDataSet.users);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void dsadToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.usersTableAdapter.dsad(this.studentsDBDataSet.users);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void cToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.usersTableAdapter.C(this.studentsDBDataSet.users);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void bToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.usersTableAdapter.B(this.studentsDBDataSet.users);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void _2ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.usersTableAdapter._2(this.studentsDBDataSet.users);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void _4ggToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.usersTableAdapter._4gg(this.studentsDBDataSet.users);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void consonantsToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.usersTableAdapter.Consonants(this.studentsDBDataSet.users);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
