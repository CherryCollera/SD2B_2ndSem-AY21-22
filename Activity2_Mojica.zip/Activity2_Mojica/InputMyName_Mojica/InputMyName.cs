﻿/*
 * student Id number : 20-05258
 * student full name : Zedrick A. Mojica
 * Section : BSCS-SD2B
 * Date : 04/04/2022
 * Purpose : getting the input of the user and printing it 
 */
using System;

namespace Activity2_Mojica
{
    class InputMyName
    {
        static void Main(string[] args)
        {
            String Name;
            System.Console.Write("Enter your name <Firstname lastname>: ");
            Name = Console.ReadLine();
            Console.WriteLine("");
            System.Console.WriteLine("Hello " + Name + "!!!");
            Console.WriteLine("");
            System.Console.WriteLine("Welcome to OOP environment.");
            System.Console.ReadKey();
        }
    }
}