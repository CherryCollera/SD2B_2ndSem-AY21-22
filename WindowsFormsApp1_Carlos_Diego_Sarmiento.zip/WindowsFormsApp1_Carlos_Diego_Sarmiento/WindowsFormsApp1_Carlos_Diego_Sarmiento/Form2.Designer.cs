﻿
namespace WindowsFormsApp1_Carlos_Diego_Sarmiento
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Firstname = new System.Windows.Forms.Label();
            this.lbl_Lastname = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txt_last_name = new System.Windows.Forms.TextBox();
            this.btn_GetMessage = new System.Windows.Forms.Button();
            this.btn_Hide = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Firstname
            // 
            this.lbl_Firstname.AutoSize = true;
            this.lbl_Firstname.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.lbl_Firstname.Location = new System.Drawing.Point(94, 101);
            this.lbl_Firstname.Name = "lbl_Firstname";
            this.lbl_Firstname.Size = new System.Drawing.Size(149, 32);
            this.lbl_Firstname.TabIndex = 0;
            this.lbl_Firstname.Text = "Firstname";
            // 
            // lbl_Lastname
            // 
            this.lbl_Lastname.AutoSize = true;
            this.lbl_Lastname.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.lbl_Lastname.Location = new System.Drawing.Point(94, 152);
            this.lbl_Lastname.Name = "lbl_Lastname";
            this.lbl_Lastname.Size = new System.Drawing.Size(145, 32);
            this.lbl_Lastname.TabIndex = 1;
            this.lbl_Lastname.Text = "Lastname";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.textBox1.Location = new System.Drawing.Point(260, 101);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(288, 39);
            this.textBox1.TabIndex = 2;
            // 
            // txt_last_name
            // 
            this.txt_last_name.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.txt_last_name.Location = new System.Drawing.Point(260, 152);
            this.txt_last_name.Name = "txt_last_name";
            this.txt_last_name.Size = new System.Drawing.Size(288, 39);
            this.txt_last_name.TabIndex = 3;
            // 
            // btn_GetMessage
            // 
            this.btn_GetMessage.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.btn_GetMessage.Location = new System.Drawing.Point(337, 214);
            this.btn_GetMessage.Name = "btn_GetMessage";
            this.btn_GetMessage.Size = new System.Drawing.Size(211, 58);
            this.btn_GetMessage.TabIndex = 4;
            this.btn_GetMessage.Text = "Get Message";
            this.btn_GetMessage.UseVisualStyleBackColor = true;
            this.btn_GetMessage.Click += new System.EventHandler(this.btn_GetMessage_Click);
            // 
            // btn_Hide
            // 
            this.btn_Hide.Font = new System.Drawing.Font("Helvetica Rounded", 20F, System.Drawing.FontStyle.Bold);
            this.btn_Hide.Location = new System.Drawing.Point(431, 346);
            this.btn_Hide.Name = "btn_Hide";
            this.btn_Hide.Size = new System.Drawing.Size(211, 58);
            this.btn_Hide.TabIndex = 5;
            this.btn_Hide.Text = "Hide";
            this.btn_Hide.UseVisualStyleBackColor = true;
            this.btn_Hide.Click += new System.EventHandler(this.btn_Hide_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 431);
            this.Controls.Add(this.btn_Hide);
            this.Controls.Add(this.btn_GetMessage);
            this.Controls.Add(this.txt_last_name);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lbl_Lastname);
            this.Controls.Add(this.lbl_Firstname);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Firstname;
        private System.Windows.Forms.Label lbl_Lastname;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox txt_last_name;
        private System.Windows.Forms.Button btn_GetMessage;
        private System.Windows.Forms.Button btn_Hide;
    }
}