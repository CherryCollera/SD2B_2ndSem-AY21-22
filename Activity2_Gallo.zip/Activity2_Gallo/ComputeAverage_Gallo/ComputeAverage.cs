﻿/*
 20-01076
Noel M. Gallo Jr.
SD2B
April 7, 2022
This program will Compute the average
 */
using System;

namespace ComputeTheAverage
{

    class ComputeTheAverage
    {

        public static void Main(string[] args)
        {
            int num, sum = 0;
            //int i = 1;
            System.Console.WriteLine("Enter 5 Grades: ");
            num = Convert.ToInt16(Console.ReadLine());
            sum += num;
            num = Convert.ToInt16(Console.ReadLine());
            sum += num;
            num = Convert.ToInt16(Console.ReadLine());
            sum += num;
            num = Convert.ToInt16(Console.ReadLine());
            sum += num;
            num = Convert.ToInt16(Console.ReadLine());
            sum += num;
            /*while (i < 5)
            {
                num = Convert.ToInt16(Console.ReadLine());
                sum += num;
                i++;
            }*/
            System.Console.WriteLine("\nThe Average is: " + String.Format("{0:0.000}", sum / 5.000));
            System.Console.ReadKey();
        }
    }
}
   