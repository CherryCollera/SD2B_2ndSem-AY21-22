﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatabaseQuery_Casaña
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cartmanCollegeDataSet.tblStudents' table. You can move, or remove it, as needed.
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);

        }

        private void BtnHighGPA_Click(object sender, EventArgs e)
        {
            listBoxHighGPA.Items.Clear();
            const double CUTOFF = 3.00;
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);
            var goodStudents =
                from s in this.cartmanCollegeDataSet.tblStudents
                where s.GradePointAverage > CUTOFF
                orderby s.GradePointAverage descending
                select s;
            foreach (var s in goodStudents)
                listBoxHighGPA.Items.Add(s.LastName + " " + s.FirstName);
        }

        private void btnShowRecords_Click(object sender, EventArgs e)
        {
            listBoxMinGPA.Items.Clear();
            double minGPA = Convert.ToDouble(txtShowRecords.Text);
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);
            var goodStudents =
                from s in this.cartmanCollegeDataSet.tblStudents
                where s.GradePointAverage > minGPA
                orderby s.GradePointAverage descending
                select s;
            foreach (var s in goodStudents)
                listBoxMinGPA.Items.Add(s.LastName + ", " + s.FirstName);
        }

        private void btnGradeStats_Click(object sender, EventArgs e)
        {
            var gpas =
                from s in this.cartmanCollegeDataSet.tblStudents
                select s.GradePointAverage;
            labelCount.Text = " Count is " + "\t" + gpas.Count();
            labelMin.Text = " Lowest is " + "\t" + gpas.Min();
            labelMax.Text = " Highest is " + "\t" + gpas.Max();
            labelAverage.Text = " Average of all GPA is " + "\t" + gpas.Average();
        }

        private void btnGroupRecords_Click(object sender, EventArgs e)
        {
            listBoxGroupGPA.Items.Clear();
            var studgpa =
                from s in this.cartmanCollegeDataSet.tblStudents
                group s by (int)s.GradePointAverage;

            foreach (var GroupGPA in studgpa)
            {
                listBoxGroupGPA.Items.Add("GPA: " + GroupGPA.Key);
                foreach (var s in GroupGPA)
                    listBoxGroupGPA.Items.Add(" " + s.GradePointAverage + " " + s.LastName);
            }
        }
    }
}
