﻿/** ===========================
 Name: Reywen Lee Bautista
 Course & Section: BSCS-SD2B
 Date: April 1, 2022
=============================*/

using System;

namespace IfElse1_Bautista
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("Enter first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2) { Console.WriteLine("\n{0} is greater than {1}", num1, num2); }
            else { Console.WriteLine("\n{0} is greater than {1}", num2, num1); }

            Console.ReadKey();
        }
    }
}
