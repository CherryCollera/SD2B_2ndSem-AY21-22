﻿/*20-00613
Marian Gillian G. Sarmiento
SD2B
April 5, 2022
This program will compute for the sum of 2 integer values*/

using System;

namespace ComputeTheSum_Sarmiento
{
    class ComputeTheSum
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("Enter first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Sum = {0} ", num1 + num2);
            Console.ReadLine();
        }
    }
}
