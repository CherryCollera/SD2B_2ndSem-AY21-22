﻿/* 20 - 01484
 John Brix B. Enriquez
 SD2B
 April 17, 2022
 This program will display the implementation of Do-While loop*/

using System;
namespace DoWhile
{
    class DoWhile
    {
        static void Main(string[] args)
        {
            int[] array_num = new int[] { 6, 7, 8, 10 };
            int sum = 0;
            int i = 0;
            do
            {
                sum += array_num[i];
                i++;
            }
            while (i < 4);
            Console.WriteLine(sum);
            Console.ReadKey();
        }
    }
}