﻿/** ===========================
 Name: Reywen Lee Bautista
 Course & Section: BSCS-SD2B
 Date: April 17, 2021
=============================*/
using System;

namespace For_Bautista
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 10 - 1; i>=0; i--) 
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
