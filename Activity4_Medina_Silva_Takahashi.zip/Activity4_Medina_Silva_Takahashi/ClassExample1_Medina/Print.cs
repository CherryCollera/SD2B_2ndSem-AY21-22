﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Medina
{
    class Print
    {
        public void PrintDetails()
        {
        //Creating object for 1st class: "Accept"
            Accept a = new Accept();
        //Executing the method from 1st class: "AcceptDetails()"
            a.AcceptDetails();

        //display the string values of firstname and lastname 
            System.Console.WriteLine("Hello " + a.firstname + " " + a.lastname + "!!!\n You have now created classes in OOP ");

        //Creating objects for 3rd class: "MyProfile"
            MyProfile profile = new MyProfile();
        //Executing the method from 3rd class: "DisplayProfile()"
            profile.DisplayProfile();


        }
    }
}
