﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 15, 2022
 *  Display the average of a given set of numbers
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ComputeAverage
    {
        internal class Program
            {
                static void Main(string[] args)
                    {                      
                        double sum = 0, avg = 0;

                        
                        // Input how many numbers to input
                        Console.Write("How many numbers you want to enter?   ");
                        int n = int.Parse(Console.ReadLine());
                        Console.Write("\n");


                        double[] numbers = new double[n];           // 2D array for storing the inputs
                        for(int i = 0;i < numbers.Length; i++)          // Input 
                            {
                                Console.Write("Number {0}: ", i + 1);
                                numbers[i] = Convert.ToDouble(Console.ReadLine());
                                sum += numbers[i];
                            }


                        // Calculate average
                        avg = sum / numbers.Length;


                        // Display
                        Console.WriteLine("\n\nAVERAGE: " + avg);
                        Console.ReadKey();
                    }
            }
    }
