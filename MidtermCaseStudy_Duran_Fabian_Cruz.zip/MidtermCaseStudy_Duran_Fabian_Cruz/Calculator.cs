﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidtermCaseStudy
{
    public partial class Calculator : Form
    {
        double total1 = 0;
        double total2 = 0;
        bool button4Clicked = false; //plus
        bool button8Clicked = false; //minus
        bool button12Clicked = false; //multiply
        bool button16Clicked = false; //divide
        public Calculator()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e) //add
        {
            total1 = total1 + double.Parse(textBox1.Text);
            textBox1.Clear();
            button8Clicked = false;
            button4Clicked = true;
            button16Clicked = false;
            button12Clicked = false;
        }

        private void button8_Click(object sender, EventArgs e) //minus
        {
            total1 = total1 + double.Parse(textBox1.Text);
            textBox1.Clear();
            button8Clicked = true;
            button4Clicked = false;
            button16Clicked = false;
            button12Clicked = false;
        }

        private void button12_Click(object sender, EventArgs e) //multiply
        {
            total1 = total1 + double.Parse(textBox1.Text);
            textBox1.Clear();
            button8Clicked = false;
            button4Clicked = false;
            button16Clicked = false;
            button12Clicked = true;
        }

        private void button16_Click(object sender, EventArgs e) //divide
        {
            total1 = total1 + double.Parse(textBox1.Text);
            textBox1.Clear();
            button8Clicked = false;
            button4Clicked = false;
            button16Clicked = true;
            button12Clicked = false;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Hide();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Form3 frm3 = new Form3();
            frm3.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + button1.Text;
        }

        private void Calculator_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + button2.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + button3.Text;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + button5.Text;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + button6.Text;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + button7.Text;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + button9.Text;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + button10.Text;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + button11.Text;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + button13.Text;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if (button4Clicked == true)

            {

                total2 = total1 + double.Parse(textBox1.Text);

            }

            else if (button8Clicked == true)

            {

                total2 = total1 - double.Parse(textBox1.Text);

            }

            else if (button12Clicked == true)

            {

                total2 = total1 * double.Parse(textBox1.Text);

            }

            else if (button16Clicked == true)

            {
                total2 = total1 / double.Parse(textBox1.Text);

            }

            textBox1.Text = total2.ToString(); total1 = 0;
        }
    }
    }


