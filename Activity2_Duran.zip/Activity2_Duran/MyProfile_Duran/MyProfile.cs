﻿/*20-03334
Angelo C. Duran
SD2B
April 4, 2022
This Program will display My Profile*/

using System;

namespace MyProfile_Duran
{
    class MyProfile
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name: Angelo C. Duran");
            Console.WriteLine("Birthdate: May 11, 2002");
            Console.WriteLine("Course: BS in Computer Science Major in Software Development");
            Console.WriteLine("Year: II");
            Console.WriteLine("Section: SD2B");
            System.Console.ReadKey();
        }
    }
}