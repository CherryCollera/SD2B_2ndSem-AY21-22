﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Carlos_Diego_Sarmiento
{
    class Input
    {
        public void getNum()
        {
            Console.Write("Input num1: ");
            DeclareVar.num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write ("Input num2: ");
            DeclareVar.num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("");
        }
    }
}
