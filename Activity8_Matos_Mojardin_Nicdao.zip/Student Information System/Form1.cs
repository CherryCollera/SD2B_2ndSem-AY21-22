﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Student_Information_System
{
    public partial class Form1 : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=db_students.mdb");
        OleDbCommand cmd;
        DataTable dt;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {           
            con.Open();
            cmd = new OleDbCommand("SELECT * FROM tbl_students", con);
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            datagrid.DataSource = dt;
            con.Close();
        }

        private void datagrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = datagrid.CurrentRow.Cells[0].Value.ToString();
            txtLName.Text = datagrid.CurrentRow.Cells[1].Value.ToString();
            txtFName.Text = datagrid.CurrentRow.Cells[2].Value.ToString();
            txtMName.Text = datagrid.CurrentRow.Cells[3].Value.ToString();
            txtAge.Text = datagrid.CurrentRow.Cells[4].Value.ToString();
            cbGender.Text = datagrid.CurrentRow.Cells[5].Value.ToString();

            btnSave.Enabled = false;
            btnEdit.Enabled = true;
            btnDelete.Enabled = true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "" || txtLName.Text == "" || txtMName.Text == "" || txtFName.Text == "" || txtAge.Text == "")
            {
                MessageBox.Show("Please fill out all fields", "Add Student Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                con.Open();
                string addStudent = "INSERT INTO tbl_students VALUES('" + txtID.Text + "', '" + txtLName.Text + "', '" + txtFName.Text + "', '" + txtMName.Text + "', '" + txtAge.Text + "', '" + cbGender.Text + "' )";
                cmd = new OleDbCommand(addStudent, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Student added successfully", "Student Added Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefreshForm();
            }
        }

        private void RefreshForm()
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            txtLName.Focus();
            con.Open();
            if (txtID.Text == "")
            {
                txtID.Text = "1";
            }

            using (OleDbDataReader read = cmd.ExecuteReader())
            {
                while (read.Read())
                {
                    int itemID = Convert.ToInt32((read[0]));
                    itemID++;
                    txtID.Text = itemID.ToString();
                }
            }
            con.Close();
            ClearText();         
            btnSave.Enabled = true;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
        }

        private void ClearText()
        {
            txtLName.Text = "";
            txtFName.Text = "";
            txtMName.Text = "";
            txtAge.Text = "";
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "" || txtLName.Text == "" || txtMName.Text == "" || txtFName.Text == "" || txtAge.Text == "")
            {
                MessageBox.Show("Please fill out all fields", "Edit Student Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                con.Open();
                string editStudent = "UPDATE tbl_students SET StudentID = '" + Convert.ToInt32(txtID.Text) + "', LastName = '" + txtLName.Text + "', FirstName = '" + txtFName.Text + "', MiddleName = '" + txtMName.Text + "', Age = '" + txtAge.Text + "'  WHERE StudentID = '" + Convert.ToInt32(txtID.Text) + "'   ";
                cmd = new OleDbCommand(editStudent, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Student edited successfully", "Student Edited Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);

                RefreshForm();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure to delete this student?", "Delete Student", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                con.Open();
                string deleteStudent = "DELETE FROM tbl_students WHERE StudentID = '" + txtID.Text + "' ";
                cmd = new OleDbCommand(deleteStudent, con);
                cmd.ExecuteNonQuery();
                con.Close();

                RefreshForm();
            }
            else if (dialogResult == DialogResult.No)
            {
                return;
            }  
        }

        private void guna2TextBox5_TextChanged(object sender, EventArgs e)
        {
            DataView dv = new DataView(dt);
            dv.RowFilter = string.Format("StudentID LIKE '%{0}%' OR LastName LIKE '%{0}%'", txtSearch.Text);
            datagrid.DataSource = dv;
        }

        private void txtID_KeyPress(object sender, KeyPressEventArgs e)
        {
            //only accepts nuumbers
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            //won't accept copy pastes
            if (e.KeyChar == 22)
                e.Handled = true;
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
