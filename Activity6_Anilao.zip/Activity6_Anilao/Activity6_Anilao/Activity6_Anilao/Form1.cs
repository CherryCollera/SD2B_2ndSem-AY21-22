﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity6_Anilao
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'myDatabaseDataSet.Table1' table. You can move, or remove it, as needed.
            this.table1TableAdapter.Fill(this.myDatabaseDataSet.Table1);

        }

        private void bSCS_studentsToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.BSCS_students(this.myDatabaseDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void bSIT_studentsToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.BSIT_students(this.myDatabaseDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void address_samalToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.Address_samal(this.myDatabaseDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void second_year_studentsToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.Second_year_students(this.myDatabaseDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void refreshToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.Refresh(this.myDatabaseDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void lastname_start_with_A_and_CToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.Lastname_start_with_A_and_C(this.myDatabaseDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void section_2BToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.Section_2B(this.myDatabaseDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void firstname_start_with_consonant_letterToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.table1TableAdapter.Firstname_start_with_consonant_letter(this.myDatabaseDataSet.Table1);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
