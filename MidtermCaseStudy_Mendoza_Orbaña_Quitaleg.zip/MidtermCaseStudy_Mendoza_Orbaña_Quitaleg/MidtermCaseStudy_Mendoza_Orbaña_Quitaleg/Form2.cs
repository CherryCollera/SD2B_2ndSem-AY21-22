﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidtermCaseStudy_Mendoza_Orbaña_Quitaleg
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)

        {
            int firstnum, secondnum, sum; 
            firstnum = Convert.ToInt32(textBox1.Text);
            secondnum = Convert.ToInt32(textBox2.Text);


            sum = firstnum + secondnum;

            MessageBox.Show("The sum is " + Convert.ToString(sum));

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int number = 25;

            MessageBox.Show(number.ToString());

        }

        private void button1_Click(object sender, EventArgs e)
        {
            float number = 25.78F;

            MessageBox.Show(number.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double number = 25.7889;

            MessageBox.Show(number.ToString());
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }
    }
    }

