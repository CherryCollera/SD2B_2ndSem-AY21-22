﻿
namespace DatabaseQuery_Anilao
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cartmanCollegeDataSet = new DatabaseQuery_Anilao.CartmanCollegeDataSet();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblStudentsTableAdapter = new DatabaseQuery_Anilao.CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Btn_HighGPA = new System.Windows.Forms.Button();
            this.listBox_HighGPA = new System.Windows.Forms.ListBox();
            this.Enter = new System.Windows.Forms.Label();
            this.textBox_MinGPA = new System.Windows.Forms.TextBox();
            this.Btn_ShowRecords = new System.Windows.Forms.Button();
            this.listBox_MinGPA = new System.Windows.Forms.ListBox();
            this.Btn_ViewGradesSta = new System.Windows.Forms.Button();
            this.labelCount = new System.Windows.Forms.Label();
            this.labelMin = new System.Windows.Forms.Label();
            this.labelMax = new System.Windows.Forms.Label();
            this.labelAverage = new System.Windows.Forms.Label();
            this.Btn_GroupRecordsGPA = new System.Windows.Forms.Button();
            this.listBox_GroupGPA = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(27, 27);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(770, 286);
            this.dataGridView1.TabIndex = 0;
            // 
            // cartmanCollegeDataSet
            // 
            this.cartmanCollegeDataSet.DataSetName = "CartmanCollegeDataSet";
            this.cartmanCollegeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.Width = 150;
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            this.lastNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            this.firstNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            this.gradePointAverageDataGridViewTextBoxColumn.Width = 150;
            // 
            // Btn_HighGPA
            // 
            this.Btn_HighGPA.Location = new System.Drawing.Point(27, 338);
            this.Btn_HighGPA.Name = "Btn_HighGPA";
            this.Btn_HighGPA.Size = new System.Drawing.Size(236, 47);
            this.Btn_HighGPA.TabIndex = 1;
            this.Btn_HighGPA.Text = "Show Students with High GPA";
            this.Btn_HighGPA.UseVisualStyleBackColor = true;
            this.Btn_HighGPA.Click += new System.EventHandler(this.Btn_HighGPA_Click);
            // 
            // listBox_HighGPA
            // 
            this.listBox_HighGPA.FormattingEnabled = true;
            this.listBox_HighGPA.ItemHeight = 20;
            this.listBox_HighGPA.Location = new System.Drawing.Point(27, 409);
            this.listBox_HighGPA.Name = "listBox_HighGPA";
            this.listBox_HighGPA.Size = new System.Drawing.Size(300, 124);
            this.listBox_HighGPA.TabIndex = 2;
            // 
            // Enter
            // 
            this.Enter.AutoSize = true;
            this.Enter.Location = new System.Drawing.Point(455, 351);
            this.Enter.Name = "Enter";
            this.Enter.Size = new System.Drawing.Size(153, 20);
            this.Enter.TabIndex = 3;
            this.Enter.Text = "Enter minimum GPA";
            // 
            // textBox_MinGPA
            // 
            this.textBox_MinGPA.Location = new System.Drawing.Point(615, 348);
            this.textBox_MinGPA.Name = "textBox_MinGPA";
            this.textBox_MinGPA.Size = new System.Drawing.Size(150, 26);
            this.textBox_MinGPA.TabIndex = 4;
            // 
            // Btn_ShowRecords
            // 
            this.Btn_ShowRecords.Location = new System.Drawing.Point(468, 380);
            this.Btn_ShowRecords.Name = "Btn_ShowRecords";
            this.Btn_ShowRecords.Size = new System.Drawing.Size(149, 41);
            this.Btn_ShowRecords.TabIndex = 5;
            this.Btn_ShowRecords.Text = "Show records";
            this.Btn_ShowRecords.UseVisualStyleBackColor = true;
            this.Btn_ShowRecords.Click += new System.EventHandler(this.Btn_ShowRecords_Click);
            // 
            // listBox_MinGPA
            // 
            this.listBox_MinGPA.FormattingEnabled = true;
            this.listBox_MinGPA.ItemHeight = 20;
            this.listBox_MinGPA.Location = new System.Drawing.Point(459, 441);
            this.listBox_MinGPA.Name = "listBox_MinGPA";
            this.listBox_MinGPA.Size = new System.Drawing.Size(288, 124);
            this.listBox_MinGPA.TabIndex = 6;
            // 
            // Btn_ViewGradesSta
            // 
            this.Btn_ViewGradesSta.Location = new System.Drawing.Point(830, 27);
            this.Btn_ViewGradesSta.Name = "Btn_ViewGradesSta";
            this.Btn_ViewGradesSta.Size = new System.Drawing.Size(200, 41);
            this.Btn_ViewGradesSta.TabIndex = 7;
            this.Btn_ViewGradesSta.Text = "View Grade Statistics";
            this.Btn_ViewGradesSta.UseVisualStyleBackColor = true;
            this.Btn_ViewGradesSta.Click += new System.EventHandler(this.Btn_ViewGradesSta_Click);
            // 
            // labelCount
            // 
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new System.Drawing.Point(849, 96);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new System.Drawing.Size(51, 20);
            this.labelCount.TabIndex = 8;
            this.labelCount.Text = "label1";
            // 
            // labelMin
            // 
            this.labelMin.AutoSize = true;
            this.labelMin.Location = new System.Drawing.Point(849, 138);
            this.labelMin.Name = "labelMin";
            this.labelMin.Size = new System.Drawing.Size(51, 20);
            this.labelMin.TabIndex = 9;
            this.labelMin.Text = "label2";
            // 
            // labelMax
            // 
            this.labelMax.AutoSize = true;
            this.labelMax.Location = new System.Drawing.Point(849, 187);
            this.labelMax.Name = "labelMax";
            this.labelMax.Size = new System.Drawing.Size(51, 20);
            this.labelMax.TabIndex = 10;
            this.labelMax.Text = "label3";
            // 
            // labelAverage
            // 
            this.labelAverage.AutoSize = true;
            this.labelAverage.Location = new System.Drawing.Point(849, 230);
            this.labelAverage.Name = "labelAverage";
            this.labelAverage.Size = new System.Drawing.Size(51, 20);
            this.labelAverage.TabIndex = 11;
            this.labelAverage.Text = "label4";
            // 
            // Btn_GroupRecordsGPA
            // 
            this.Btn_GroupRecordsGPA.Location = new System.Drawing.Point(1126, 27);
            this.Btn_GroupRecordsGPA.Name = "Btn_GroupRecordsGPA";
            this.Btn_GroupRecordsGPA.Size = new System.Drawing.Size(231, 41);
            this.Btn_GroupRecordsGPA.TabIndex = 12;
            this.Btn_GroupRecordsGPA.Text = "Group Records  by GPA";
            this.Btn_GroupRecordsGPA.UseVisualStyleBackColor = true;
            this.Btn_GroupRecordsGPA.Click += new System.EventHandler(this.Btn_GroupRecordsGPA_Click);
            // 
            // listBox_GroupGPA
            // 
            this.listBox_GroupGPA.FormattingEnabled = true;
            this.listBox_GroupGPA.ItemHeight = 20;
            this.listBox_GroupGPA.Location = new System.Drawing.Point(1126, 96);
            this.listBox_GroupGPA.Name = "listBox_GroupGPA";
            this.listBox_GroupGPA.Size = new System.Drawing.Size(231, 264);
            this.listBox_GroupGPA.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1426, 626);
            this.Controls.Add(this.listBox_GroupGPA);
            this.Controls.Add(this.Btn_GroupRecordsGPA);
            this.Controls.Add(this.labelAverage);
            this.Controls.Add(this.labelMax);
            this.Controls.Add(this.labelMin);
            this.Controls.Add(this.labelCount);
            this.Controls.Add(this.Btn_ViewGradesSta);
            this.Controls.Add(this.listBox_MinGPA);
            this.Controls.Add(this.Btn_ShowRecords);
            this.Controls.Add(this.textBox_MinGPA);
            this.Controls.Add(this.Enter);
            this.Controls.Add(this.listBox_HighGPA);
            this.Controls.Add(this.Btn_HighGPA);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Database Query Anilao";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CartmanCollegeDataSet cartmanCollegeDataSet;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button Btn_HighGPA;
        private System.Windows.Forms.ListBox listBox_HighGPA;
        private System.Windows.Forms.Label Enter;
        private System.Windows.Forms.TextBox textBox_MinGPA;
        private System.Windows.Forms.Button Btn_ShowRecords;
        private System.Windows.Forms.ListBox listBox_MinGPA;
        private System.Windows.Forms.Button Btn_ViewGradesSta;
        private System.Windows.Forms.Label labelCount;
        private System.Windows.Forms.Label labelMin;
        private System.Windows.Forms.Label labelMax;
        private System.Windows.Forms.Label labelAverage;
        private System.Windows.Forms.Button Btn_GroupRecordsGPA;
        private System.Windows.Forms.ListBox listBox_GroupGPA;
    }
}

