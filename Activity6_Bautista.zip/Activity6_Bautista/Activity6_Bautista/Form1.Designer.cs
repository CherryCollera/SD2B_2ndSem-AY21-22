﻿
namespace Activity6_Bautista
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.refreshToolStrip = new System.Windows.Forms.ToolStrip();
            this.refreshToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.bSCSToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSCSToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.bSITToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSITToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.sAMALToolStrip = new System.Windows.Forms.ToolStrip();
            this.sAMALToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.sECOND_YEARToolStrip = new System.Windows.Forms.ToolStrip();
            this.sECOND_YEARToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lASTNAME_AandCToolStrip = new System.Windows.Forms.ToolStrip();
            this.lASTNAME_AandCToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.sECTION_2BToolStrip = new System.Windows.Forms.ToolStrip();
            this.sECTION_2BToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lASRNAME_CONSONANTToolStrip = new System.Windows.Forms.ToolStrip();
            this.lASRNAME_CONSONANTToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.studentIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.middlenameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.table1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.activity6_DatabaseDataSet = new Activity6_Bautista.Activity6_DatabaseDataSet();
            this.table1TableAdapter = new Activity6_Bautista.Activity6_DatabaseDataSetTableAdapters.Table1TableAdapter();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.refreshToolStrip.SuspendLayout();
            this.bSCSToolStrip.SuspendLayout();
            this.bSITToolStrip.SuspendLayout();
            this.sAMALToolStrip.SuspendLayout();
            this.sECOND_YEARToolStrip.SuspendLayout();
            this.lASTNAME_AandCToolStrip.SuspendLayout();
            this.sECTION_2BToolStrip.SuspendLayout();
            this.lASRNAME_CONSONANTToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.table1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.activity6_DatabaseDataSet)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(858, 408);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(2, 411);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(858, 89);
            this.panel2.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studentIDDataGridViewTextBoxColumn,
            this.lastnameDataGridViewTextBoxColumn,
            this.firstnameDataGridViewTextBoxColumn,
            this.middlenameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.birthdayDataGridViewTextBoxColumn,
            this.programDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.table1BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(6, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(843, 400);
            this.dataGridView1.TabIndex = 0;
            // 
            // refreshToolStrip
            // 
            this.refreshToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.refreshToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshToolStripButton});
            this.refreshToolStrip.Location = new System.Drawing.Point(422, 45);
            this.refreshToolStrip.Name = "refreshToolStrip";
            this.refreshToolStrip.Size = new System.Drawing.Size(62, 25);
            this.refreshToolStrip.TabIndex = 2;
            this.refreshToolStrip.Text = "refreshToolStrip";
            // 
            // refreshToolStripButton
            // 
            this.refreshToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.refreshToolStripButton.Name = "refreshToolStripButton";
            this.refreshToolStripButton.Size = new System.Drawing.Size(50, 22);
            this.refreshToolStripButton.Text = "Refresh";
            this.refreshToolStripButton.Click += new System.EventHandler(this.refreshToolStripButton_Click);
            // 
            // bSCSToolStrip
            // 
            this.bSCSToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSCSToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSCSToolStripButton});
            this.bSCSToolStrip.Location = new System.Drawing.Point(8, 11);
            this.bSCSToolStrip.Name = "bSCSToolStrip";
            this.bSCSToolStrip.Size = new System.Drawing.Size(50, 25);
            this.bSCSToolStrip.TabIndex = 2;
            this.bSCSToolStrip.Text = "bSCSToolStrip";
            this.bSCSToolStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.bSCSToolStrip_ItemClicked);
            // 
            // bSCSToolStripButton
            // 
            this.bSCSToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSCSToolStripButton.Name = "bSCSToolStripButton";
            this.bSCSToolStripButton.Size = new System.Drawing.Size(38, 22);
            this.bSCSToolStripButton.Text = "BSCS";
            this.bSCSToolStripButton.Click += new System.EventHandler(this.bSCSToolStripButton_Click);
            // 
            // bSITToolStrip
            // 
            this.bSITToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSITToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSITToolStripButton});
            this.bSITToolStrip.Location = new System.Drawing.Point(89, 11);
            this.bSITToolStrip.Name = "bSITToolStrip";
            this.bSITToolStrip.Size = new System.Drawing.Size(45, 25);
            this.bSITToolStrip.TabIndex = 2;
            this.bSITToolStrip.Text = "bSITToolStrip";
            // 
            // bSITToolStripButton
            // 
            this.bSITToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSITToolStripButton.Name = "bSITToolStripButton";
            this.bSITToolStripButton.Size = new System.Drawing.Size(33, 22);
            this.bSITToolStripButton.Text = "BSIT";
            this.bSITToolStripButton.Click += new System.EventHandler(this.bSITToolStripButton_Click);
            // 
            // sAMALToolStrip
            // 
            this.sAMALToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.sAMALToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sAMALToolStripButton});
            this.sAMALToolStrip.Location = new System.Drawing.Point(165, 11);
            this.sAMALToolStrip.Name = "sAMALToolStrip";
            this.sAMALToolStrip.Size = new System.Drawing.Size(62, 25);
            this.sAMALToolStrip.TabIndex = 2;
            this.sAMALToolStrip.Text = "sAMALToolStrip";
            // 
            // sAMALToolStripButton
            // 
            this.sAMALToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.sAMALToolStripButton.Name = "sAMALToolStripButton";
            this.sAMALToolStripButton.Size = new System.Drawing.Size(50, 22);
            this.sAMALToolStripButton.Text = "SAMAL";
            this.sAMALToolStripButton.Click += new System.EventHandler(this.sAMALToolStripButton_Click);
            // 
            // sECOND_YEARToolStrip
            // 
            this.sECOND_YEARToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.sECOND_YEARToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sECOND_YEARToolStripButton});
            this.sECOND_YEARToolStrip.Location = new System.Drawing.Point(258, 11);
            this.sECOND_YEARToolStrip.Name = "sECOND_YEARToolStrip";
            this.sECOND_YEARToolStrip.Size = new System.Drawing.Size(102, 25);
            this.sECOND_YEARToolStrip.TabIndex = 2;
            this.sECOND_YEARToolStrip.Text = "sECOND_YEARToolStrip";
            // 
            // sECOND_YEARToolStripButton
            // 
            this.sECOND_YEARToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.sECOND_YEARToolStripButton.Name = "sECOND_YEARToolStripButton";
            this.sECOND_YEARToolStripButton.Size = new System.Drawing.Size(90, 22);
            this.sECOND_YEARToolStripButton.Text = "SECOND_YEAR";
            this.sECOND_YEARToolStripButton.Click += new System.EventHandler(this.sECOND_YEARToolStripButton_Click);
            // 
            // lASTNAME_AandCToolStrip
            // 
            this.lASTNAME_AandCToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.lASTNAME_AandCToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lASTNAME_AandCToolStripButton});
            this.lASTNAME_AandCToolStrip.Location = new System.Drawing.Point(391, 11);
            this.lASTNAME_AandCToolStrip.Name = "lASTNAME_AandCToolStrip";
            this.lASTNAME_AandCToolStrip.Size = new System.Drawing.Size(124, 25);
            this.lASTNAME_AandCToolStrip.TabIndex = 2;
            this.lASTNAME_AandCToolStrip.Text = "lASTNAME_AandCToolStrip";
            // 
            // lASTNAME_AandCToolStripButton
            // 
            this.lASTNAME_AandCToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lASTNAME_AandCToolStripButton.Name = "lASTNAME_AandCToolStripButton";
            this.lASTNAME_AandCToolStripButton.Size = new System.Drawing.Size(112, 22);
            this.lASTNAME_AandCToolStripButton.Text = "LASTNAME_AandC";
            this.lASTNAME_AandCToolStripButton.Click += new System.EventHandler(this.lASTNAME_AandCToolStripButton_Click);
            // 
            // sECTION_2BToolStrip
            // 
            this.sECTION_2BToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.sECTION_2BToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sECTION_2BToolStripButton});
            this.sECTION_2BToolStrip.Location = new System.Drawing.Point(546, 11);
            this.sECTION_2BToolStrip.Name = "sECTION_2BToolStrip";
            this.sECTION_2BToolStrip.Size = new System.Drawing.Size(88, 25);
            this.sECTION_2BToolStrip.TabIndex = 2;
            this.sECTION_2BToolStrip.Text = "sECTION_2BToolStrip";
            // 
            // sECTION_2BToolStripButton
            // 
            this.sECTION_2BToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.sECTION_2BToolStripButton.Name = "sECTION_2BToolStripButton";
            this.sECTION_2BToolStripButton.Size = new System.Drawing.Size(76, 22);
            this.sECTION_2BToolStripButton.Text = "SECTION_2B";
            this.sECTION_2BToolStripButton.Click += new System.EventHandler(this.sECTION_2BToolStripButton_Click);
            // 
            // lASRNAME_CONSONANTToolStrip
            // 
            this.lASRNAME_CONSONANTToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.lASRNAME_CONSONANTToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lASRNAME_CONSONANTToolStripButton});
            this.lASRNAME_CONSONANTToolStrip.Location = new System.Drawing.Point(665, 11);
            this.lASRNAME_CONSONANTToolStrip.Name = "lASRNAME_CONSONANTToolStrip";
            this.lASRNAME_CONSONANTToolStrip.Size = new System.Drawing.Size(162, 25);
            this.lASRNAME_CONSONANTToolStrip.TabIndex = 2;
            this.lASRNAME_CONSONANTToolStrip.Text = "lASRNAME_CONSONANTToolStrip";
            // 
            // lASRNAME_CONSONANTToolStripButton
            // 
            this.lASRNAME_CONSONANTToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lASRNAME_CONSONANTToolStripButton.Name = "lASRNAME_CONSONANTToolStripButton";
            this.lASRNAME_CONSONANTToolStripButton.Size = new System.Drawing.Size(150, 22);
            this.lASRNAME_CONSONANTToolStripButton.Text = "LASRNAME_CONSONANT";
            this.lASRNAME_CONSONANTToolStripButton.Click += new System.EventHandler(this.lASRNAME_CONSONANTToolStripButton_Click);
            // 
            // studentIDDataGridViewTextBoxColumn
            // 
            this.studentIDDataGridViewTextBoxColumn.DataPropertyName = "Student ID";
            this.studentIDDataGridViewTextBoxColumn.HeaderText = "Student ID";
            this.studentIDDataGridViewTextBoxColumn.Name = "studentIDDataGridViewTextBoxColumn";
            // 
            // lastnameDataGridViewTextBoxColumn
            // 
            this.lastnameDataGridViewTextBoxColumn.DataPropertyName = "Lastname";
            this.lastnameDataGridViewTextBoxColumn.HeaderText = "Lastname";
            this.lastnameDataGridViewTextBoxColumn.Name = "lastnameDataGridViewTextBoxColumn";
            // 
            // firstnameDataGridViewTextBoxColumn
            // 
            this.firstnameDataGridViewTextBoxColumn.DataPropertyName = "Firstname";
            this.firstnameDataGridViewTextBoxColumn.HeaderText = "Firstname";
            this.firstnameDataGridViewTextBoxColumn.Name = "firstnameDataGridViewTextBoxColumn";
            // 
            // middlenameDataGridViewTextBoxColumn
            // 
            this.middlenameDataGridViewTextBoxColumn.DataPropertyName = "Middlename";
            this.middlenameDataGridViewTextBoxColumn.HeaderText = "Middlename";
            this.middlenameDataGridViewTextBoxColumn.Name = "middlenameDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // birthdayDataGridViewTextBoxColumn
            // 
            this.birthdayDataGridViewTextBoxColumn.DataPropertyName = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.HeaderText = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.Name = "birthdayDataGridViewTextBoxColumn";
            // 
            // programDataGridViewTextBoxColumn
            // 
            this.programDataGridViewTextBoxColumn.DataPropertyName = "Program";
            this.programDataGridViewTextBoxColumn.HeaderText = "Program";
            this.programDataGridViewTextBoxColumn.Name = "programDataGridViewTextBoxColumn";
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            // 
            // table1BindingSource
            // 
            this.table1BindingSource.DataMember = "Table1";
            this.table1BindingSource.DataSource = this.activity6_DatabaseDataSet;
            // 
            // activity6_DatabaseDataSet
            // 
            this.activity6_DatabaseDataSet.DataSetName = "Activity6_DatabaseDataSet";
            this.activity6_DatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // table1TableAdapter
            // 
            this.table1TableAdapter.ClearBeforeFill = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.lASRNAME_CONSONANTToolStrip);
            this.panel3.Controls.Add(this.refreshToolStrip);
            this.panel3.Controls.Add(this.sECTION_2BToolStrip);
            this.panel3.Controls.Add(this.lASTNAME_AandCToolStrip);
            this.panel3.Controls.Add(this.sECOND_YEARToolStrip);
            this.panel3.Controls.Add(this.sAMALToolStrip);
            this.panel3.Controls.Add(this.bSITToolStrip);
            this.panel3.Controls.Add(this.bSCSToolStrip);
            this.panel3.Location = new System.Drawing.Point(6, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(843, 81);
            this.panel3.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(862, 503);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Grid View";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.refreshToolStrip.ResumeLayout(false);
            this.refreshToolStrip.PerformLayout();
            this.bSCSToolStrip.ResumeLayout(false);
            this.bSCSToolStrip.PerformLayout();
            this.bSITToolStrip.ResumeLayout(false);
            this.bSITToolStrip.PerformLayout();
            this.sAMALToolStrip.ResumeLayout(false);
            this.sAMALToolStrip.PerformLayout();
            this.sECOND_YEARToolStrip.ResumeLayout(false);
            this.sECOND_YEARToolStrip.PerformLayout();
            this.lASTNAME_AandCToolStrip.ResumeLayout(false);
            this.lASTNAME_AandCToolStrip.PerformLayout();
            this.sECTION_2BToolStrip.ResumeLayout(false);
            this.sECTION_2BToolStrip.PerformLayout();
            this.lASRNAME_CONSONANTToolStrip.ResumeLayout(false);
            this.lASRNAME_CONSONANTToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.table1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.activity6_DatabaseDataSet)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Activity6_DatabaseDataSet activity6_DatabaseDataSet;
        private System.Windows.Forms.BindingSource table1BindingSource;
        private Activity6_DatabaseDataSetTableAdapters.Table1TableAdapter table1TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn middlenameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn programDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStrip refreshToolStrip;
        private System.Windows.Forms.ToolStripButton refreshToolStripButton;
        private System.Windows.Forms.ToolStrip bSCSToolStrip;
        private System.Windows.Forms.ToolStripButton bSCSToolStripButton;
        private System.Windows.Forms.ToolStrip bSITToolStrip;
        private System.Windows.Forms.ToolStripButton bSITToolStripButton;
        private System.Windows.Forms.ToolStrip sAMALToolStrip;
        private System.Windows.Forms.ToolStripButton sAMALToolStripButton;
        private System.Windows.Forms.ToolStrip sECOND_YEARToolStrip;
        private System.Windows.Forms.ToolStripButton sECOND_YEARToolStripButton;
        private System.Windows.Forms.ToolStrip lASTNAME_AandCToolStrip;
        private System.Windows.Forms.ToolStripButton lASTNAME_AandCToolStripButton;
        private System.Windows.Forms.ToolStrip sECTION_2BToolStrip;
        private System.Windows.Forms.ToolStripButton sECTION_2BToolStripButton;
        private System.Windows.Forms.ToolStrip lASRNAME_CONSONANTToolStrip;
        private System.Windows.Forms.ToolStripButton lASRNAME_CONSONANTToolStripButton;
        private System.Windows.Forms.Panel panel3;
    }
}

