﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Medina
{
    class DeclareVar
    {
        public static int sum, diff, prod, r, quotient, num1, num2;
    }
}
