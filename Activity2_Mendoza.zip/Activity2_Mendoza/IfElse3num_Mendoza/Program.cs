﻿using System;

namespace IfElse2_Mendoza
{
    class Program
    {
        static void Main(string[] args)
        {

            int num1, num2, num3;
            const double pi = 3.14159;

            Console.Write("Enter first number:  ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number:  ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter third number:  ");
            num3 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();

            if (num1 >= num2)
            {
                if (num1 >= num3)
                {
                    Console.WriteLine(num1 + " is greater than " + num3 + " and " + num2+ ".");
                }
                else if (num1 < num3)
                {
                    Console.WriteLine(num3 + " is greater than " + num1 + " and " + num2 + ".");
                }
                
            }
            else
            {
                if (num2 > num3)
                {
                    Console.WriteLine(num2 + " is greater than " + num1 + " and " + num3 + ".");
                }
                else if (num2 < num3)
                {
                    Console.WriteLine(num3 + " is greater than " + num1 + " and " + num2 + ".");
                }
                
            }
            Console.ReadLine();
        }
    }
}