﻿/* 	ACTIVITY4_Grp9			
	BSCS SD2B

GrpMembers:	Medina, Angelica D
		    Silva, Alyssa MaeT. 
		    Takahashi, Aira M.

Date:   04-27-2022
 */

using System;

namespace ClassExample1_Medina
{
    class Program
    {
        static void Main(string[] args)
        {
            Print p = new Print();
            p.PrintDetails();

            Console.ReadLine();
        }
    }
}
