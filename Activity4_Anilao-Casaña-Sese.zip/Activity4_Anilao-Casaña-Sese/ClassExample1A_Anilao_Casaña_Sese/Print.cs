﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1A_Anilao_Casaña_Sese
{
    class Print //2nd class created
    {
        public void PrintDetails(String firstname, String lastname)
        {
            //Printing the value collected from method AcceptDetails()
            System.Console.Write("\nHello " + firstname + " " + lastname 
                + "!!!\nYou have created a class in OOP!");
        }
    }
}
