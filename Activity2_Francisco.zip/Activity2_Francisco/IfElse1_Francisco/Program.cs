﻿using System;

namespace IfElse1_Francisco
{
    class IfElse1
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("Enter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();

            if (num1 > num2)
            {
                Console.WriteLine(num1 + " is greater than {0}.", num2);
            }
            else if (num1 < num2)
            {
                Console.WriteLine(num2 + " is greater than {0}.", num1);
            }
            else
                Console.WriteLine(num1 + " is equal to {0}.", num2);
            Console.ReadKey();
        }
    }
}
