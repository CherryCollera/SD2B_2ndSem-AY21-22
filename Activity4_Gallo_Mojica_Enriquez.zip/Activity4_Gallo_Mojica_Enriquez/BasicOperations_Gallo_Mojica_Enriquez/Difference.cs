﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Gallo_Mojica_Enriquez
{
    internal class Difference
    {
        public static int ComputeDifference()
        {
            return DeclareVar.num1 - DeclareVar.num2;
        }
    }
}