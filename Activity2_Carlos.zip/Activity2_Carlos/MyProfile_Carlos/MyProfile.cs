﻿/*
 * 20-00382
 * Roiel A. Carlos
 * SD2B
 * April 7, 2022
 * This program will display my information.
 */
using System;

namespace MyProfile_Carlos
{
    class MyProfile
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine();
            System.Console.WriteLine("\tName: \t\tRoiel A. Carlos");
            System.Console.WriteLine();
            System.Console.WriteLine("\tDate of Birth: \tDecember 3 2001");
            System.Console.WriteLine();
            System.Console.WriteLine("\tCourse: \tBS Computer Science Major in Software Development");
            System.Console.WriteLine();
            System.Console.WriteLine("\tYear: \t\tII");
            System.Console.WriteLine();
            System.Console.WriteLine("\tSection: \tSD2B");
            System.Console.ReadKey();
        }
    }
}
