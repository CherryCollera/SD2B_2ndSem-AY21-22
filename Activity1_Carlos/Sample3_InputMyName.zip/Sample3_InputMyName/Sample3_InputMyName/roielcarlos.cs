﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample3_InputMyName
{
    internal class roielcarlos
    {
        static void Main(string[] args)
        {
            String name;
            System.Console.Write("Enter your name <First Name, Last Name> ");
            name = Console.ReadLine();
            System.Console.WriteLine();
            Console.WriteLine("Hello " + name + "!!!\nWelcome to OOP environment.");
            Console.ReadKey();
            
        }
    }
}
