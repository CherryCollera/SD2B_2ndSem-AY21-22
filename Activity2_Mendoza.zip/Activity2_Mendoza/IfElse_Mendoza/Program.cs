﻿using System;

namespace IfElse1_Mendoza
{
    class Program
    {
        static void Main(string[] args)
        {

            int num1, num2;
            const double pi = 3.14159;

            Console.Write("Enter first number:  ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number:  ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            if (num1 < num2)
            {
                Console.WriteLine(num2 +" is greater than " + num1 + ".");
            }else if (num1 > num2)
            {
                Console.WriteLine(num1 + " is greater than " + num2 + ".");
            }else if(num1 == num2)
            {
                Console.WriteLine(num2 + " is equal to " + num1 + ".");
            }

            
            Console.ReadLine();
        }
    }
}