﻿/** ===========================
 Name: Reywen Lee Bautista
 Course & Section: BSCS-SD2B
 Date: April 17, 2021
=============================*/
using System;

namespace CompareNames_Bautista
{
    class Program
    {
        static void Main(string[] args)
        {
            string string1 = "Reyween";
            string string2 = "Reyween";
            string string3 = "Reywen";
            string string4 = "reywen";
            string string5 = "REYWEN";

            Console.WriteLine("Using Equals() method");
            Console.WriteLine("\tcompare {0} to {1}: {2}", string1, string2, String.Equals(string1, string2));
            Console.WriteLine("\tcompare {0} to {1}: {2}", string1, string3, String.Equals(string1, string3));
            Console.WriteLine("\tLength of {0} is {1}", string1, string1.Length);
            Console.WriteLine("\tString {0} Substring(0, 3) will return {1}", string5, string5.Substring(0, 3));

            Console.WriteLine("\nUsing Compare() method");
            Console.WriteLine("\tcompare {0} to {1}: {2}", string1, string2, String.Compare(string1, string2));
            Console.WriteLine("\tcompare {0} to {1}: {2}", string1, string3, String.Compare(string1, string3));
            Console.WriteLine("\tcompare {0} to {1}: {2}", string3, string1, String.Compare(string3, string1));
            Console.WriteLine("\tcompare {0} to {1}: {2}", string4, string5, String.Equals(string4, string5));

            Console.WriteLine("\nUsing Equals() method");
            Console.WriteLine("\tcompare {0} to {1}: {2}", string1, string2, string1.CompareTo(string2));
            Console.WriteLine("\tcompare {0} to {1}: {2}", string1, string3, string1.CompareTo(string3));
            Console.WriteLine("\tcompare {0} to {1}: {2}", string3, string1, string3.CompareTo(string1));

            Console.ReadKey();
        }
    }
}
