﻿using System;

namespace ClassExample1_Manansala_Francisco_Cruz
{
    class Program
    {
        static void Main(string[] args)
        {
            Print print = new Print();
            print.PrintDetails();
            Console.ReadLine();
        }
    }
}
