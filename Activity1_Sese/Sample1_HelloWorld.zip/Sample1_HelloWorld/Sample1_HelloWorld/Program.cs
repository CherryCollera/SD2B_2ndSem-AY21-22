﻿/*20-00903
 * Regie A. Sese
 * SD2B
 * March 22, 2022
 * This prgram will display the phrase "Hello World"*/

using System;

namespace Sample1_HelloWorld
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World!");
            System.Console.ReadKey();
        }
        

    }
        
}
