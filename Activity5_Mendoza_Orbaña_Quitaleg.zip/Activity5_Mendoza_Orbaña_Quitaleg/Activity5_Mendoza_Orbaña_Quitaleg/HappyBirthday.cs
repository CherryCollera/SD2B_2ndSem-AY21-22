﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Activity5_Mendoza_Orbaña_Quitaleg
{
    internal class HappyBirthday
    {
        public string GetMessage(string firstname)
        {
            return "Happy Birtday " + firstname;
        }
    }
}
