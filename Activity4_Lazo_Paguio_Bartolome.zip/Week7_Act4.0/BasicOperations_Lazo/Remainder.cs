class Remainder{
    public void computeRemainder(){
        DeclareVar.remainder = DeclareVar.num1 % DeclareVar.num2;
    }
}