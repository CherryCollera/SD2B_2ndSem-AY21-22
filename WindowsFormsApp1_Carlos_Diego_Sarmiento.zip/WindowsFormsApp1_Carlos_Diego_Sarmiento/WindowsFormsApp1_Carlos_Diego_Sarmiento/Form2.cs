﻿/* Activity #5
 * Group Members: Carlos, Roiel A.
 *                Diego, Angelo R.
 *                Sarmiento, Marian Gillian G.
 * Program, Year, and Section: BSCS-SD2B
 * Date: 05/04/2022
 This form will display Happy Birthday and the name based on input. This form
connects to Form3
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1_Carlos_Diego_Sarmiento
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_GetMessage_Click(object sender, EventArgs e)
        {
            string firstname = textBox1.Text;
            string lastname = txt_last_name.Text;
            MessageBox.Show("Happy Birthday " + firstname + " " + lastname);
        }

        private void btn_Hide_Click(object sender, EventArgs e)
        {
            Form3 next = new Form3();
            next.Show();
            this.Hide();
        }
    }
}
