﻿//This program will display "Hello World"

using System;

namespace HelloWorld_Sese
{
    class HelloWorld
    {
        static void Main(String[] args)
        {
            System.Console.WriteLine("Hello World!");
            System.Console.ReadKey();
        }
    }
}