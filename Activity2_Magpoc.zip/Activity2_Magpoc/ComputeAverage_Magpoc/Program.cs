﻿using System;
namespace ComputeAverage
{

    class ComputeAverage
    {

        static void Main()
        {
            double avg;
            double[] grades = new double[5];
            Console.WriteLine("Enter 5 grades: ");
            grades[0] = Convert.ToDouble(Console.ReadLine());
            grades[1] = Convert.ToDouble(Console.ReadLine());
            grades[2] = Convert.ToDouble(Console.ReadLine());
            grades[3] = Convert.ToDouble(Console.ReadLine());
            grades[4] = Convert.ToDouble(Console.ReadLine());

            avg = grades[0] + grades[1] + grades[2] + grades[3] +
                grades[4];
            Console.WriteLine("The average is {0:0.000}", avg / 5);

            Console.ReadKey();
        }

    }
}
