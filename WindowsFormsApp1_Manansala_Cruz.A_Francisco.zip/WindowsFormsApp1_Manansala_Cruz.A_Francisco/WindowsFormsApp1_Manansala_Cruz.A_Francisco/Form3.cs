﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1_Manansala_Cruz.A_Francisco
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string fn = textBox1.Text;
            string ln = textBox2.Text;
            MessageBox.Show("\nHello " + fn + " " + ln +"\n"
                + "Group Member\n"
                + "Name          :        Arnie James Manansala\n"
                + "Date of Birth :        May, 11 2002\n"
                + "Course        :        BS Computer Science\n"
                + "Year          :        2nd year\n"
                + "Section       :        B\n\n"
                + "Name          :        Jan Andrei Francisco\n"
                + "Date of Birth :        Nov, 13 2001\n"
                + "Course        :        BS Computer Science\n"
                + "Year          :        2nd year\n"
                + "Section       :        B\n\n"
                + "Name          :        Alexis Emmannuel Cruz\n"
                + "Date of Birth :        Dec 04 2001\n"
                + "Course        :        BS Computer Science\n"
                + "Year          :        2nd year\n"
                + "Section       :        B");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 frm = new Form4();
            frm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
            this.Hide();
        }
    }
}
