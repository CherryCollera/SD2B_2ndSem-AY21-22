﻿/* 20 - 01484
 John Brix B. Enriquez
 SD2B
 April 5, 2022
 This program will display the inputted name*/

using System;
namespace InputMyName
{
    class MyName
    {
        static void Main(string[] args)
        {
            string fname;
            string lname;
            Console.WriteLine("Enter your name (firstname lastname) ");
            fname = Console.ReadLine();
            lname = Console.ReadLine();
            Console.WriteLine("Hello {0} {1}!!!", fname, lname);
            Console.WriteLine("Welcome to OOP environment.");
            Console.ReadKey();

        }
    }
}