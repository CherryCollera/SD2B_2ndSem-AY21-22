﻿using System;

namespace DeclaringConstants
{

    class DeclaringConstants
    {

        static void Main()
        {

            double pi, rad, area;
            pi = 3.14159;
            Console.Write("Enter Radius: ");
            rad = Convert.ToDouble(Console.ReadLine());

            area = pi * rad * rad;

            Console.Write("Radius: {0:0.0000},", rad);
            Console.WriteLine(" Area: {0:0.0000}", area);
            Console.ReadKey();

        }
    }
}