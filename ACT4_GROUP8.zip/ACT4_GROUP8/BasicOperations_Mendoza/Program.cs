﻿using System;

namespace BasicOperations_Mendoza
{
    class Program
    {
        static void Main(string[] args)
        {
            Input i = new Input();
            i.InputValues();
            Sum s = new Sum();
            Difference d = new Difference();
            Quotient q = new Quotient();
            Product p = new Product();
            Remainder r = new Remainder();
            s.ComputeSum();
            d.ComputeDifference();
            q.ComputeQuotient();
            p.ComputeProduct();
            r.ComputeRemainder();
            Console.WriteLine("Sum = "+ DeclareVar.sum );
            Console.WriteLine("Difference = " + DeclareVar.diff);
            Console.WriteLine("Product = " + DeclareVar.prod);
            Console.WriteLine("Qoutient = " + DeclareVar.qou);
            Console.WriteLine("Remainder = " + DeclareVar.rem);
            




            Console.ReadKey();
        }
    }
}