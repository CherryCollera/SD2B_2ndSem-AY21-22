﻿
namespace DataGridView_Casaña
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.studIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.middleNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentsTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.database1DataSet = new DataGridView_Casaña.Database1DataSet();
            this.label1 = new System.Windows.Forms.Label();
            this.bSCS_StudentsToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSCS_StudentsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.bSIT_StudentsToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSIT_StudentsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.address_SamalToolStrip = new System.Windows.Forms.ToolStrip();
            this.address_SamalToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.second_Year_StudentsToolStrip = new System.Windows.Forms.ToolStrip();
            this.second_Year_StudentsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.refreshToolStrip = new System.Windows.Forms.ToolStrip();
            this.refreshToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.a_and_C_LastNamesToolStrip = new System.Windows.Forms.ToolStrip();
            this.a_and_C_LastNamesToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.section_2BToolStrip = new System.Windows.Forms.ToolStrip();
            this.section_2BToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.studentsTableTableAdapter = new DataGridView_Casaña.Database1DataSetTableAdapters.studentsTableTableAdapter();
            this.firstName_ConsonantToolStrip = new System.Windows.Forms.ToolStrip();
            this.firstName_ConsonantToolStripButton = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsTableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet)).BeginInit();
            this.bSCS_StudentsToolStrip.SuspendLayout();
            this.bSIT_StudentsToolStrip.SuspendLayout();
            this.address_SamalToolStrip.SuspendLayout();
            this.second_Year_StudentsToolStrip.SuspendLayout();
            this.refreshToolStrip.SuspendLayout();
            this.a_and_C_LastNamesToolStrip.SuspendLayout();
            this.section_2BToolStrip.SuspendLayout();
            this.firstName_ConsonantToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studIDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.middleNameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.birthdateDataGridViewTextBoxColumn,
            this.programDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.studentsTableBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(35, 49);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(792, 259);
            this.dataGridView1.TabIndex = 0;
            // 
            // studIDDataGridViewTextBoxColumn
            // 
            this.studIDDataGridViewTextBoxColumn.DataPropertyName = "StudID";
            this.studIDDataGridViewTextBoxColumn.HeaderText = "StudID";
            this.studIDDataGridViewTextBoxColumn.Name = "studIDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // middleNameDataGridViewTextBoxColumn
            // 
            this.middleNameDataGridViewTextBoxColumn.DataPropertyName = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.HeaderText = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.Name = "middleNameDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // birthdateDataGridViewTextBoxColumn
            // 
            this.birthdateDataGridViewTextBoxColumn.DataPropertyName = "Birthdate";
            this.birthdateDataGridViewTextBoxColumn.HeaderText = "Birthdate";
            this.birthdateDataGridViewTextBoxColumn.Name = "birthdateDataGridViewTextBoxColumn";
            // 
            // programDataGridViewTextBoxColumn
            // 
            this.programDataGridViewTextBoxColumn.DataPropertyName = "Program";
            this.programDataGridViewTextBoxColumn.HeaderText = "Program";
            this.programDataGridViewTextBoxColumn.Name = "programDataGridViewTextBoxColumn";
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            // 
            // studentsTableBindingSource
            // 
            this.studentsTableBindingSource.DataMember = "studentsTable";
            this.studentsTableBindingSource.DataSource = this.database1DataSet;
            // 
            // database1DataSet
            // 
            this.database1DataSet.DataSetName = "Database1DataSet";
            this.database1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(217, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(450, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "STUDENTS RECORDS MONITORING SYSTEM";
            // 
            // bSCS_StudentsToolStrip
            // 
            this.bSCS_StudentsToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSCS_StudentsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSCS_StudentsToolStripButton});
            this.bSCS_StudentsToolStrip.Location = new System.Drawing.Point(35, 329);
            this.bSCS_StudentsToolStrip.Name = "bSCS_StudentsToolStrip";
            this.bSCS_StudentsToolStrip.Size = new System.Drawing.Size(101, 25);
            this.bSCS_StudentsToolStrip.TabIndex = 2;
            this.bSCS_StudentsToolStrip.Text = "bSCS_StudentsToolStrip";
            // 
            // bSCS_StudentsToolStripButton
            // 
            this.bSCS_StudentsToolStripButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bSCS_StudentsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSCS_StudentsToolStripButton.Name = "bSCS_StudentsToolStripButton";
            this.bSCS_StudentsToolStripButton.Size = new System.Drawing.Size(89, 22);
            this.bSCS_StudentsToolStripButton.Text = "BSCS_Students";
            this.bSCS_StudentsToolStripButton.Click += new System.EventHandler(this.bSCS_StudentsToolStripButton_Click);
            // 
            // bSIT_StudentsToolStrip
            // 
            this.bSIT_StudentsToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSIT_StudentsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSIT_StudentsToolStripButton});
            this.bSIT_StudentsToolStrip.Location = new System.Drawing.Point(146, 329);
            this.bSIT_StudentsToolStrip.Name = "bSIT_StudentsToolStrip";
            this.bSIT_StudentsToolStrip.Size = new System.Drawing.Size(96, 25);
            this.bSIT_StudentsToolStrip.TabIndex = 3;
            this.bSIT_StudentsToolStrip.Text = "bSIT_StudentsToolStrip";
            // 
            // bSIT_StudentsToolStripButton
            // 
            this.bSIT_StudentsToolStripButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bSIT_StudentsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSIT_StudentsToolStripButton.Name = "bSIT_StudentsToolStripButton";
            this.bSIT_StudentsToolStripButton.Size = new System.Drawing.Size(84, 22);
            this.bSIT_StudentsToolStripButton.Text = "BSIT_Students";
            this.bSIT_StudentsToolStripButton.Click += new System.EventHandler(this.bSIT_StudentsToolStripButton_Click_1);
            // 
            // address_SamalToolStrip
            // 
            this.address_SamalToolStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.address_SamalToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.address_SamalToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.address_SamalToolStripButton});
            this.address_SamalToolStrip.Location = new System.Drawing.Point(260, 329);
            this.address_SamalToolStrip.Name = "address_SamalToolStrip";
            this.address_SamalToolStrip.Size = new System.Drawing.Size(102, 25);
            this.address_SamalToolStrip.TabIndex = 4;
            this.address_SamalToolStrip.Text = "address_SamalToolStrip";
            // 
            // address_SamalToolStripButton
            // 
            this.address_SamalToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.address_SamalToolStripButton.Name = "address_SamalToolStripButton";
            this.address_SamalToolStripButton.Size = new System.Drawing.Size(90, 22);
            this.address_SamalToolStripButton.Text = "Address_Samal";
            this.address_SamalToolStripButton.Click += new System.EventHandler(this.address_SamalToolStripButton_Click);
            // 
            // second_Year_StudentsToolStrip
            // 
            this.second_Year_StudentsToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.second_Year_StudentsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.second_Year_StudentsToolStripButton});
            this.second_Year_StudentsToolStrip.Location = new System.Drawing.Point(376, 329);
            this.second_Year_StudentsToolStrip.Name = "second_Year_StudentsToolStrip";
            this.second_Year_StudentsToolStrip.Size = new System.Drawing.Size(140, 25);
            this.second_Year_StudentsToolStrip.TabIndex = 5;
            this.second_Year_StudentsToolStrip.Text = "second_Year_StudentsToolStrip";
            // 
            // second_Year_StudentsToolStripButton
            // 
            this.second_Year_StudentsToolStripButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.second_Year_StudentsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.second_Year_StudentsToolStripButton.Name = "second_Year_StudentsToolStripButton";
            this.second_Year_StudentsToolStripButton.Size = new System.Drawing.Size(128, 22);
            this.second_Year_StudentsToolStripButton.Text = "Second_Year_Students";
            this.second_Year_StudentsToolStripButton.Click += new System.EventHandler(this.second_Year_StudentsToolStripButton_Click);
            // 
            // refreshToolStrip
            // 
            this.refreshToolStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.refreshToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.refreshToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshToolStripButton});
            this.refreshToolStrip.Location = new System.Drawing.Point(528, 329);
            this.refreshToolStrip.Name = "refreshToolStrip";
            this.refreshToolStrip.Size = new System.Drawing.Size(62, 25);
            this.refreshToolStrip.TabIndex = 6;
            this.refreshToolStrip.Text = "refreshToolStrip";
            // 
            // refreshToolStripButton
            // 
            this.refreshToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.refreshToolStripButton.Name = "refreshToolStripButton";
            this.refreshToolStripButton.Size = new System.Drawing.Size(50, 22);
            this.refreshToolStripButton.Text = "Refresh";
            this.refreshToolStripButton.Click += new System.EventHandler(this.refreshToolStripButton_Click);
            // 
            // a_and_C_LastNamesToolStrip
            // 
            this.a_and_C_LastNamesToolStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.a_and_C_LastNamesToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.a_and_C_LastNamesToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.a_and_C_LastNamesToolStripButton});
            this.a_and_C_LastNamesToolStrip.Location = new System.Drawing.Point(603, 329);
            this.a_and_C_LastNamesToolStrip.Name = "a_and_C_LastNamesToolStrip";
            this.a_and_C_LastNamesToolStrip.Size = new System.Drawing.Size(132, 25);
            this.a_and_C_LastNamesToolStrip.TabIndex = 7;
            this.a_and_C_LastNamesToolStrip.Text = "a_and_C_LastNamesToolStrip";
            // 
            // a_and_C_LastNamesToolStripButton
            // 
            this.a_and_C_LastNamesToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.a_and_C_LastNamesToolStripButton.Name = "a_and_C_LastNamesToolStripButton";
            this.a_and_C_LastNamesToolStripButton.Size = new System.Drawing.Size(120, 22);
            this.a_and_C_LastNamesToolStripButton.Text = "A_and_C_LastNames";
            this.a_and_C_LastNamesToolStripButton.Click += new System.EventHandler(this.a_and_C_LastNamesToolStripButton_Click);
            // 
            // section_2BToolStrip
            // 
            this.section_2BToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.section_2BToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.section_2BToolStripButton});
            this.section_2BToolStrip.Location = new System.Drawing.Point(747, 329);
            this.section_2BToolStrip.Name = "section_2BToolStrip";
            this.section_2BToolStrip.Size = new System.Drawing.Size(80, 25);
            this.section_2BToolStrip.TabIndex = 8;
            this.section_2BToolStrip.Text = "section_2BToolStrip";
            // 
            // section_2BToolStripButton
            // 
            this.section_2BToolStripButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.section_2BToolStripButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.section_2BToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.section_2BToolStripButton.Name = "section_2BToolStripButton";
            this.section_2BToolStripButton.Size = new System.Drawing.Size(68, 22);
            this.section_2BToolStripButton.Text = "Section_2B";
            this.section_2BToolStripButton.Click += new System.EventHandler(this.section_2BToolStripButton_Click);
            // 
            // studentsTableTableAdapter
            // 
            this.studentsTableTableAdapter.ClearBeforeFill = true;
            // 
            // firstName_ConsonantToolStrip
            // 
            this.firstName_ConsonantToolStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.firstName_ConsonantToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.firstName_ConsonantToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.firstName_ConsonantToolStripButton});
            this.firstName_ConsonantToolStrip.Location = new System.Drawing.Point(376, 368);
            this.firstName_ConsonantToolStrip.Name = "firstName_ConsonantToolStrip";
            this.firstName_ConsonantToolStrip.Size = new System.Drawing.Size(140, 25);
            this.firstName_ConsonantToolStrip.TabIndex = 9;
            this.firstName_ConsonantToolStrip.Text = "firstName_ConsonantToolStrip";
            // 
            // firstName_ConsonantToolStripButton
            // 
            this.firstName_ConsonantToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.firstName_ConsonantToolStripButton.Name = "firstName_ConsonantToolStripButton";
            this.firstName_ConsonantToolStripButton.Size = new System.Drawing.Size(23, 23);
            this.firstName_ConsonantToolStripButton.Text = "FirstName_Consonant";
            this.firstName_ConsonantToolStripButton.Click += new System.EventHandler(this.firstName_ConsonantToolStripButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(847, 402);
            this.Controls.Add(this.firstName_ConsonantToolStrip);
            this.Controls.Add(this.section_2BToolStrip);
            this.Controls.Add(this.a_and_C_LastNamesToolStrip);
            this.Controls.Add(this.refreshToolStrip);
            this.Controls.Add(this.second_Year_StudentsToolStrip);
            this.Controls.Add(this.address_SamalToolStrip);
            this.Controls.Add(this.bSIT_StudentsToolStrip);
            this.Controls.Add(this.bSCS_StudentsToolStrip);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.Text = "Data Grid Casaña";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsTableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet)).EndInit();
            this.bSCS_StudentsToolStrip.ResumeLayout(false);
            this.bSCS_StudentsToolStrip.PerformLayout();
            this.bSIT_StudentsToolStrip.ResumeLayout(false);
            this.bSIT_StudentsToolStrip.PerformLayout();
            this.address_SamalToolStrip.ResumeLayout(false);
            this.address_SamalToolStrip.PerformLayout();
            this.second_Year_StudentsToolStrip.ResumeLayout(false);
            this.second_Year_StudentsToolStrip.PerformLayout();
            this.refreshToolStrip.ResumeLayout(false);
            this.refreshToolStrip.PerformLayout();
            this.a_and_C_LastNamesToolStrip.ResumeLayout(false);
            this.a_and_C_LastNamesToolStrip.PerformLayout();
            this.section_2BToolStrip.ResumeLayout(false);
            this.section_2BToolStrip.PerformLayout();
            this.firstName_ConsonantToolStrip.ResumeLayout(false);
            this.firstName_ConsonantToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private Database1DataSet database1DataSet;
        private System.Windows.Forms.BindingSource studentsTableBindingSource;
        private Database1DataSetTableAdapters.studentsTableTableAdapter studentsTableTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn middleNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn programDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStrip bSCS_StudentsToolStrip;
        private System.Windows.Forms.ToolStripButton bSCS_StudentsToolStripButton;
        private System.Windows.Forms.ToolStrip bSIT_StudentsToolStrip;
        private System.Windows.Forms.ToolStripButton bSIT_StudentsToolStripButton;
        private System.Windows.Forms.ToolStrip address_SamalToolStrip;
        private System.Windows.Forms.ToolStripButton address_SamalToolStripButton;
        private System.Windows.Forms.ToolStrip second_Year_StudentsToolStrip;
        private System.Windows.Forms.ToolStripButton second_Year_StudentsToolStripButton;
        private System.Windows.Forms.ToolStrip refreshToolStrip;
        private System.Windows.Forms.ToolStripButton refreshToolStripButton;
        private System.Windows.Forms.ToolStrip a_and_C_LastNamesToolStrip;
        private System.Windows.Forms.ToolStripButton a_and_C_LastNamesToolStripButton;
        private System.Windows.Forms.ToolStrip section_2BToolStrip;
        private System.Windows.Forms.ToolStripButton section_2BToolStripButton;
        private System.Windows.Forms.ToolStrip firstName_ConsonantToolStrip;
        private System.Windows.Forms.ToolStripButton firstName_ConsonantToolStripButton;
    }
}

