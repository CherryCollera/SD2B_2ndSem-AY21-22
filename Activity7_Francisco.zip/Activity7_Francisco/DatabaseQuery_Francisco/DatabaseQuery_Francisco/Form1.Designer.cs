﻿
namespace DatabaseQuery_Francisco
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cartmanCollegeDataSet = new DatabaseQuery_Francisco.CartmanCollegeDataSet();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblStudentsTableAdapter = new DatabaseQuery_Francisco.CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Btn_HighGPA = new System.Windows.Forms.Button();
            this.listBox_HighGPA = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_MinGPA = new System.Windows.Forms.TextBox();
            this.Btn_ShowRecords = new System.Windows.Forms.Button();
            this.listBox_MinGPA = new System.Windows.Forms.ListBox();
            this.Btn_ViewGradeStat = new System.Windows.Forms.Button();
            this.labelCount = new System.Windows.Forms.Label();
            this.labelMin = new System.Windows.Forms.Label();
            this.labelMax = new System.Windows.Forms.Label();
            this.labelAverage = new System.Windows.Forms.Label();
            this.Btn_GroupRecordsGPA = new System.Windows.Forms.Button();
            this.listBox_GroupGPA = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(519, 214);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // cartmanCollegeDataSet
            // 
            this.cartmanCollegeDataSet.DataSetName = "CartmanCollegeDataSet";
            this.cartmanCollegeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            // 
            // Btn_HighGPA
            // 
            this.Btn_HighGPA.Location = new System.Drawing.Point(12, 232);
            this.Btn_HighGPA.Name = "Btn_HighGPA";
            this.Btn_HighGPA.Size = new System.Drawing.Size(212, 33);
            this.Btn_HighGPA.TabIndex = 1;
            this.Btn_HighGPA.Text = "Show Students with High GPA";
            this.Btn_HighGPA.UseVisualStyleBackColor = true;
            this.Btn_HighGPA.Click += new System.EventHandler(this.Btn_HighGPA_Click);
            // 
            // listBox_HighGPA
            // 
            this.listBox_HighGPA.FormattingEnabled = true;
            this.listBox_HighGPA.Location = new System.Drawing.Point(12, 271);
            this.listBox_HighGPA.Name = "listBox_HighGPA";
            this.listBox_HighGPA.Size = new System.Drawing.Size(212, 147);
            this.listBox_HighGPA.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(289, 242);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Enter minimum GPA:";
            // 
            // textBox_MinGPA
            // 
            this.textBox_MinGPA.Location = new System.Drawing.Point(398, 239);
            this.textBox_MinGPA.Name = "textBox_MinGPA";
            this.textBox_MinGPA.Size = new System.Drawing.Size(93, 20);
            this.textBox_MinGPA.TabIndex = 4;
            // 
            // Btn_ShowRecords
            // 
            this.Btn_ShowRecords.Location = new System.Drawing.Point(288, 283);
            this.Btn_ShowRecords.Name = "Btn_ShowRecords";
            this.Btn_ShowRecords.Size = new System.Drawing.Size(104, 22);
            this.Btn_ShowRecords.TabIndex = 5;
            this.Btn_ShowRecords.Text = "Show Records";
            this.Btn_ShowRecords.UseVisualStyleBackColor = true;
            this.Btn_ShowRecords.Click += new System.EventHandler(this.Btn_ShowRecords_Click);
            // 
            // listBox_MinGPA
            // 
            this.listBox_MinGPA.FormattingEnabled = true;
            this.listBox_MinGPA.Location = new System.Drawing.Point(288, 310);
            this.listBox_MinGPA.Name = "listBox_MinGPA";
            this.listBox_MinGPA.Size = new System.Drawing.Size(212, 108);
            this.listBox_MinGPA.TabIndex = 6;
            // 
            // Btn_ViewGradeStat
            // 
            this.Btn_ViewGradeStat.Location = new System.Drawing.Point(553, 12);
            this.Btn_ViewGradeStat.Name = "Btn_ViewGradeStat";
            this.Btn_ViewGradeStat.Size = new System.Drawing.Size(143, 22);
            this.Btn_ViewGradeStat.TabIndex = 7;
            this.Btn_ViewGradeStat.Text = "View Grade Statistics";
            this.Btn_ViewGradeStat.UseVisualStyleBackColor = true;
            this.Btn_ViewGradeStat.Click += new System.EventHandler(this.Btn_ViewGradeStat_Click);
            // 
            // labelCount
            // 
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new System.Drawing.Point(562, 59);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new System.Drawing.Size(35, 13);
            this.labelCount.TabIndex = 8;
            this.labelCount.Text = "label2";
            // 
            // labelMin
            // 
            this.labelMin.AutoSize = true;
            this.labelMin.Location = new System.Drawing.Point(562, 97);
            this.labelMin.Name = "labelMin";
            this.labelMin.Size = new System.Drawing.Size(35, 13);
            this.labelMin.TabIndex = 9;
            this.labelMin.Text = "label3";
            // 
            // labelMax
            // 
            this.labelMax.AutoSize = true;
            this.labelMax.Location = new System.Drawing.Point(562, 134);
            this.labelMax.Name = "labelMax";
            this.labelMax.Size = new System.Drawing.Size(35, 13);
            this.labelMax.TabIndex = 10;
            this.labelMax.Text = "label4";
            // 
            // labelAverage
            // 
            this.labelAverage.AutoSize = true;
            this.labelAverage.Location = new System.Drawing.Point(562, 170);
            this.labelAverage.Name = "labelAverage";
            this.labelAverage.Size = new System.Drawing.Size(35, 13);
            this.labelAverage.TabIndex = 11;
            this.labelAverage.Text = "label5";
            this.labelAverage.Click += new System.EventHandler(this.label5_Click);
            // 
            // Btn_GroupRecordsGPA
            // 
            this.Btn_GroupRecordsGPA.Location = new System.Drawing.Point(742, 12);
            this.Btn_GroupRecordsGPA.Name = "Btn_GroupRecordsGPA";
            this.Btn_GroupRecordsGPA.Size = new System.Drawing.Size(143, 22);
            this.Btn_GroupRecordsGPA.TabIndex = 12;
            this.Btn_GroupRecordsGPA.Text = "Group Records by GPA";
            this.Btn_GroupRecordsGPA.UseVisualStyleBackColor = true;
            this.Btn_GroupRecordsGPA.Click += new System.EventHandler(this.Btn_GroupRecordsGPA_Click);
            // 
            // listBox_GroupGPA
            // 
            this.listBox_GroupGPA.FormattingEnabled = true;
            this.listBox_GroupGPA.Location = new System.Drawing.Point(742, 59);
            this.listBox_GroupGPA.Name = "listBox_GroupGPA";
            this.listBox_GroupGPA.Size = new System.Drawing.Size(143, 199);
            this.listBox_GroupGPA.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(896, 478);
            this.Controls.Add(this.listBox_GroupGPA);
            this.Controls.Add(this.Btn_GroupRecordsGPA);
            this.Controls.Add(this.labelAverage);
            this.Controls.Add(this.labelMax);
            this.Controls.Add(this.labelMin);
            this.Controls.Add(this.labelCount);
            this.Controls.Add(this.Btn_ViewGradeStat);
            this.Controls.Add(this.listBox_MinGPA);
            this.Controls.Add(this.Btn_ShowRecords);
            this.Controls.Add(this.textBox_MinGPA);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox_HighGPA);
            this.Controls.Add(this.Btn_HighGPA);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Database Query Francisco";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CartmanCollegeDataSet cartmanCollegeDataSet;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button Btn_HighGPA;
        private System.Windows.Forms.ListBox listBox_HighGPA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_MinGPA;
        private System.Windows.Forms.Button Btn_ShowRecords;
        private System.Windows.Forms.ListBox listBox_MinGPA;
        private System.Windows.Forms.Button Btn_ViewGradeStat;
        private System.Windows.Forms.Label labelCount;
        private System.Windows.Forms.Label labelMin;
        private System.Windows.Forms.Label labelMax;
        private System.Windows.Forms.Label labelAverage;
        private System.Windows.Forms.Button Btn_GroupRecordsGPA;
        private System.Windows.Forms.ListBox listBox_GroupGPA;
    }
}

