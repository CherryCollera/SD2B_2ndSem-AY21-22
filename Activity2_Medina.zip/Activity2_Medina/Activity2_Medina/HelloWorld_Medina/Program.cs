﻿/*  20-01732
    Angelica D. Medina

    BSCSSD-2B
    April 07, 2022

This program will display the phrase 'Hello World'.
*/

using System;

namespace Sample1_HelloWorld
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World!");

            System.Console.ReadKey();
        }
    }
}
