﻿/*  20-01732
    Angelica D. Medina

    BSCSSD-2B
    April 18, 2022

This program will compare the three different numbers from the input of the user. 
*/


using System;

namespace CompareNumbers_Medina
{
    class comparenumbers_medina
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;

            Console.Write("Enter 1st Number:  ");
            num1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter 2nd Number:  ");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter 3rd Number:  ");
            num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2 && num1 > num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num1, num2, num3);
                Console.WriteLine("{0} is less than {1}", num2, num1);
                Console.WriteLine("{0} is less than {1}", num3, num1);
                
            }
            else if (num2 > num1 && num2 > num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num2, num1, num3);
                Console.WriteLine("{0} is less than {1}", num1, num2);
                Console.WriteLine("{0} is less than {1}", num3, num2);
                
            }
            else if (num3 > num1 && num3 > num2)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num3, num1, num2);
                Console.WriteLine("{0} is less than {1}", num1, num3);
                Console.WriteLine("{0} is less than {1}", num2, num3);
                
            }
            else
            {
                Console.WriteLine("{0}, {1}, and {2} are equal", num1, num2, num3);
                
            }

            Console.ReadKey();
        }
    }
}
