﻿namespace DataGridView_Mojica
{


    partial class MyDatabaseDataSet
    {
        partial class studentDataTable
        {
        }
    }
}

namespace DataGridView_Mojica.MyDatabaseDataSetTableAdapters {
    
    
    public partial class studentTableAdapter {
    }
}
