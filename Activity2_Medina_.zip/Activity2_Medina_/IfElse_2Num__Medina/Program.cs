﻿/*  20-01732
    Angelica D. Medina
 
    BSCSSD-2B
    April 07, 2022

This program will display the example of if-else with 2 input numbers.
*/

using System;

namespace IfElse_2Num__Medina
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            System.Console.Write("Enter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            System.Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            System.Console.WriteLine("");

            if (num1 > num2) { Console.WriteLine("\n{0} is Greater than {1}\n", num1, num2); }
            else { Console.WriteLine("\n{0} is Greater than {1}", num2, num1); }

            System.Console.WriteLine("");

            System.Console.ReadKey();
        }
    }
}