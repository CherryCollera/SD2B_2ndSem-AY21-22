﻿/*
 20-01076
Noel M. Gallo Jr.
SD2B
April 7, 2022
This program will Compare numbers
 */
using System;

namespace IfElse1
{

    class IfElse1
    {

        public static void Main(string[] args)
        {
            System.Console.Write("Enter 1st number: ");
            int num1 = Convert.ToInt16(Console.ReadLine());
            System.Console.Write("Enter 2nd number: ");
            int num2 = Convert.ToInt16(Console.ReadLine());

            if (num1 > num2)
            {
                System.Console.WriteLine("\n{0} is greater than {1}.", num1, num2);
            }
            else if (num1 < num2)
            {
                System.Console.WriteLine("\n{0} is less than {1}.", num1, num2);
            }
            else
            {
                System.Console.WriteLine("\n{0} is equal to {1}.", num1, num2);
            }
            System.Console.ReadKey();
        }
    }
}