﻿/* 20 - 01484
 John Brix B. Enriquez
 SD2B
 April 5, 2022
 This program will compute the area of the circle*/

using System;
namespace ComputeTheSum
{
    class ComputeTheSum
    {
        static void Main(string[] args)
        {
            const double pi = 3.14159;
            double radius;
            Console.Write("Enter Radius: ");
            radius = Convert.ToInt32(Console.ReadLine());
            double AreaCircle = pi * radius * radius;
            Console.WriteLine("Radius: {0:.0000}, Area: {1:.0000}", radius, AreaCircle);
            Console.ReadKey();

        }
    }
}