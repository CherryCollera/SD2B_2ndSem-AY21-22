﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Medina
{
    class Product
    {
        public void ComputeProduct()
        {
            DeclareVar.prod = DeclareVar.num1 * DeclareVar.num2; //computes the product of the two input values
        }
    }
}
