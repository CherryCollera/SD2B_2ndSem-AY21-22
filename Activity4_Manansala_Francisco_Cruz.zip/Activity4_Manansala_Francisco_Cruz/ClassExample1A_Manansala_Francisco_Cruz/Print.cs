﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1A_Manansala_Francisco_Cruz
{
    class Print
    {
        public void PrintDetails(String firstname, String lastname)
        {
            System.Console.Write("\nHello " + firstname + " " + lastname
                + "!!!\nYou have created a class in OOP!");
        }
    }
}
