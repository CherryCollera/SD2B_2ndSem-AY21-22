﻿/*
20-02530
Carl Joseph Mendoza
SD2B
October 23, 2002
The program will display my profile
 */

using System;

namespace MyProfile_Mendoza
{
    class Profile
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\tName:\t\t Carl Joseph A. Mendoza \n");
            Console.WriteLine("\tDate of Birth:\t October 23, 2002 \n");
            Console.WriteLine("\tCourse:\t\t Bachelor of Science in Computer Science \n");
            Console.WriteLine("\tYear:\t\t IV \n");
            Console.WriteLine("\tSection:\t SD2B \n");
            Console.ReadKey();
        }
    }
}
