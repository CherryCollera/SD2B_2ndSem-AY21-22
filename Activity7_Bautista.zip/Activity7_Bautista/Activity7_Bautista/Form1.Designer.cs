﻿
namespace Activity7_Bautista
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cartmanCollegeDataSet = new Activity7_Bautista.CartmanCollegeDataSet();
            this.tblStudentsTableAdapter = new Activity7_Bautista.CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter();
            this.BPanel1 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.listBox_HighGPA = new System.Windows.Forms.ListBox();
            this.btn_HighGPA = new System.Windows.Forms.Button();
            this.btn_ShowRecords = new System.Windows.Forms.Button();
            this.listBox_MinGPA = new System.Windows.Forms.ListBox();
            this.Label_MinGPA = new System.Windows.Forms.Label();
            this.textBox_MinGPA = new System.Windows.Forms.TextBox();
            this.btn_ViewGradeStat = new System.Windows.Forms.Button();
            this.btn_GroupRecordsGPA = new System.Windows.Forms.Button();
            this.listBox_GroupGPA = new System.Windows.Forms.ListBox();
            this.labelCount = new System.Windows.Forms.Label();
            this.labelMin = new System.Windows.Forms.Label();
            this.labelMax = new System.Windows.Forms.Label();
            this.labelAverage = new System.Windows.Forms.Label();
            this._GroupRecordsGPA = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).BeginInit();
            this.BPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this._GroupRecordsGPA.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Gray;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(7, 9);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(444, 262);
            this.dataGridView1.TabIndex = 0;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet;
            // 
            // cartmanCollegeDataSet
            // 
            this.cartmanCollegeDataSet.DataSetName = "CartmanCollegeDataSet";
            this.cartmanCollegeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // BPanel1
            // 
            this.BPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.BPanel1.Controls.Add(this.panel3);
            this.BPanel1.Controls.Add(this.panel2);
            this.BPanel1.Controls.Add(this.panel1);
            this.BPanel1.Controls.Add(this.dataGridView1);
            this.BPanel1.Location = new System.Drawing.Point(3, 3);
            this.BPanel1.Name = "BPanel1";
            this.BPanel1.Size = new System.Drawing.Size(780, 473);
            this.BPanel1.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btn_HighGPA);
            this.panel1.Controls.Add(this.listBox_HighGPA);
            this.panel1.Font = new System.Drawing.Font("Arial Nova Cond", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(8, 277);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(218, 187);
            this.panel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.textBox_MinGPA);
            this.panel2.Controls.Add(this.Label_MinGPA);
            this.panel2.Controls.Add(this.btn_ShowRecords);
            this.panel2.Controls.Add(this.listBox_MinGPA);
            this.panel2.Font = new System.Drawing.Font("Arial Nova Cond", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(233, 277);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(218, 187);
            this.panel2.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(34)))), ((int)(((byte)(34)))));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this._GroupRecordsGPA);
            this.panel3.Controls.Add(this.listBox_GroupGPA);
            this.panel3.Controls.Add(this.btn_GroupRecordsGPA);
            this.panel3.Controls.Add(this.btn_ViewGradeStat);
            this.panel3.Font = new System.Drawing.Font("Arial Nova Cond", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(457, 9);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(315, 455);
            this.panel3.TabIndex = 3;
            // 
            // listBox_HighGPA
            // 
            this.listBox_HighGPA.FormattingEnabled = true;
            this.listBox_HighGPA.ItemHeight = 14;
            this.listBox_HighGPA.Items.AddRange(new object[] {
            ""});
            this.listBox_HighGPA.Location = new System.Drawing.Point(9, 33);
            this.listBox_HighGPA.Name = "listBox_HighGPA";
            this.listBox_HighGPA.Size = new System.Drawing.Size(199, 144);
            this.listBox_HighGPA.TabIndex = 0;
            // 
            // btn_HighGPA
            // 
            this.btn_HighGPA.Location = new System.Drawing.Point(8, 7);
            this.btn_HighGPA.Name = "btn_HighGPA";
            this.btn_HighGPA.Size = new System.Drawing.Size(199, 20);
            this.btn_HighGPA.TabIndex = 1;
            this.btn_HighGPA.Text = "Show Srudents with High GPA";
            this.btn_HighGPA.UseVisualStyleBackColor = true;
            this.btn_HighGPA.Click += new System.EventHandler(this.btn_HighGPA_Click);
            // 
            // btn_ShowRecords
            // 
            this.btn_ShowRecords.Location = new System.Drawing.Point(9, 33);
            this.btn_ShowRecords.Name = "btn_ShowRecords";
            this.btn_ShowRecords.Size = new System.Drawing.Size(200, 20);
            this.btn_ShowRecords.TabIndex = 3;
            this.btn_ShowRecords.Text = "Show Records";
            this.btn_ShowRecords.UseVisualStyleBackColor = true;
            this.btn_ShowRecords.Click += new System.EventHandler(this.btn_ShowRecords_Click);
            // 
            // listBox_MinGPA
            // 
            this.listBox_MinGPA.FormattingEnabled = true;
            this.listBox_MinGPA.ItemHeight = 14;
            this.listBox_MinGPA.Items.AddRange(new object[] {
            ""});
            this.listBox_MinGPA.Location = new System.Drawing.Point(9, 59);
            this.listBox_MinGPA.Name = "listBox_MinGPA";
            this.listBox_MinGPA.Size = new System.Drawing.Size(199, 116);
            this.listBox_MinGPA.TabIndex = 2;
            // 
            // Label_MinGPA
            // 
            this.Label_MinGPA.AutoSize = true;
            this.Label_MinGPA.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Label_MinGPA.Location = new System.Drawing.Point(7, 10);
            this.Label_MinGPA.Name = "Label_MinGPA";
            this.Label_MinGPA.Size = new System.Drawing.Size(99, 14);
            this.Label_MinGPA.TabIndex = 4;
            this.Label_MinGPA.Text = "Enter Minimum GPA";
            // 
            // textBox_MinGPA
            // 
            this.textBox_MinGPA.Location = new System.Drawing.Point(113, 7);
            this.textBox_MinGPA.Name = "textBox_MinGPA";
            this.textBox_MinGPA.Size = new System.Drawing.Size(95, 21);
            this.textBox_MinGPA.TabIndex = 5;
            // 
            // btn_ViewGradeStat
            // 
            this.btn_ViewGradeStat.Location = new System.Drawing.Point(7, 7);
            this.btn_ViewGradeStat.Name = "btn_ViewGradeStat";
            this.btn_ViewGradeStat.Size = new System.Drawing.Size(146, 34);
            this.btn_ViewGradeStat.TabIndex = 2;
            this.btn_ViewGradeStat.Text = "View Grade Statistics";
            this.btn_ViewGradeStat.UseVisualStyleBackColor = true;
            this.btn_ViewGradeStat.Click += new System.EventHandler(this.btn_ViewGradeStat_Click);
            // 
            // btn_GroupRecordsGPA
            // 
            this.btn_GroupRecordsGPA.Location = new System.Drawing.Point(158, 7);
            this.btn_GroupRecordsGPA.Name = "btn_GroupRecordsGPA";
            this.btn_GroupRecordsGPA.Size = new System.Drawing.Size(149, 34);
            this.btn_GroupRecordsGPA.TabIndex = 3;
            this.btn_GroupRecordsGPA.Text = "Group Records by GPA";
            this.btn_GroupRecordsGPA.UseVisualStyleBackColor = true;
            this.btn_GroupRecordsGPA.Click += new System.EventHandler(this.btn_GroupRecordsGPA_Click);
            // 
            // listBox_GroupGPA
            // 
            this.listBox_GroupGPA.FormattingEnabled = true;
            this.listBox_GroupGPA.ItemHeight = 14;
            this.listBox_GroupGPA.Items.AddRange(new object[] {
            ""});
            this.listBox_GroupGPA.Location = new System.Drawing.Point(158, 47);
            this.listBox_GroupGPA.Name = "listBox_GroupGPA";
            this.listBox_GroupGPA.Size = new System.Drawing.Size(149, 396);
            this.listBox_GroupGPA.TabIndex = 2;
            // 
            // labelCount
            // 
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new System.Drawing.Point(3, 10);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new System.Drawing.Size(34, 14);
            this.labelCount.TabIndex = 4;
            this.labelCount.Text = "Count";
            // 
            // labelMin
            // 
            this.labelMin.AutoSize = true;
            this.labelMin.Location = new System.Drawing.Point(3, 34);
            this.labelMin.Name = "labelMin";
            this.labelMin.Size = new System.Drawing.Size(40, 14);
            this.labelMin.TabIndex = 5;
            this.labelMin.Text = "Lowest";
            // 
            // labelMax
            // 
            this.labelMax.AutoSize = true;
            this.labelMax.Location = new System.Drawing.Point(3, 59);
            this.labelMax.Name = "labelMax";
            this.labelMax.Size = new System.Drawing.Size(43, 14);
            this.labelMax.TabIndex = 7;
            this.labelMax.Text = "Highest";
            // 
            // labelAverage
            // 
            this.labelAverage.AutoSize = true;
            this.labelAverage.Location = new System.Drawing.Point(3, 84);
            this.labelAverage.Name = "labelAverage";
            this.labelAverage.Size = new System.Drawing.Size(45, 14);
            this.labelAverage.TabIndex = 6;
            this.labelAverage.Text = "Average";
            // 
            // _GroupRecordsGPA
            // 
            this._GroupRecordsGPA.BackColor = System.Drawing.Color.White;
            this._GroupRecordsGPA.Controls.Add(this.labelMax);
            this._GroupRecordsGPA.Controls.Add(this.labelAverage);
            this._GroupRecordsGPA.Controls.Add(this.labelMin);
            this._GroupRecordsGPA.Controls.Add(this.labelCount);
            this._GroupRecordsGPA.Location = new System.Drawing.Point(8, 47);
            this._GroupRecordsGPA.Name = "_GroupRecordsGPA";
            this._GroupRecordsGPA.Size = new System.Drawing.Size(144, 396);
            this._GroupRecordsGPA.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(787, 479);
            this.Controls.Add(this.BPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Form1";
            this.Text = "Database Query Bautista";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).EndInit();
            this.BPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this._GroupRecordsGPA.ResumeLayout(false);
            this._GroupRecordsGPA.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CartmanCollegeDataSet cartmanCollegeDataSet;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel BPanel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel _GroupRecordsGPA;
        private System.Windows.Forms.Label labelMax;
        private System.Windows.Forms.Label labelAverage;
        private System.Windows.Forms.Label labelMin;
        private System.Windows.Forms.Label labelCount;
        private System.Windows.Forms.ListBox listBox_GroupGPA;
        private System.Windows.Forms.Button btn_GroupRecordsGPA;
        private System.Windows.Forms.Button btn_ViewGradeStat;
        private System.Windows.Forms.TextBox textBox_MinGPA;
        private System.Windows.Forms.Label Label_MinGPA;
        private System.Windows.Forms.Button btn_ShowRecords;
        private System.Windows.Forms.ListBox listBox_MinGPA;
        private System.Windows.Forms.Button btn_HighGPA;
        private System.Windows.Forms.ListBox listBox_HighGPA;
    }
}

