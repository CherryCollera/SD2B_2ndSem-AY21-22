﻿/*  20-01732
    Angelica D. Medina

    BSCSSD-2B
    April 07, 2022

This will display the basic operations on Mathemetics.
*/

using System;

namespace BasicOperations_Medina
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            System.Console.Write("Enter the First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());

            System .Console.Write("Enter the Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            System.Console.WriteLine("");


            Console.Write(
                "\nSum = {0} " +
                "\nDifference = {1} " +
                "\nProduct = {2} " +
                "\nQuotient = {3} " +
                "\nRemainder = {4}",
                num1 + num2, num1 - num2, num1 * num2, num1 / num2, num1 % num2);

            System.Console.WriteLine("");

            Console.ReadKey();

        }
    }
}
