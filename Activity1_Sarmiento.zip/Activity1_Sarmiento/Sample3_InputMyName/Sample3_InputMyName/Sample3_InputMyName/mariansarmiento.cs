﻿/*20-00613
Marian Gillian G. Sarmiento
SD2B
March 26, 2022
This program will ask to input my name*/

using System;

namespace Sample3_InputMyName
{
    class mariansarmiento
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your name (firstname lastname) ");
            string fullName = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("Hello " + fullName + "!!!");
            Console.WriteLine("Welcome to OOP environment.");
            Console.ReadKey();
        }
    }
}
