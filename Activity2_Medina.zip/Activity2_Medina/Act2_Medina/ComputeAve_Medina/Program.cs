﻿/*  20-01732
    Angelica D. Medina

    BSCSSD-2B
    April 07, 2022

This program will compute the average of the five input grades.
*/

using System;

namespace ComputeAve_Medina
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] nums = new double[6]; nums[5] = 0;

            System.Console.WriteLine("Enter 5 grades:	");

            for (int i = 0; i < 5; i++)
            {
                nums[i] = Convert.ToInt32(Console.ReadLine());
                nums[5] += nums[i];
            }
            System.Console.WriteLine("");

            System.Console.WriteLine("The Average is {0:0.000}", nums[5] / 5);

            System.Console.WriteLine("");

            System.Console.ReadKey();
        }
    }
}
