﻿/** ===========================
 Name: Reywen Lee Bautista
 Course & Section: BSCS-SD2B
 Date: April 1, 2022
=============================*/

using System;

namespace DeclaringConstants_Bautista
{
    class Program
    {
        static void Main(string[] args)
        {
            double radius, pi = 3.14159;
            Console.Write("Enter Radius: ");

            radius = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\nRadius: {0:0.0000} \nArea: {1:0.0000}", radius, pi * radius * radius);
            Console.ReadKey();
        }
    }
}
