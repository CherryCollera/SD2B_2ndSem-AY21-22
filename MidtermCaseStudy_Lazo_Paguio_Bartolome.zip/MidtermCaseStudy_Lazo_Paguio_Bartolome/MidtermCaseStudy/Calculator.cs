﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidtermCaseStudy
{
    public partial class Calculator : Form
    {

        double total1 = 0;

        double total2 = 0;

        bool plusButtonClicked = false;

        bool minusButtonClicked = false;

        bool divideButtonClicked = false;

        bool multiplyButtonClicked = false;

        public Calculator()
        {
            InitializeComponent();
        }

        private void Calculator_Load(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + nine.Text;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + dot.Text;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            minusButtonClicked = true;
            plusButtonClicked = false;
            divideButtonClicked = false;
            multiplyButtonClicked = false;
        }

        private void one_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + one.Text;
        }

        private void two_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + two.Text;
        }

        private void three_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + three.Text;
        }

        private void four_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + four.Text;
        }

        private void five_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + five.Text;
        }

        private void six_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + six.Text;
        }

        private void seven_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + seven.Text;
        }

        private void eight_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + eight.Text;
        }

        private void zero_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + zero.Text;
        }

        private void clear_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            minusButtonClicked = false;
            plusButtonClicked = true;
            divideButtonClicked = false;
            multiplyButtonClicked = false;
        }

        private void equalsBtn_Click(object sender, EventArgs e)
        {
            if (plusButtonClicked == true)

            {
                total2 = total1 + double.Parse(txtDisplay.Text);

            }
            else if (minusButtonClicked == true)
            {
                total2 = total1 - double.Parse(txtDisplay.Text);
            }
            else if (multiplyButtonClicked == true)
            {
                total2 = total1 * double.Parse(txtDisplay.Text);
            }
            else if (divideButtonClicked == true)
            {
                total2 = total1 / double.Parse(txtDisplay.Text);
            }
            txtDisplay.Text = total2.ToString(); total1 = 0;
        }

        private void multiplyBtn_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            minusButtonClicked = false;
            plusButtonClicked = false;
            divideButtonClicked = false;
            multiplyButtonClicked = true;
        }

        private void divideBtn_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            minusButtonClicked = false;
            plusButtonClicked = false;
            divideButtonClicked = true;
            multiplyButtonClicked = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.Show();
            this.Hide();
        }
    }
}
