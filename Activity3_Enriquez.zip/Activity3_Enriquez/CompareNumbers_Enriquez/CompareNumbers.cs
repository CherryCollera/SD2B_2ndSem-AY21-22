﻿/* 20 - 01484
 John Brix B. Enriquez
 SD2B
 April 17, 2022
 This program will compare three number*/

using System;
namespace CompareNumbers
{
    class CompareNumbers
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;
            Console.Write("Enter 1st number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 2nd number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 3rd number: ");
            num3 = Convert.ToInt32(Console.ReadLine());

            //Two number are equal but less than the other number
            if (num1 == num2 && num1 < num3)
            {
                Console.WriteLine("{0} and {1} are equal", num1, num2);
                Console.WriteLine("{0} and {1} are less than {2}", num1, num2, num3);
            }
            else if (num2 == num3 && num2 < num1)
            {
                Console.WriteLine("{0} and {1} are equal", num2, num3);
                Console.WriteLine("{0} and {1} are less than {2}", num2, num3, num1);
            }
            else if (num1 == num3 && num1 < num2)
            {
                Console.WriteLine("{0} and {1} are equal", num1, num3);
                Console.WriteLine("{0} and {1} are less than {2}", num1, num3, num2);
            }

            //Two number are equal and greater than the other number
            else if (num1 == num2 && num1 > num3)
            {
                Console.WriteLine("{0} and {1} are equal", num1, num2);
                Console.WriteLine("{0} is less than {1} and {2}", num3, num1, num2);
            }
            else if (num2 == num3 && num2 > num1)
            {
                Console.WriteLine("{0} and {1} are equal", num2, num3);
                Console.WriteLine("{0} is less than {1} and {2}", num1, num2, num3);
            }
            else if (num1 == num3 && num1 > num2)
            {
                Console.WriteLine("{0} and {1} are equal", num1, num3);
                Console.WriteLine("{0} is less than {1} and {2}", num2, num1, num3);
            }

            //Comparing three different numbers
            else if (num1 > num2 && num1 > num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num1, num2, num3);
                Console.WriteLine("{0} is less than {1}", num2, num1);
                Console.WriteLine("{0} is less than {1}", num3, num1);
            }
            else if (num2 > num1 && num2 > num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num2, num1, num3);
                Console.WriteLine("{0} is less than {1}", num1, num2);
                Console.WriteLine("{0} is less than {1}", num3, num2);
            }
            else if (num3 > num1 && num3 > num2)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num3, num1, num2);
                Console.WriteLine("{0} is less than {1}", num1, num3);
                Console.WriteLine("{0} is less than {1}", num2, num3);
            }
            else
            {
                Console.WriteLine("{0} {1} and {2} are equal", num1, num2, num3);  
            }
            Console.ReadKey();
        }
    }
}