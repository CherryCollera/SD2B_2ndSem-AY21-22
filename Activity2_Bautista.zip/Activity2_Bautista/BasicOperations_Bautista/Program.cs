﻿/** ===========================
 Name: Reywen Lee Bautista
 Course & Section: BSCS-SD2B
 Date: April 1, 2022
=============================*/

using System;

namespace BasicOperations_Bautista
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("Enter the first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.Write(
                "\nSum = {0} " +
                "\nDifference = {1} " +
                "\nProduct = {2} " +
                "\nQuotient = {3} " +
                "\nRemainder = {4}",
                num1 + num2, num1 - num2, num1 * num2, num1 / num2, num1 % num2);

            Console.ReadKey();

        }
    }
}
