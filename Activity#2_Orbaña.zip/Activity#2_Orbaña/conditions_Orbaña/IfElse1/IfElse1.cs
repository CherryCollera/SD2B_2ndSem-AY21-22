﻿using System;

namespace IfElse1
{
    class IfElse1
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("Enter first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            if (num1 < num2)
                Console.WriteLine("\n" + num1 + " is less than " + num2 + ".");
            else if (num1 > num2)
                Console.WriteLine("\n" + num1 + " is greater than " + num2 + ".");
            else
                Console.WriteLine("\n" + num1 + " is equal to " + num2 + ".");
            Console.ReadLine();
        }
    }
}
