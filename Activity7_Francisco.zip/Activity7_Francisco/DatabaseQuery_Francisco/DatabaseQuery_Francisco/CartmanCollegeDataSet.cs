﻿namespace DatabaseQuery_Francisco
{


    partial class CartmanCollegeDataSet
    {
    }
}

namespace DatabaseQuery_Francisco.CartmanCollegeDataSetTableAdapters {
    
    
    public partial class tblStudentsTableAdapter {
    }
}
