﻿using System;

namespace DeclaringConstants_Mendoza
{
    class Constants
    {
        static void Main(string[] args)
        {

            double  AreaCircle, radius;
            const double pi = 3.14159;
            
            Console.Write("Enter Radius:  ");
            radius = Convert.ToDouble(Console.ReadLine());
            AreaCircle = pi * radius * radius;





            Console.WriteLine("Radius: " + radius.ToString("F4", System.Globalization.CultureInfo.InvariantCulture) 
                + ", Area:" + Math.Round(AreaCircle,4));

            Console.ReadLine();
        }
    }
}