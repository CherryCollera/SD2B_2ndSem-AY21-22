﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 16, 2022
 *  Display numbers from 0-9 using while loop
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CompareNames
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 0;


            while (i * 5 < 10)
            {
                Console.WriteLine(i);
                i++;
            }
        }
    }
}
