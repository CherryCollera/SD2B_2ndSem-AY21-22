﻿namespace DatabaseQuery_Enriquez
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn_HighGPA = new System.Windows.Forms.Button();
            this.listBox_highGPA = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_minGPA = new System.Windows.Forms.TextBox();
            this.btn_showRecords = new System.Windows.Forms.Button();
            this.listBox_minGPA = new System.Windows.Forms.ListBox();
            this.btn_gradeStatistics = new System.Windows.Forms.Button();
            this.btn_groupRecordGPA = new System.Windows.Forms.Button();
            this.listBox_GroupRecordsGPA = new System.Windows.Forms.ListBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cartmanCollegeDataSet = new DatabaseQuery_Enriquez.CartmanCollegeDataSet();
            this.tblStudentsTableAdapter = new DatabaseQuery_Enriquez.CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter();
            this.labelCount = new System.Windows.Forms.Label();
            this.labelMin = new System.Windows.Forms.Label();
            this.labelMax = new System.Windows.Forms.Label();
            this.labelAverage = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_HighGPA
            // 
            this.btn_HighGPA.Location = new System.Drawing.Point(23, 266);
            this.btn_HighGPA.Name = "btn_HighGPA";
            this.btn_HighGPA.Size = new System.Drawing.Size(223, 40);
            this.btn_HighGPA.TabIndex = 0;
            this.btn_HighGPA.Text = "Show Grade with High GPA";
            this.btn_HighGPA.UseVisualStyleBackColor = true;
            this.btn_HighGPA.Click += new System.EventHandler(this.btn_highGPA_Click);
            // 
            // listBox_highGPA
            // 
            this.listBox_highGPA.FormattingEnabled = true;
            this.listBox_highGPA.ItemHeight = 16;
            this.listBox_highGPA.Location = new System.Drawing.Point(23, 322);
            this.listBox_highGPA.Name = "listBox_highGPA";
            this.listBox_highGPA.Size = new System.Drawing.Size(223, 116);
            this.listBox_highGPA.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(288, 266);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Enter Minimum GPA:";
            // 
            // textBox_minGPA
            // 
            this.textBox_minGPA.Location = new System.Drawing.Point(422, 263);
            this.textBox_minGPA.Name = "textBox_minGPA";
            this.textBox_minGPA.Size = new System.Drawing.Size(100, 22);
            this.textBox_minGPA.TabIndex = 3;
            // 
            // btn_showRecords
            // 
            this.btn_showRecords.Location = new System.Drawing.Point(291, 314);
            this.btn_showRecords.Name = "btn_showRecords";
            this.btn_showRecords.Size = new System.Drawing.Size(170, 23);
            this.btn_showRecords.TabIndex = 4;
            this.btn_showRecords.Text = "Show Records";
            this.btn_showRecords.UseVisualStyleBackColor = true;
            this.btn_showRecords.Click += new System.EventHandler(this.btn_showRecords_Click);
            // 
            // listBox_minGPA
            // 
            this.listBox_minGPA.FormattingEnabled = true;
            this.listBox_minGPA.ItemHeight = 16;
            this.listBox_minGPA.Location = new System.Drawing.Point(295, 354);
            this.listBox_minGPA.Name = "listBox_minGPA";
            this.listBox_minGPA.Size = new System.Drawing.Size(236, 84);
            this.listBox_minGPA.TabIndex = 5;
            // 
            // btn_gradeStatistics
            // 
            this.btn_gradeStatistics.Location = new System.Drawing.Point(584, 51);
            this.btn_gradeStatistics.Name = "btn_gradeStatistics";
            this.btn_gradeStatistics.Size = new System.Drawing.Size(198, 23);
            this.btn_gradeStatistics.TabIndex = 6;
            this.btn_gradeStatistics.Text = "View Grade Statistics";
            this.btn_gradeStatistics.UseVisualStyleBackColor = true;
            this.btn_gradeStatistics.Click += new System.EventHandler(this.btn_gradeStatistics_Click);
            // 
            // btn_groupRecordGPA
            // 
            this.btn_groupRecordGPA.Location = new System.Drawing.Point(805, 51);
            this.btn_groupRecordGPA.Name = "btn_groupRecordGPA";
            this.btn_groupRecordGPA.Size = new System.Drawing.Size(196, 23);
            this.btn_groupRecordGPA.TabIndex = 7;
            this.btn_groupRecordGPA.Text = "Group Records by GPA";
            this.btn_groupRecordGPA.UseVisualStyleBackColor = true;
            this.btn_groupRecordGPA.Click += new System.EventHandler(this.btn_groupRecordGPA_Click);
            // 
            // listBox_GroupRecordsGPA
            // 
            this.listBox_GroupRecordsGPA.FormattingEnabled = true;
            this.listBox_GroupRecordsGPA.ItemHeight = 16;
            this.listBox_GroupRecordsGPA.Location = new System.Drawing.Point(805, 98);
            this.listBox_GroupRecordsGPA.Name = "listBox_GroupRecordsGPA";
            this.listBox_GroupRecordsGPA.Size = new System.Drawing.Size(196, 276);
            this.listBox_GroupRecordsGPA.TabIndex = 8;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 51);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(566, 206);
            this.dataGridView1.TabIndex = 9;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.Width = 125;
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            this.lastNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            this.firstNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            this.gradePointAverageDataGridViewTextBoxColumn.Width = 125;
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet;
            // 
            // cartmanCollegeDataSet
            // 
            this.cartmanCollegeDataSet.DataSetName = "CartmanCollegeDataSet";
            this.cartmanCollegeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // labelCount
            // 
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new System.Drawing.Point(599, 94);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new System.Drawing.Size(44, 16);
            this.labelCount.TabIndex = 10;
            this.labelCount.Text = "label2";
            // 
            // labelMin
            // 
            this.labelMin.AutoSize = true;
            this.labelMin.Location = new System.Drawing.Point(599, 133);
            this.labelMin.Name = "labelMin";
            this.labelMin.Size = new System.Drawing.Size(44, 16);
            this.labelMin.TabIndex = 11;
            this.labelMin.Text = "label3";
            // 
            // labelMax
            // 
            this.labelMax.AutoSize = true;
            this.labelMax.Location = new System.Drawing.Point(599, 171);
            this.labelMax.Name = "labelMax";
            this.labelMax.Size = new System.Drawing.Size(44, 16);
            this.labelMax.TabIndex = 12;
            this.labelMax.Text = "label4";
            // 
            // labelAverage
            // 
            this.labelAverage.AutoSize = true;
            this.labelAverage.Location = new System.Drawing.Point(599, 210);
            this.labelAverage.Name = "labelAverage";
            this.labelAverage.Size = new System.Drawing.Size(44, 16);
            this.labelAverage.TabIndex = 13;
            this.labelAverage.Text = "label2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1042, 450);
            this.Controls.Add(this.labelAverage);
            this.Controls.Add(this.labelMax);
            this.Controls.Add(this.labelMin);
            this.Controls.Add(this.labelCount);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.listBox_GroupRecordsGPA);
            this.Controls.Add(this.btn_groupRecordGPA);
            this.Controls.Add(this.btn_gradeStatistics);
            this.Controls.Add(this.listBox_minGPA);
            this.Controls.Add(this.btn_showRecords);
            this.Controls.Add(this.textBox_minGPA);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox_highGPA);
            this.Controls.Add(this.btn_HighGPA);
            this.Name = "Form1";
            this.Text = "Database Query Enriquez";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_HighGPA;
        private System.Windows.Forms.ListBox listBox_highGPA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_minGPA;
        private System.Windows.Forms.Button btn_showRecords;
        private System.Windows.Forms.ListBox listBox_minGPA;
        private System.Windows.Forms.Button btn_gradeStatistics;
        private System.Windows.Forms.Button btn_groupRecordGPA;
        private System.Windows.Forms.ListBox listBox_GroupRecordsGPA;
        private System.Windows.Forms.DataGridView dataGridView1;
        private CartmanCollegeDataSet cartmanCollegeDataSet;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label labelCount;
        private System.Windows.Forms.Label labelMin;
        private System.Windows.Forms.Label labelMax;
        private System.Windows.Forms.Label labelAverage;
    }
}

