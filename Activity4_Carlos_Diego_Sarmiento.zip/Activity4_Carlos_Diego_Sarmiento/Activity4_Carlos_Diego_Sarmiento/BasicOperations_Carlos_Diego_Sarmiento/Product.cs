﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Carlos_Diego_Sarmiento
{
    class Product
    {
        public void computeProduct()
        {
            DeclareVar.prod = DeclareVar.num1 * DeclareVar.num2;
            Console.WriteLine("The product is {0}", DeclareVar.prod);
        }
    }
}
