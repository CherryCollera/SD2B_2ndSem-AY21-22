﻿/*
20-02604
Jaycee Audrei Mari M. Quitaleg
SD2B
April 06, 2022
This program will take five integer inputs from the user and display its average.
 */

using System;

namespace Compute_Average
{
    class Compute_Average
    {
        static void Main()
        {
            Console.WriteLine("Enter five grades.");
            int num1 = Convert.ToInt32(Console.ReadLine());
            int num2 = Convert.ToInt32(Console.ReadLine());
            int num3 = Convert.ToInt32(Console.ReadLine());
            int num4 = Convert.ToInt32(Console.ReadLine());
            int num5 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Average = {0}", (num1+num2+num3+num4+num5)/5);
            Console.ReadLine();
        }
    }
}
