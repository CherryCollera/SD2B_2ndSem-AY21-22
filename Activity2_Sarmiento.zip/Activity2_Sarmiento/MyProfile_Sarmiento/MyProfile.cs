﻿/*20-00613
Marian Gillian G. Sarmiento
SD2B
April 5, 2022
This program will display my profile*/

using System;

namespace MyProfile_Sarmiento
{
    class MyProfile
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name: Marian Gillian G. Sarmiento" + "\n");
            Console.WriteLine("Date of Birth: December 30" + "\n");
            Console.WriteLine("Course: BS Computer Science" + "\n");
            Console.WriteLine("Year: II" + "\n");
            Console.WriteLine("Section: SD2B" + "\n");
            Console.ReadKey();
        }
    }
}
