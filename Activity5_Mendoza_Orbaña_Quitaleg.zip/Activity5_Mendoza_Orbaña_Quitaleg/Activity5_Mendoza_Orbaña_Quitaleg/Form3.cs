﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity5_Mendoza_Orbaña_Quitaleg
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
            this.Hide();
        }

        private void hideBtn_Click(object sender, EventArgs e)
        {
            Form4 form = new Form4();
            form.Show();
            this.Hide();
        }

        private void profileBtn_Click(object sender, EventArgs e)
        {
            string fname = fnameTxt.Text;
            string lname = lnameTxt.Text;

            MessageBox.Show("\t\tHello " + fname + " " + lname +
                "\nDate of Birth\t:\tFebruary 21,2002" +
                "\nCourse\t\t:\tBS Computer Science" +
                "\nYear\t\t:\tII" +
                "\nSection\t\t:\tB");

        }

        private void fnameTxt_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
