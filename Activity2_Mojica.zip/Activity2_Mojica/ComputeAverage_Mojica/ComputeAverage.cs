﻿/*
 * student Id number : 20-05258
 * student full name : Zedrick A. Mojica
 * Section : BSCS-SD2B
 * Date : 04/04/2022
 * Purpose : compute the average of 5 grades
 */
using System;

namespace Activity2_Mojica
{
    class ComputeAverage
    {
        static void Main(string[] args)
        {
            int num1, num2, num3, num4, num5;
            System.Console.WriteLine("Enter five grades : ");
            num1 = Convert.ToInt32(Console.ReadLine()); 
            System.Console.Write("");
            num2 = Convert.ToInt32(Console.ReadLine());
            System.Console.Write("");
            num3 = Convert.ToInt32(Console.ReadLine());
            System.Console.Write("");
            num4 = Convert.ToInt32(Console.ReadLine());
            System.Console.Write("");
            num5 = Convert.ToInt32(Console.ReadLine());
            System.Console.Write("");
            System.Console.WriteLine("The average is : {0} ", (num1 + num2 + num3 + num4 + num5)/5);
            System.Console.ReadKey();
        }
    }
}