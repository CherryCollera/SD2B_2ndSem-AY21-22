﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1_Matos_Nicdao_Mojardin
    {
        internal class HappyBirthday
            {
                public string GetMessage(string firstname)
                    {
                        return "Happy Birtday to you, " + firstname + "!!";
                    }
            }
    }
