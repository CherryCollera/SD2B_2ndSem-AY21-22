﻿namespace Activity6_Cruz__Z
{


    partial class MyDatabaseDataSet
    {
    }
}

namespace Activity6_Cruz__Z.MyDatabaseDataSetTableAdapters {
    
    
    public partial class StudentTableAdapter {
    }
}
