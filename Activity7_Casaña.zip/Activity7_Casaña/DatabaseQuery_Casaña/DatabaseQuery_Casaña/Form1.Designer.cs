﻿
namespace DatabaseQuery_Casaña
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cartmanCollegeDataSet = new DatabaseQuery_Casaña.CartmanCollegeDataSet();
            this.tblStudentsTableAdapter = new DatabaseQuery_Casaña.CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter();
            this.BtnHighGPA = new System.Windows.Forms.Button();
            this.listBoxHighGPA = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtShowRecords = new System.Windows.Forms.TextBox();
            this.btnShowRecords = new System.Windows.Forms.Button();
            this.listBoxMinGPA = new System.Windows.Forms.ListBox();
            this.btnGradeStats = new System.Windows.Forms.Button();
            this.labelCount = new System.Windows.Forms.Label();
            this.labelMin = new System.Windows.Forms.Label();
            this.labelMax = new System.Windows.Forms.Label();
            this.labelAverage = new System.Windows.Forms.Label();
            this.btnGroupRecords = new System.Windows.Forms.Button();
            this.listBoxGroupGPA = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(21, 10);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(496, 162);
            this.dataGridView1.TabIndex = 0;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet;
            // 
            // cartmanCollegeDataSet
            // 
            this.cartmanCollegeDataSet.DataSetName = "CartmanCollegeDataSet";
            this.cartmanCollegeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // BtnHighGPA
            // 
            this.BtnHighGPA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.BtnHighGPA.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnHighGPA.Location = new System.Drawing.Point(21, 192);
            this.BtnHighGPA.Margin = new System.Windows.Forms.Padding(2);
            this.BtnHighGPA.Name = "BtnHighGPA";
            this.BtnHighGPA.Size = new System.Drawing.Size(235, 26);
            this.BtnHighGPA.TabIndex = 1;
            this.BtnHighGPA.Text = "Show Students with High GPA";
            this.BtnHighGPA.UseVisualStyleBackColor = false;
            this.BtnHighGPA.Click += new System.EventHandler(this.BtnHighGPA_Click);
            // 
            // listBoxHighGPA
            // 
            this.listBoxHighGPA.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.listBoxHighGPA.FormattingEnabled = true;
            this.listBoxHighGPA.ItemHeight = 16;
            this.listBoxHighGPA.Location = new System.Drawing.Point(21, 250);
            this.listBoxHighGPA.Name = "listBoxHighGPA";
            this.listBoxHighGPA.Size = new System.Drawing.Size(235, 116);
            this.listBoxHighGPA.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(282, 186);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "Enter minimum GPA: ";
            // 
            // txtShowRecords
            // 
            this.txtShowRecords.Location = new System.Drawing.Point(420, 183);
            this.txtShowRecords.Name = "txtShowRecords";
            this.txtShowRecords.Size = new System.Drawing.Size(97, 22);
            this.txtShowRecords.TabIndex = 4;
            // 
            // btnShowRecords
            // 
            this.btnShowRecords.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnShowRecords.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnShowRecords.Location = new System.Drawing.Point(346, 211);
            this.btnShowRecords.Name = "btnShowRecords";
            this.btnShowRecords.Size = new System.Drawing.Size(115, 23);
            this.btnShowRecords.TabIndex = 5;
            this.btnShowRecords.Text = "Show Records";
            this.btnShowRecords.UseVisualStyleBackColor = false;
            this.btnShowRecords.Click += new System.EventHandler(this.btnShowRecords_Click);
            // 
            // listBoxMinGPA
            // 
            this.listBoxMinGPA.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.listBoxMinGPA.FormattingEnabled = true;
            this.listBoxMinGPA.ItemHeight = 16;
            this.listBoxMinGPA.Location = new System.Drawing.Point(285, 250);
            this.listBoxMinGPA.Name = "listBoxMinGPA";
            this.listBoxMinGPA.Size = new System.Drawing.Size(235, 116);
            this.listBoxMinGPA.TabIndex = 6;
            // 
            // btnGradeStats
            // 
            this.btnGradeStats.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnGradeStats.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGradeStats.Location = new System.Drawing.Point(537, 27);
            this.btnGradeStats.Name = "btnGradeStats";
            this.btnGradeStats.Size = new System.Drawing.Size(205, 23);
            this.btnGradeStats.TabIndex = 7;
            this.btnGradeStats.Text = "View Grade Statistics";
            this.btnGradeStats.UseVisualStyleBackColor = false;
            this.btnGradeStats.Click += new System.EventHandler(this.btnGradeStats_Click);
            // 
            // labelCount
            // 
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new System.Drawing.Point(550, 75);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new System.Drawing.Size(0, 16);
            this.labelCount.TabIndex = 8;
            // 
            // labelMin
            // 
            this.labelMin.AutoSize = true;
            this.labelMin.Location = new System.Drawing.Point(550, 110);
            this.labelMin.Name = "labelMin";
            this.labelMin.Size = new System.Drawing.Size(0, 16);
            this.labelMin.TabIndex = 9;
            // 
            // labelMax
            // 
            this.labelMax.AutoSize = true;
            this.labelMax.Location = new System.Drawing.Point(550, 145);
            this.labelMax.Name = "labelMax";
            this.labelMax.Size = new System.Drawing.Size(0, 16);
            this.labelMax.TabIndex = 10;
            // 
            // labelAverage
            // 
            this.labelAverage.AutoSize = true;
            this.labelAverage.Location = new System.Drawing.Point(550, 180);
            this.labelAverage.Name = "labelAverage";
            this.labelAverage.Size = new System.Drawing.Size(0, 16);
            this.labelAverage.TabIndex = 11;
            // 
            // btnGroupRecords
            // 
            this.btnGroupRecords.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnGroupRecords.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGroupRecords.Location = new System.Drawing.Point(780, 27);
            this.btnGroupRecords.Name = "btnGroupRecords";
            this.btnGroupRecords.Size = new System.Drawing.Size(162, 23);
            this.btnGroupRecords.TabIndex = 12;
            this.btnGroupRecords.Text = "Group Records by GPA";
            this.btnGroupRecords.UseVisualStyleBackColor = false;
            this.btnGroupRecords.Click += new System.EventHandler(this.btnGroupRecords_Click);
            // 
            // listBoxGroupGPA
            // 
            this.listBoxGroupGPA.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.listBoxGroupGPA.FormattingEnabled = true;
            this.listBoxGroupGPA.ItemHeight = 16;
            this.listBoxGroupGPA.Location = new System.Drawing.Point(780, 58);
            this.listBoxGroupGPA.Name = "listBoxGroupGPA";
            this.listBoxGroupGPA.Size = new System.Drawing.Size(162, 228);
            this.listBoxGroupGPA.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(964, 374);
            this.Controls.Add(this.listBoxGroupGPA);
            this.Controls.Add(this.btnGroupRecords);
            this.Controls.Add(this.labelAverage);
            this.Controls.Add(this.labelMax);
            this.Controls.Add(this.labelMin);
            this.Controls.Add(this.labelCount);
            this.Controls.Add(this.btnGradeStats);
            this.Controls.Add(this.listBoxMinGPA);
            this.Controls.Add(this.btnShowRecords);
            this.Controls.Add(this.txtShowRecords);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBoxHighGPA);
            this.Controls.Add(this.BtnHighGPA);
            this.Controls.Add(this.dataGridView1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Database Query Casaña";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CartmanCollegeDataSet cartmanCollegeDataSet;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button BtnHighGPA;
        private System.Windows.Forms.ListBox listBoxHighGPA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtShowRecords;
        private System.Windows.Forms.Button btnShowRecords;
        private System.Windows.Forms.ListBox listBoxMinGPA;
        private System.Windows.Forms.Button btnGradeStats;
        private System.Windows.Forms.Label labelCount;
        private System.Windows.Forms.Label labelMin;
        private System.Windows.Forms.Label labelMax;
        private System.Windows.Forms.Label labelAverage;
        private System.Windows.Forms.Button btnGroupRecords;
        private System.Windows.Forms.ListBox listBoxGroupGPA;
    }
}

