﻿using System;

namespace MyProfile_Takahashi
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name:\t Aira M Takahashi");
            Console.WriteLine("Date of Birth:\t April 28, 2000");
            Console.WriteLine("Course:\t BS Computer Science");
            Console.WriteLine("Year:\t 2");
            Console.WriteLine("Section:\t B");
            Console.ReadKey();
        }
    }
}
