﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicOperations_Duran_Fabian_Cruz
{
    class Difference
    {
        public void ComputeDifference()
        {
            DeclareVar.difference = DeclareVar.num1 - DeclareVar.num2;
        }
    }
}
