﻿using System;

namespace ComputeAverage
{
    class ComputeAverage
    {
        static void Main(string[] args)
        {
            int num1, num2, num3, num4, num5;
            double grade;
            Console.Write("Enter 5 grades: \n");
            num1 = Convert.ToInt32(Console.ReadLine());
            num2 = Convert.ToInt32(Console.ReadLine());
            num3 = Convert.ToInt32(Console.ReadLine());
            num4 = Convert.ToInt32(Console.ReadLine());
            num5 = Convert.ToInt32(Console.ReadLine());
            grade = num1 + num2 + num3 + num4 + num5;

            Console.WriteLine("The average is  = {0:00.000}.", grade / 5);
            Console.ReadLine();
        }
    }
}
