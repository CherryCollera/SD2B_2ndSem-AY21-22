﻿/*
 * 20-00382
 * Roiel A. Carlos
 * SD2B
 * April 7, 2022
 * This program will compare 2 numbers and display which is greater, or if they are equal.
 */
using System;

namespace IfElse1_Carlos
{
    class IfElse1
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("Enter first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2)
                Console.WriteLine(num1 + " is greater than " + num2 + ".");
            else if (num2 > num1)
                Console.WriteLine(num2 + " is greater than " + num1 + ".");
            else
                Console.WriteLine(num1 + " is equal to " + num2 + ".");

            Console.ReadKey();
        }
    }
}
