﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample1_Gallo_Mojica_Enriquez
{
    internal class Print //Creating 2nd class
    {
        public void PrintDetails()
        {
            Accept a = new Accept(); //Creating object of 1st class
            a.AcceptDetails(); //executing method of 1st class
            //Print value of name variable
            Console.WriteLine("Hello " + a.firstName + " " + a.lastName + "!!! \nYou have created class in OOP");
            MyProfile mp = new MyProfile();
            mp.DisplayProfile();
        }
    }
}
