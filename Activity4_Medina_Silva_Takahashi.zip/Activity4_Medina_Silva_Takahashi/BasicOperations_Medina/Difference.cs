﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Medina
{
    class Difference
    {
        public void ComputeDifference()
        {
            DeclareVar.diff = DeclareVar.num1 - DeclareVar.num2; //computes the difference of the two input values. 
        }
    }
}
