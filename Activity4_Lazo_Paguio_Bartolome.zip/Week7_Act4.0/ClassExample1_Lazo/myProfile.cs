class myProfile{

    public void DisplayProfile(){
        System.Console.WriteLine("\n\n\n\t\t\t\t P R O F I L E");
        System.Console.WriteLine("Name: Andrei Lazo");
        System.Console.WriteLine("Birthday: \t\tMarch 4 ,2002");
        System.Console.WriteLine("Course:\t\t\t BS Computer Science");
        System.Console.WriteLine("Year:\t\t\t2nd Year");
        System.Console.WriteLine("Section:\t\t\tB");
        System.Console.WriteLine("Section:\t\t\tB");
        System.Console.ReadLine();
    }
}