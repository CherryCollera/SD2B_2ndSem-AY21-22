﻿/*
 * 20-03273
 *  Dianna Grace Matos
 *  SD2B
 *  May 14, 2022
 *  Program: Displays "Hello world! I am Dianna!"
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Sample1_HelloWorld
    {
        internal class Program
            {
                static void Main(string[] args)
                    {
                        Console.WriteLine("Hello world! I am Dianna!");  
                        Console.ReadKey();
                    }
            }
    }
