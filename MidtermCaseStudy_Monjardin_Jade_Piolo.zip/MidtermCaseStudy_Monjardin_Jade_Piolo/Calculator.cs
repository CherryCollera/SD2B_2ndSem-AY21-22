﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidtermCaseStudy_Monjardin_Jade_Piolo
{
    public partial class Calculator : Form
    {
        double total1 = 0;
        double total2 = 0;
        bool plusButtonClicked = false;
        bool minusButtonClicked = false;
        bool divideButtonClicked = false;
        bool multiplyButtonClicked = false;

        public Calculator()
        {
            InitializeComponent();
        }

        private void Calculator_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            new Form2().Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Hide();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + btn1.Text;
        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + Btn2.Text;
        }

        private void Btn3_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + Btn3.Text;
        }

        private void Btn6_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + Btn6.Text;
        }

        private void Btn5_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + Btn5.Text;
        }

        private void Btn4_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + Btn4.Text;
        }

        private void Btn7_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + Btn7.Text;
        }

        private void Btn0_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + Btn0.Text;
        }

        private void BtnDot_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + BtnDot.Text;
        }

        private void BtnTimes_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(textBox1.Text);
            textBox1.Clear();

            minusButtonClicked = false;
            plusButtonClicked = false;
            divideButtonClicked = false;
            multiplyButtonClicked = true;
        }

        private void BtnDivide_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(textBox1.Text);
            textBox1.Clear();

            minusButtonClicked = false;
            plusButtonClicked = false;
            divideButtonClicked = true;
            multiplyButtonClicked = false;
        }

        private void BtnMinus_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(textBox1.Text);
            textBox1.Clear();

            minusButtonClicked = true;
            plusButtonClicked = false;
            divideButtonClicked = false;
            multiplyButtonClicked = false;
        }

        private void BtnPlus_Click(object sender, EventArgs e)
        {
            total1 = total1 + double.Parse(textBox1.Text);
            textBox1.Clear();

            minusButtonClicked = false;
            plusButtonClicked = true;
            divideButtonClicked = false;
            multiplyButtonClicked = false;
        }

        private void Btn8_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + Btn8.Text;
        }

        private void Btn9_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + Btn9.Text;
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void BtnEquals_Click(object sender, EventArgs e)
        {
            if (plusButtonClicked == true)
                total2 = total1 + double.Parse(textBox1.Text);
            else if (minusButtonClicked == true)
                total2 = total1 - double.Parse(textBox1.Text);
            else if (multiplyButtonClicked == true)
                total2 = total1 * double.Parse(textBox1.Text);
            else if (divideButtonClicked == true)
                total2 = total1 / double.Parse(textBox1.Text);
            textBox1.Text = total2.ToString();
            total1 = 0;
        }
    }
}
