﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Mendoza
{
     class Difference
    {
        public void ComputeDifference()
        {
            DeclareVar.diff = DeclareVar.num1 - DeclareVar.num2;

        }
    }
}
