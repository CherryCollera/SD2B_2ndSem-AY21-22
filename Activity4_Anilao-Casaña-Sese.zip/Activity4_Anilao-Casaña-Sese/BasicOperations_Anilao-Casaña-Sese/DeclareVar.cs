﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Anilao_Casaña_Sese
{
    class DeclareVar
    {
        public static int num1, num2, sum, difference, product, quotient, remainder;


    }
}
