﻿// Midterm Case Study Group 5
// Members:
//          Anilao, Jean Claudine D.
//          Casaña, Regee D.
//          Sese, Regie A.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidtermCaseStudy_Anilao_Casaña_Sese
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void msgButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hello", "My Message", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            Calculator calculator = new Calculator();
            calculator.Show();
            this.Hide();
        }
    }
}
