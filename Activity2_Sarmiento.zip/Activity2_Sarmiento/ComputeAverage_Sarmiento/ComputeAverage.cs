﻿/*20-00613
Marian Gillian G. Sarmiento
SD2B
April 5, 2022
This program will compute the average of 5 integer values*/

using System;

namespace ComputeAverage_Sarmiento
{
    class ComputeAverage
    {
        static void Main(string[] args)
        {

            double num1, num2, num3, num4, num5;

            Console.Write("Enter 5 grades: \n");
            num1 = Convert.ToDouble(Console.ReadLine());
            num2 = Convert.ToDouble(Console.ReadLine());
            num3 = Convert.ToDouble(Console.ReadLine());
            num4 = Convert.ToDouble(Console.ReadLine());
            num5 = Convert.ToDouble(Console.ReadLine());

            double avg = (num1 + num2 + num3 + num4 + num5) / 5;
            Console.WriteLine("The average is = {0:0.000}.", avg);
            Console.ReadLine();
        }
    }
}
