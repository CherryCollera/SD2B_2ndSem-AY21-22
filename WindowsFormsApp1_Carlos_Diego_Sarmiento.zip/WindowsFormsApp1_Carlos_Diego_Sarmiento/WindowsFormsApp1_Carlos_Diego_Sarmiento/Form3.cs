﻿/* Activity #5
 * Group Members: Carlos, Roiel A.
 *                Diego, Angelo R.
 *                Sarmiento, Marian Gillian G.
 * Program, Year, and Section: BSCS-SD2B
 * Date: 05/04/2022
 This form will display the name based on input and a profile. 
This form connects to Form4 and Form2
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1_Carlos_Diego_Sarmiento
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_Hide_Click(object sender, EventArgs e)
        {
            Form4 next = new Form4();
            next.Show();
            this.Hide();
        }

        private void btn_GetMyProfile_Click(object sender, EventArgs e)
        {
            string firstname = txt_Firstname.Text;
            string lastname = txt_Lastname.Text;
            MessageBox.Show("\t\tHello " + firstname + " " + lastname +
                "\nDate of Birth\t:\tDecember 3, 2001" +
                "\nCourse\t\t:\tBS Computer Science" +
                "\nYear\t\t:\tII" +
                "\nSection\t\t:\tB");
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
            this.Hide();
        }
    }
}
