﻿/*20-00903
Regie A. Sese
SD2B
March 22, 2022
This program will display my Profile*/

using System;

namespace Sample2_MyProfile
{
    class MyProfile
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Name: " + "Regie A. Sese");
            System.Console.WriteLine("\nDate of Birth: " + "September 14, 2001");
            System.Console.WriteLine("\nCourse: " + "BS in Computer Science major in Software Development");
            System.Console.WriteLine("\nYear: " + "II");
            System.Console.WriteLine("\nSection: " + "SD2B");
            System.Console.ReadLine();
        }
    }
}