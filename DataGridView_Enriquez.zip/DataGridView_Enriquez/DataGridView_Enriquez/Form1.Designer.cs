﻿namespace DataGridView_Enriquez
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.studIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.middleNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentRecordDataSet = new DataGridView_Enriquez.StudentRecordDataSet();
            this.bSCSToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSCSToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.bSITToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSITToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.address_SamalToolStrip = new System.Windows.Forms.ToolStrip();
            this.address_SamalToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.second_year_studentsToolStrip = new System.Windows.Forms.ToolStrip();
            this.second_year_studentsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.section_2BToolStrip = new System.Windows.Forms.ToolStrip();
            this.section_2BToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lastname_starts_with_AtoCToolStrip = new System.Windows.Forms.ToolStrip();
            this.lastname_starts_with_AtoCToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lastname_starts_with_ConsonantToolStrip = new System.Windows.Forms.ToolStrip();
            this.lastname_starts_with_ConsonantToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.refreshToolStrip = new System.Windows.Forms.ToolStrip();
            this.refreshToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.studentsTableAdapter = new DataGridView_Enriquez.StudentRecordDataSetTableAdapters.StudentsTableAdapter();
            this.lbl_Title = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentRecordDataSet)).BeginInit();
            this.bSCSToolStrip.SuspendLayout();
            this.bSITToolStrip.SuspendLayout();
            this.address_SamalToolStrip.SuspendLayout();
            this.second_year_studentsToolStrip.SuspendLayout();
            this.section_2BToolStrip.SuspendLayout();
            this.lastname_starts_with_AtoCToolStrip.SuspendLayout();
            this.lastname_starts_with_ConsonantToolStrip.SuspendLayout();
            this.refreshToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studIDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.middleNameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.birthdayDataGridViewTextBoxColumn,
            this.programDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn,
            this.yearDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.studentsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(30, 70);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1184, 316);
            this.dataGridView1.TabIndex = 0;
            // 
            // studIDDataGridViewTextBoxColumn
            // 
            this.studIDDataGridViewTextBoxColumn.DataPropertyName = "StudID";
            this.studIDDataGridViewTextBoxColumn.HeaderText = "StudID";
            this.studIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.studIDDataGridViewTextBoxColumn.Name = "studIDDataGridViewTextBoxColumn";
            this.studIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            this.lastNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            this.firstNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // middleNameDataGridViewTextBoxColumn
            // 
            this.middleNameDataGridViewTextBoxColumn.DataPropertyName = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.HeaderText = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.middleNameDataGridViewTextBoxColumn.Name = "middleNameDataGridViewTextBoxColumn";
            this.middleNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            this.addressDataGridViewTextBoxColumn.Width = 125;
            // 
            // birthdayDataGridViewTextBoxColumn
            // 
            this.birthdayDataGridViewTextBoxColumn.DataPropertyName = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.HeaderText = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.birthdayDataGridViewTextBoxColumn.Name = "birthdayDataGridViewTextBoxColumn";
            this.birthdayDataGridViewTextBoxColumn.Width = 125;
            // 
            // programDataGridViewTextBoxColumn
            // 
            this.programDataGridViewTextBoxColumn.DataPropertyName = "Program";
            this.programDataGridViewTextBoxColumn.HeaderText = "Program";
            this.programDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.programDataGridViewTextBoxColumn.Name = "programDataGridViewTextBoxColumn";
            this.programDataGridViewTextBoxColumn.Width = 125;
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            this.sectionDataGridViewTextBoxColumn.Width = 125;
            // 
            // yearDataGridViewTextBoxColumn
            // 
            this.yearDataGridViewTextBoxColumn.DataPropertyName = "Year";
            this.yearDataGridViewTextBoxColumn.HeaderText = "Year";
            this.yearDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.yearDataGridViewTextBoxColumn.Name = "yearDataGridViewTextBoxColumn";
            this.yearDataGridViewTextBoxColumn.Width = 125;
            // 
            // studentsBindingSource
            // 
            this.studentsBindingSource.DataMember = "Students";
            this.studentsBindingSource.DataSource = this.studentRecordDataSet;
            // 
            // studentRecordDataSet
            // 
            this.studentRecordDataSet.DataSetName = "StudentRecordDataSet";
            this.studentRecordDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bSCSToolStrip
            // 
            this.bSCSToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSCSToolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.bSCSToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSCSToolStripButton});
            this.bSCSToolStrip.Location = new System.Drawing.Point(231, 402);
            this.bSCSToolStrip.Name = "bSCSToolStrip";
            this.bSCSToolStrip.Size = new System.Drawing.Size(60, 31);
            this.bSCSToolStrip.TabIndex = 1;
            this.bSCSToolStrip.Text = "bSCSToolStrip";
            // 
            // bSCSToolStripButton
            // 
            this.bSCSToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSCSToolStripButton.Name = "bSCSToolStripButton";
            this.bSCSToolStripButton.Size = new System.Drawing.Size(47, 28);
            this.bSCSToolStripButton.Text = "BSCS";
            this.bSCSToolStripButton.Click += new System.EventHandler(this.bSCSToolStripButton_Click);
            // 
            // bSITToolStrip
            // 
            this.bSITToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSITToolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.bSITToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSITToolStripButton});
            this.bSITToolStrip.Location = new System.Drawing.Point(309, 402);
            this.bSITToolStrip.Name = "bSITToolStrip";
            this.bSITToolStrip.Size = new System.Drawing.Size(55, 31);
            this.bSITToolStrip.TabIndex = 2;
            this.bSITToolStrip.Text = "bSITToolStrip";
            // 
            // bSITToolStripButton
            // 
            this.bSITToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSITToolStripButton.Name = "bSITToolStripButton";
            this.bSITToolStripButton.Size = new System.Drawing.Size(42, 28);
            this.bSITToolStripButton.Text = "BSIT";
            this.bSITToolStripButton.Click += new System.EventHandler(this.bSITToolStripButton_Click);
            // 
            // address_SamalToolStrip
            // 
            this.address_SamalToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.address_SamalToolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.address_SamalToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.address_SamalToolStripButton});
            this.address_SamalToolStrip.Location = new System.Drawing.Point(403, 402);
            this.address_SamalToolStrip.Name = "address_SamalToolStrip";
            this.address_SamalToolStrip.Size = new System.Drawing.Size(126, 31);
            this.address_SamalToolStrip.TabIndex = 3;
            this.address_SamalToolStrip.Text = "address_SamalToolStrip";
            // 
            // address_SamalToolStripButton
            // 
            this.address_SamalToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.address_SamalToolStripButton.Name = "address_SamalToolStripButton";
            this.address_SamalToolStripButton.Size = new System.Drawing.Size(113, 28);
            this.address_SamalToolStripButton.Text = "Address_Samal";
            this.address_SamalToolStripButton.Click += new System.EventHandler(this.address_SamalToolStripButton_Click);
            // 
            // second_year_studentsToolStrip
            // 
            this.second_year_studentsToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.second_year_studentsToolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.second_year_studentsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.second_year_studentsToolStripButton});
            this.second_year_studentsToolStrip.Location = new System.Drawing.Point(566, 402);
            this.second_year_studentsToolStrip.Name = "second_year_studentsToolStrip";
            this.second_year_studentsToolStrip.Size = new System.Drawing.Size(170, 31);
            this.second_year_studentsToolStrip.TabIndex = 4;
            this.second_year_studentsToolStrip.Text = "second_year_studentsToolStrip";
            // 
            // second_year_studentsToolStripButton
            // 
            this.second_year_studentsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.second_year_studentsToolStripButton.Name = "second_year_studentsToolStripButton";
            this.second_year_studentsToolStripButton.Size = new System.Drawing.Size(157, 28);
            this.second_year_studentsToolStripButton.Text = "Second_year_students";
            this.second_year_studentsToolStripButton.Click += new System.EventHandler(this.second_year_studentsToolStripButton_Click);
            // 
            // section_2BToolStrip
            // 
            this.section_2BToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.section_2BToolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.section_2BToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.section_2BToolStripButton});
            this.section_2BToolStrip.Location = new System.Drawing.Point(768, 402);
            this.section_2BToolStrip.Name = "section_2BToolStrip";
            this.section_2BToolStrip.Size = new System.Drawing.Size(98, 31);
            this.section_2BToolStrip.TabIndex = 5;
            this.section_2BToolStrip.Text = "section_2BToolStrip";
            // 
            // section_2BToolStripButton
            // 
            this.section_2BToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.section_2BToolStripButton.Name = "section_2BToolStripButton";
            this.section_2BToolStripButton.Size = new System.Drawing.Size(85, 28);
            this.section_2BToolStripButton.Text = "Section_2B";
            this.section_2BToolStripButton.Click += new System.EventHandler(this.section_2BToolStripButton_Click);
            // 
            // lastname_starts_with_AtoCToolStrip
            // 
            this.lastname_starts_with_AtoCToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.lastname_starts_with_AtoCToolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.lastname_starts_with_AtoCToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lastname_starts_with_AtoCToolStripButton});
            this.lastname_starts_with_AtoCToolStrip.Location = new System.Drawing.Point(9, 402);
            this.lastname_starts_with_AtoCToolStrip.Name = "lastname_starts_with_AtoCToolStrip";
            this.lastname_starts_with_AtoCToolStrip.Size = new System.Drawing.Size(203, 31);
            this.lastname_starts_with_AtoCToolStrip.TabIndex = 6;
            this.lastname_starts_with_AtoCToolStrip.Text = "lastname_starts_with_AtoCToolStrip";
            // 
            // lastname_starts_with_AtoCToolStripButton
            // 
            this.lastname_starts_with_AtoCToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lastname_starts_with_AtoCToolStripButton.Name = "lastname_starts_with_AtoCToolStripButton";
            this.lastname_starts_with_AtoCToolStripButton.Size = new System.Drawing.Size(190, 28);
            this.lastname_starts_with_AtoCToolStripButton.Text = "Lastname_starts_with_AtoC";
            this.lastname_starts_with_AtoCToolStripButton.Click += new System.EventHandler(this.lastname_starts_with_AtoCToolStripButton_Click);
            // 
            // lastname_starts_with_ConsonantToolStrip
            // 
            this.lastname_starts_with_ConsonantToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.lastname_starts_with_ConsonantToolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.lastname_starts_with_ConsonantToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lastname_starts_with_ConsonantToolStripButton});
            this.lastname_starts_with_ConsonantToolStrip.Location = new System.Drawing.Point(895, 402);
            this.lastname_starts_with_ConsonantToolStrip.Name = "lastname_starts_with_ConsonantToolStrip";
            this.lastname_starts_with_ConsonantToolStrip.Size = new System.Drawing.Size(240, 31);
            this.lastname_starts_with_ConsonantToolStrip.TabIndex = 7;
            this.lastname_starts_with_ConsonantToolStrip.Text = "lastname_starts_with_ConsonantToolStrip";
            // 
            // lastname_starts_with_ConsonantToolStripButton
            // 
            this.lastname_starts_with_ConsonantToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lastname_starts_with_ConsonantToolStripButton.Name = "lastname_starts_with_ConsonantToolStripButton";
            this.lastname_starts_with_ConsonantToolStripButton.Size = new System.Drawing.Size(227, 28);
            this.lastname_starts_with_ConsonantToolStripButton.Text = "Lastname_starts_with_Consonant";
            this.lastname_starts_with_ConsonantToolStripButton.Click += new System.EventHandler(this.lastname_starts_with_ConsonantToolStripButton_Click);
            // 
            // refreshToolStrip
            // 
            this.refreshToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.refreshToolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.refreshToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshToolStripButton});
            this.refreshToolStrip.Location = new System.Drawing.Point(566, 431);
            this.refreshToolStrip.Name = "refreshToolStrip";
            this.refreshToolStrip.Size = new System.Drawing.Size(75, 31);
            this.refreshToolStrip.TabIndex = 8;
            this.refreshToolStrip.Text = "refreshToolStrip";
            // 
            // refreshToolStripButton
            // 
            this.refreshToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.refreshToolStripButton.Name = "refreshToolStripButton";
            this.refreshToolStripButton.Size = new System.Drawing.Size(62, 28);
            this.refreshToolStripButton.Text = "Refresh";
            this.refreshToolStripButton.Click += new System.EventHandler(this.refreshToolStripButton_Click);
            // 
            // studentsTableAdapter
            // 
            this.studentsTableAdapter.ClearBeforeFill = true;
            // 
            // lbl_Title
            // 
            this.lbl_Title.AutoSize = true;
            this.lbl_Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.8F);
            this.lbl_Title.Location = new System.Drawing.Point(330, 9);
            this.lbl_Title.Name = "lbl_Title";
            this.lbl_Title.Size = new System.Drawing.Size(573, 39);
            this.lbl_Title.TabIndex = 9;
            this.lbl_Title.Text = "Student Records Monitoring System";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1236, 467);
            this.Controls.Add(this.lbl_Title);
            this.Controls.Add(this.refreshToolStrip);
            this.Controls.Add(this.lastname_starts_with_ConsonantToolStrip);
            this.Controls.Add(this.lastname_starts_with_AtoCToolStrip);
            this.Controls.Add(this.section_2BToolStrip);
            this.Controls.Add(this.second_year_studentsToolStrip);
            this.Controls.Add(this.address_SamalToolStrip);
            this.Controls.Add(this.bSITToolStrip);
            this.Controls.Add(this.bSCSToolStrip);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "                                                                                 " +
    "                                              Data Grid Enriquez";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentRecordDataSet)).EndInit();
            this.bSCSToolStrip.ResumeLayout(false);
            this.bSCSToolStrip.PerformLayout();
            this.bSITToolStrip.ResumeLayout(false);
            this.bSITToolStrip.PerformLayout();
            this.address_SamalToolStrip.ResumeLayout(false);
            this.address_SamalToolStrip.PerformLayout();
            this.second_year_studentsToolStrip.ResumeLayout(false);
            this.second_year_studentsToolStrip.PerformLayout();
            this.section_2BToolStrip.ResumeLayout(false);
            this.section_2BToolStrip.PerformLayout();
            this.lastname_starts_with_AtoCToolStrip.ResumeLayout(false);
            this.lastname_starts_with_AtoCToolStrip.PerformLayout();
            this.lastname_starts_with_ConsonantToolStrip.ResumeLayout(false);
            this.lastname_starts_with_ConsonantToolStrip.PerformLayout();
            this.refreshToolStrip.ResumeLayout(false);
            this.refreshToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private StudentRecordDataSet studentRecordDataSet;
        private System.Windows.Forms.BindingSource studentsBindingSource;
        private StudentRecordDataSetTableAdapters.StudentsTableAdapter studentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn middleNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn programDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStrip bSCSToolStrip;
        private System.Windows.Forms.ToolStripButton bSCSToolStripButton;
        private System.Windows.Forms.ToolStrip bSITToolStrip;
        private System.Windows.Forms.ToolStripButton bSITToolStripButton;
        private System.Windows.Forms.ToolStrip address_SamalToolStrip;
        private System.Windows.Forms.ToolStripButton address_SamalToolStripButton;
        private System.Windows.Forms.ToolStrip second_year_studentsToolStrip;
        private System.Windows.Forms.ToolStripButton second_year_studentsToolStripButton;
        private System.Windows.Forms.ToolStrip section_2BToolStrip;
        private System.Windows.Forms.ToolStripButton section_2BToolStripButton;
        private System.Windows.Forms.ToolStrip lastname_starts_with_AtoCToolStrip;
        private System.Windows.Forms.ToolStripButton lastname_starts_with_AtoCToolStripButton;
        private System.Windows.Forms.ToolStrip lastname_starts_with_ConsonantToolStrip;
        private System.Windows.Forms.ToolStripButton lastname_starts_with_ConsonantToolStripButton;
        private System.Windows.Forms.ToolStrip refreshToolStrip;
        private System.Windows.Forms.ToolStripButton refreshToolStripButton;
        private System.Windows.Forms.Label lbl_Title;
    }
}

