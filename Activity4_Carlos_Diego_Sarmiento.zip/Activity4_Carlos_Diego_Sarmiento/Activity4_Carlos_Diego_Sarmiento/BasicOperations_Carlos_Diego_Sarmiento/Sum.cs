﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Carlos_Diego_Sarmiento
{
    class Sum
    {
        public void computeSum()
        {
            DeclareVar.sum = DeclareVar.num1 + DeclareVar.num2;
            Console.WriteLine("The sum is {0}", DeclareVar.sum);
        }
        
    }
}
