﻿/*  20-01732
    Angelica D. Medina

    BSCSSD-2B
    April 07, 2022

*/

using System;

namespace DeclaringConstants_Medina
{
    class Program
    {
        static void Main(string[] args)
        {
            double radius, pi = 3.14159;
            System.Console.Write("Enter Radius: ");
            System.Console.WriteLine("");

            radius = Convert.ToInt32(Console.ReadLine());
            System.Console.WriteLine("\nRadius: {0:0.0000} \nArea: {1:0.0000}", radius, pi * radius * radius);
            System.Console.WriteLine("");

            System.Console.ReadKey();
        }
    }
}