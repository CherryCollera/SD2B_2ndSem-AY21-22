﻿/*
 * 20-00382
 * Roiel A. Carlos
 * SD2B
 * April 18, 2022
 * This program will display the grade equivalent and remarks based on the final grade input
 */
using System;

namespace GradingSystem_Carlos
{
    class GradingSystem
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your final grade: ");
            string fnlGrade = Console.ReadLine();

            // if final grade is incomplete (ignore case)
            if (string.Equals(fnlGrade, "inc", StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("Grade Equivalent:\tINC\nRemarks\t\t:\tIncomplete");
            }
            else
            {
                //convert grade to int if grade is not inc
                int num = Convert.ToInt32(fnlGrade);

                if (num >= 98 && num <= 100)
                {
                    Console.WriteLine("Grade Equivalent:\t1.00\nRemarks\t\t:\tExcellent");
                }
                else if (num >= 95 && num <= 97)
                {
                    Console.WriteLine("Grade Equivalent:\t1.25\nRemarks\t\t:\tExcellent");
                }
                else if (num >= 92 && num <= 94)
                {
                    Console.WriteLine("Grade Equivalent:\t1.50\nRemarks\t\t:\tVery Good");
                }
                else if (num >= 89 && num <= 91)
                {
                    Console.WriteLine("Grade Equivalent:\t1.75\nRemarks\t\t:\tVery Good");
                }
                else if (num >= 86 && num <= 88)
                {
                    Console.WriteLine("Grade Equivalent:\t2.00\nRemarks\t\t:\tGood");
                }
                else if (num >= 83 && num <= 85)
                {
                    Console.WriteLine("Grade Equivalent:\t2.25\nRemarks\t\t:\tGood");
                }
                else if (num >= 80 && num <= 82)
                {
                    Console.WriteLine("Grade Equivalent:\t2.50\nRemarks\t\t:\tFair");
                }
                else if (num >= 77 && num <= 79)
                {
                    Console.WriteLine("Grade Equivalent:\t2.75\nRemarks\t\t:\tPassed");
                }
                else if (num >= 75 && num <= 76)
                {
                    Console.WriteLine("Grade Equivalent:\t3.00\nRemarks\t\t:\tPassed");
                }
                else if (num >= 72 && num <= 74)
                {
                    Console.WriteLine("Grade Equivalent:\t4.00\nRemarks\t\t:\tConditional");
                }
                else
                {
                    Console.WriteLine("Grade Equivalent:\t5.00\nRemarks\t\t:\tFailed");
                }
            }
            Console.ReadKey();
        }
    }
}
