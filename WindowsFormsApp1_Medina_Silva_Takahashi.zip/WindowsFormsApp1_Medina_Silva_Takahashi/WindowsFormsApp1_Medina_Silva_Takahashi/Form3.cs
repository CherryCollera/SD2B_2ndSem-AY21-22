﻿/* 		Activity #5
 * 		Grp 9
 * 	Members: Medina, Angelica
	   	 Silva, Alyssa Mae
	   	 Takahashi, Aira
 * BSCS-SD2B
 * 05/04/2022*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1_Medina_Silva_Takahashi
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_getMessage3_Click(object sender, EventArgs e)
        {
            string a, b;
            a = txt_firstName3.Text;
            b = txt_lastName3.Text;
            MessageBox.Show(MyProfile(a, b));
        }

        public string MyProfile(string firstname, string lastname)
        {
            return ("\t\tHello " + firstname + " " + lastname)
                    + "\nDate of Birth\t:\t" + "December 25, 2000"
                    + "\nCourse\t\t:\t" + "BS in Computer Science major in Software Development"
                    + "\nYear\t\t:\t" + "II"
                    + "\nSection\t\t:\t" + "SD2B";

        }

        private void btn_Hide3_Click(object sender, EventArgs e)
        {
            Form4 next = new Form4();
            next.Show();
            this.Hide();
        }

        private void btn_Back3_Click(object sender, EventArgs e)
        {
            Form2 back = new Form2();
            back.Show();
            this.Hide();
        }
    }
    
}

