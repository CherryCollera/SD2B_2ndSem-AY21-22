﻿using System;

namespace Do_While
{
    class Program
    {
        static void Main(string[] args)
        {
            int [] arr = new int []{6,7,8,10};
            int sum  = 0;
            int i = 0;
            do{
                sum += arr[i];
                i++;
            }
            while (i<4);
            
            Console.WriteLine(sum);
            
        }
    }
}
