﻿/*
20-02604
Jaycee Audrei Mari M. Quitaleg
SD2B
April 06, 2022
This program will take two integer inputs from the user and display its basic operations.
 */

using System;

namespace BasicOperation
{
    class BasicOpeartion
    {
        static void Main()
        {
            Console.Write("Enter the first number: ");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the second number: ");
            int num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\nSum = {0}", num1 + num2);
            Console.WriteLine("Difference = {0}", num1 - num2);
            Console.WriteLine("Product = {0}", num1 * num2);
            Console.WriteLine("Quotient = {0}", num1 / num2);
            Console.WriteLine("Remainder = {0}", num1 % num2);
            Console.ReadLine();
        }
    }
}

