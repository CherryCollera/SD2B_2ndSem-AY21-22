﻿using System.Windows.Forms;

namespace Activity6_Matos
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.refreshToolStrip = new System.Windows.Forms.ToolStrip();
            this.refreshToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lastName_AToolStrip = new System.Windows.Forms.ToolStrip();
            this.lastName_AToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.bSCSToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSCSToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.bSITToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSITToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.sect_2BToolStrip = new System.Windows.Forms.ToolStrip();
            this.sect_2BToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.residence_Samal1ToolStrip = new System.Windows.Forms.ToolStrip();
            this.residence_Samal1ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.newYorkToolStrip = new System.Windows.Forms.ToolStrip();
            this.newYorkToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.label4 = new System.Windows.Forms.Label();
            this.sec2DToolStrip = new System.Windows.Forms.ToolStrip();
            this.sec2DToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.dsadToolStrip = new System.Windows.Forms.ToolStrip();
            this.dsadToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.cToolStrip = new System.Windows.Forms.ToolStrip();
            this.cToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.bToolStrip = new System.Windows.Forms.ToolStrip();
            this.bToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.label5 = new System.Windows.Forms.Label();
            this._2ToolStrip = new System.Windows.Forms.ToolStrip();
            this._2ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this._4ggToolStrip = new System.Windows.Forms.ToolStrip();
            this._4ggToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.label6 = new System.Windows.Forms.Label();
            this.consonantsToolStrip = new System.Windows.Forms.ToolStrip();
            this.consonantsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.middleNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentsDBDataSet = new Activity6_Matos.StudentsDBDataSet();
            this.usersTableAdapter = new Activity6_Matos.StudentsDBDataSetTableAdapters.usersTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.refreshToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.lastName_AToolStrip.SuspendLayout();
            this.bSCSToolStrip.SuspendLayout();
            this.bSITToolStrip.SuspendLayout();
            this.sect_2BToolStrip.SuspendLayout();
            this.residence_Samal1ToolStrip.SuspendLayout();
            this.newYorkToolStrip.SuspendLayout();
            this.sec2DToolStrip.SuspendLayout();
            this.dsadToolStrip.SuspendLayout();
            this.cToolStrip.SuspendLayout();
            this.bToolStrip.SuspendLayout();
            this._2ToolStrip.SuspendLayout();
            this._4ggToolStrip.SuspendLayout();
            this.consonantsToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDBDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.middleNameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.birthdayDataGridViewTextBoxColumn,
            this.programDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.usersBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(808, 477);
            this.dataGridView1.TabIndex = 0;
            // 
            // refreshToolStrip
            // 
            this.refreshToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.refreshToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshToolStripButton});
            this.refreshToolStrip.Location = new System.Drawing.Point(909, 27);
            this.refreshToolStrip.Name = "refreshToolStrip";
            this.refreshToolStrip.Size = new System.Drawing.Size(62, 25);
            this.refreshToolStrip.TabIndex = 1;
            this.refreshToolStrip.Text = "refreshToolStrip";
            // 
            // refreshToolStripButton
            // 
            this.refreshToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.refreshToolStripButton.Name = "refreshToolStripButton";
            this.refreshToolStripButton.Size = new System.Drawing.Size(50, 22);
            this.refreshToolStripButton.Text = "Refresh";
            this.refreshToolStripButton.Click += new System.EventHandler(this.refreshToolStripButton_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Activity6_Matos.Properties.Resources.bg;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1272, 785);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // lastName_AToolStrip
            // 
            this.lastName_AToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.lastName_AToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lastName_AToolStripButton});
            this.lastName_AToolStrip.Location = new System.Drawing.Point(874, 120);
            this.lastName_AToolStrip.Name = "lastName_AToolStrip";
            this.lastName_AToolStrip.Size = new System.Drawing.Size(35, 25);
            this.lastName_AToolStrip.TabIndex = 4;
            this.lastName_AToolStrip.Text = "lastName_AToolStrip";
            // 
            // lastName_AToolStripButton
            // 
            this.lastName_AToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lastName_AToolStripButton.Name = "lastName_AToolStripButton";
            this.lastName_AToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.lastName_AToolStripButton.Text = "A";
            this.lastName_AToolStripButton.Click += new System.EventHandler(this.lastName_AToolStripButton_Click);
            // 
            // bSCSToolStrip
            // 
            this.bSCSToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSCSToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSCSToolStripButton});
            this.bSCSToolStrip.Location = new System.Drawing.Point(927, 211);
            this.bSCSToolStrip.Name = "bSCSToolStrip";
            this.bSCSToolStrip.Size = new System.Drawing.Size(50, 25);
            this.bSCSToolStrip.TabIndex = 5;
            this.bSCSToolStrip.Text = "bSCSToolStrip";
            // 
            // bSCSToolStripButton
            // 
            this.bSCSToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSCSToolStripButton.Name = "bSCSToolStripButton";
            this.bSCSToolStripButton.Size = new System.Drawing.Size(38, 22);
            this.bSCSToolStripButton.Text = "BSCS";
            this.bSCSToolStripButton.Click += new System.EventHandler(this.bSCSToolStripButton_Click);
            // 
            // bSITToolStrip
            // 
            this.bSITToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSITToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSITToolStripButton});
            this.bSITToolStrip.Location = new System.Drawing.Point(874, 211);
            this.bSITToolStrip.Name = "bSITToolStrip";
            this.bSITToolStrip.Size = new System.Drawing.Size(45, 25);
            this.bSITToolStrip.TabIndex = 6;
            this.bSITToolStrip.Text = "bSITToolStrip";
            // 
            // bSITToolStripButton
            // 
            this.bSITToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSITToolStripButton.Name = "bSITToolStripButton";
            this.bSITToolStripButton.Size = new System.Drawing.Size(33, 22);
            this.bSITToolStripButton.Text = "BSIT";
            this.bSITToolStripButton.Click += new System.EventHandler(this.bSITToolStripButton_Click);
            // 
            // sect_2BToolStrip
            // 
            this.sect_2BToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.sect_2BToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sect_2BToolStripButton});
            this.sect_2BToolStrip.Location = new System.Drawing.Point(1054, 304);
            this.sect_2BToolStrip.Name = "sect_2BToolStrip";
            this.sect_2BToolStrip.Size = new System.Drawing.Size(36, 25);
            this.sect_2BToolStrip.TabIndex = 8;
            this.sect_2BToolStrip.Text = "sect_2BToolStrip";
            // 
            // sect_2BToolStripButton
            // 
            this.sect_2BToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.sect_2BToolStripButton.Name = "sect_2BToolStripButton";
            this.sect_2BToolStripButton.Size = new System.Drawing.Size(24, 22);
            this.sect_2BToolStripButton.Text = "2B";
            this.sect_2BToolStripButton.Click += new System.EventHandler(this.sect_2BToolStripButton_Click);
            // 
            // residence_Samal1ToolStrip
            // 
            this.residence_Samal1ToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.residence_Samal1ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.residence_Samal1ToolStripButton});
            this.residence_Samal1ToolStrip.Location = new System.Drawing.Point(874, 388);
            this.residence_Samal1ToolStrip.Name = "residence_Samal1ToolStrip";
            this.residence_Samal1ToolStrip.Size = new System.Drawing.Size(55, 25);
            this.residence_Samal1ToolStrip.TabIndex = 9;
            this.residence_Samal1ToolStrip.Text = "residence_Samal1ToolStrip";
            // 
            // residence_Samal1ToolStripButton
            // 
            this.residence_Samal1ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.residence_Samal1ToolStripButton.Name = "residence_Samal1ToolStripButton";
            this.residence_Samal1ToolStripButton.Size = new System.Drawing.Size(43, 22);
            this.residence_Samal1ToolStripButton.Text = "Samal";
            this.residence_Samal1ToolStripButton.Click += new System.EventHandler(this.residence_Samal1ToolStripButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(838, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 24);
            this.label1.TabIndex = 10;
            this.label1.Text = "Last Name:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(838, 180);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 24);
            this.label2.TabIndex = 11;
            this.label2.Text = "Program:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(838, 358);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 24);
            this.label3.TabIndex = 12;
            this.label3.Text = "Residence:";
            // 
            // newYorkToolStrip
            // 
            this.newYorkToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.newYorkToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newYorkToolStripButton});
            this.newYorkToolStrip.Location = new System.Drawing.Point(938, 388);
            this.newYorkToolStrip.Name = "newYorkToolStrip";
            this.newYorkToolStrip.Size = new System.Drawing.Size(70, 25);
            this.newYorkToolStrip.TabIndex = 13;
            this.newYorkToolStrip.Text = "newYorkToolStrip";
            // 
            // newYorkToolStripButton
            // 
            this.newYorkToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.newYorkToolStripButton.Name = "newYorkToolStripButton";
            this.newYorkToolStripButton.Size = new System.Drawing.Size(58, 22);
            this.newYorkToolStripButton.Text = "NewYork";
            this.newYorkToolStripButton.Click += new System.EventHandler(this.newYorkToolStripButton_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1016, 272);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 24);
            this.label4.TabIndex = 14;
            this.label4.Text = "Section:";
            // 
            // sec2DToolStrip
            // 
            this.sec2DToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.sec2DToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sec2DToolStripButton});
            this.sec2DToolStrip.Location = new System.Drawing.Point(1097, 304);
            this.sec2DToolStrip.Name = "sec2DToolStrip";
            this.sec2DToolStrip.Size = new System.Drawing.Size(37, 25);
            this.sec2DToolStrip.TabIndex = 15;
            this.sec2DToolStrip.Text = "sec2DToolStrip";
            // 
            // sec2DToolStripButton
            // 
            this.sec2DToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.sec2DToolStripButton.Name = "sec2DToolStripButton";
            this.sec2DToolStripButton.Size = new System.Drawing.Size(25, 22);
            this.sec2DToolStripButton.Text = "2D";
            this.sec2DToolStripButton.Click += new System.EventHandler(this.sec2DToolStripButton_Click);
            // 
            // dsadToolStrip
            // 
            this.dsadToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.dsadToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dsadToolStripButton});
            this.dsadToolStrip.Location = new System.Drawing.Point(1143, 305);
            this.dsadToolStrip.Name = "dsadToolStrip";
            this.dsadToolStrip.Size = new System.Drawing.Size(37, 25);
            this.dsadToolStrip.TabIndex = 16;
            this.dsadToolStrip.Text = "dsadToolStrip";
            // 
            // dsadToolStripButton
            // 
            this.dsadToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.dsadToolStripButton.Name = "dsadToolStripButton";
            this.dsadToolStripButton.Size = new System.Drawing.Size(25, 22);
            this.dsadToolStripButton.Text = "4D";
            this.dsadToolStripButton.Click += new System.EventHandler(this.dsadToolStripButton_Click);
            // 
            // cToolStrip
            // 
            this.cToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.cToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cToolStripButton});
            this.cToolStrip.Location = new System.Drawing.Point(961, 120);
            this.cToolStrip.Name = "cToolStrip";
            this.cToolStrip.Size = new System.Drawing.Size(35, 25);
            this.cToolStrip.TabIndex = 17;
            this.cToolStrip.Text = "cToolStrip";
            // 
            // cToolStripButton
            // 
            this.cToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.cToolStripButton.Name = "cToolStripButton";
            this.cToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.cToolStripButton.Text = "C";
            this.cToolStripButton.Click += new System.EventHandler(this.cToolStripButton_Click);
            // 
            // bToolStrip
            // 
            this.bToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bToolStripButton});
            this.bToolStrip.Location = new System.Drawing.Point(918, 120);
            this.bToolStrip.Name = "bToolStrip";
            this.bToolStrip.Size = new System.Drawing.Size(35, 25);
            this.bToolStrip.TabIndex = 18;
            this.bToolStrip.Text = "bToolStrip";
            // 
            // bToolStripButton
            // 
            this.bToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bToolStripButton.Name = "bToolStripButton";
            this.bToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.bToolStripButton.Text = "B";
            this.bToolStripButton.Click += new System.EventHandler(this.bToolStripButton_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(838, 272);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 24);
            this.label5.TabIndex = 19;
            this.label5.Text = "Year:";
            // 
            // _2ToolStrip
            // 
            this._2ToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this._2ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._2ToolStripButton});
            this._2ToolStrip.Location = new System.Drawing.Point(874, 305);
            this._2ToolStrip.Name = "_2ToolStrip";
            this._2ToolStrip.Size = new System.Drawing.Size(35, 25);
            this._2ToolStrip.TabIndex = 20;
            this._2ToolStrip.Text = "_2ToolStrip";
            // 
            // _2ToolStripButton
            // 
            this._2ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this._2ToolStripButton.Name = "_2ToolStripButton";
            this._2ToolStripButton.Size = new System.Drawing.Size(23, 22);
            this._2ToolStripButton.Text = "2";
            this._2ToolStripButton.ToolTipText = "2";
            this._2ToolStripButton.Click += new System.EventHandler(this._2ToolStripButton_Click);
            // 
            // _4ggToolStrip
            // 
            this._4ggToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this._4ggToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._4ggToolStripButton});
            this._4ggToolStrip.Location = new System.Drawing.Point(917, 305);
            this._4ggToolStrip.Name = "_4ggToolStrip";
            this._4ggToolStrip.Size = new System.Drawing.Size(35, 25);
            this._4ggToolStrip.TabIndex = 21;
            this._4ggToolStrip.Text = "_4ggToolStrip";
            // 
            // _4ggToolStripButton
            // 
            this._4ggToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this._4ggToolStripButton.Name = "_4ggToolStripButton";
            this._4ggToolStripButton.Size = new System.Drawing.Size(23, 22);
            this._4ggToolStripButton.Text = "4";
            this._4ggToolStripButton.Click += new System.EventHandler(this._4ggToolStripButton_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(1050, 88);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 24);
            this.label6.TabIndex = 22;
            this.label6.Text = "First Name:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // consonantsToolStrip
            // 
            this.consonantsToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.consonantsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.consonantsToolStripButton});
            this.consonantsToolStrip.Location = new System.Drawing.Point(1097, 120);
            this.consonantsToolStrip.Name = "consonantsToolStrip";
            this.consonantsToolStrip.Size = new System.Drawing.Size(86, 25);
            this.consonantsToolStrip.TabIndex = 23;
            this.consonantsToolStrip.Text = "consonantsToolStrip";
            // 
            // consonantsToolStripButton
            // 
            this.consonantsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.consonantsToolStripButton.Name = "consonantsToolStripButton";
            this.consonantsToolStripButton.Size = new System.Drawing.Size(74, 22);
            this.consonantsToolStripButton.Text = "Consonants";
            this.consonantsToolStripButton.Click += new System.EventHandler(this.consonantsToolStripButton_Click);
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "Last Name";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "Last Name";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "First Name";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "First Name";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // middleNameDataGridViewTextBoxColumn
            // 
            this.middleNameDataGridViewTextBoxColumn.DataPropertyName = "Middle Name";
            this.middleNameDataGridViewTextBoxColumn.HeaderText = "Middle Name";
            this.middleNameDataGridViewTextBoxColumn.Name = "middleNameDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // birthdayDataGridViewTextBoxColumn
            // 
            this.birthdayDataGridViewTextBoxColumn.DataPropertyName = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.HeaderText = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.Name = "birthdayDataGridViewTextBoxColumn";
            // 
            // programDataGridViewTextBoxColumn
            // 
            this.programDataGridViewTextBoxColumn.DataPropertyName = "Program";
            this.programDataGridViewTextBoxColumn.HeaderText = "Program";
            this.programDataGridViewTextBoxColumn.Name = "programDataGridViewTextBoxColumn";
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            // 
            // usersBindingSource
            // 
            this.usersBindingSource.DataMember = "users";
            this.usersBindingSource.DataSource = this.studentsDBDataSet;
            // 
            // studentsDBDataSet
            // 
            this.studentsDBDataSet.DataSetName = "StudentsDBDataSet";
            this.studentsDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // usersTableAdapter
            // 
            this.usersTableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1215, 502);
            this.Controls.Add(this.consonantsToolStrip);
            this.Controls.Add(this.label6);
            this.Controls.Add(this._4ggToolStrip);
            this.Controls.Add(this._2ToolStrip);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.bToolStrip);
            this.Controls.Add(this.cToolStrip);
            this.Controls.Add(this.dsadToolStrip);
            this.Controls.Add(this.sec2DToolStrip);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.newYorkToolStrip);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.residence_Samal1ToolStrip);
            this.Controls.Add(this.sect_2BToolStrip);
            this.Controls.Add(this.bSITToolStrip);
            this.Controls.Add(this.bSCSToolStrip);
            this.Controls.Add(this.lastName_AToolStrip);
            this.Controls.Add(this.refreshToolStrip);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.pictureBox2);
            this.Name = "Form1";
            this.Text = "Student Data";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.refreshToolStrip.ResumeLayout(false);
            this.refreshToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.lastName_AToolStrip.ResumeLayout(false);
            this.lastName_AToolStrip.PerformLayout();
            this.bSCSToolStrip.ResumeLayout(false);
            this.bSCSToolStrip.PerformLayout();
            this.bSITToolStrip.ResumeLayout(false);
            this.bSITToolStrip.PerformLayout();
            this.sect_2BToolStrip.ResumeLayout(false);
            this.sect_2BToolStrip.PerformLayout();
            this.residence_Samal1ToolStrip.ResumeLayout(false);
            this.residence_Samal1ToolStrip.PerformLayout();
            this.newYorkToolStrip.ResumeLayout(false);
            this.newYorkToolStrip.PerformLayout();
            this.sec2DToolStrip.ResumeLayout(false);
            this.sec2DToolStrip.PerformLayout();
            this.dsadToolStrip.ResumeLayout(false);
            this.dsadToolStrip.PerformLayout();
            this.cToolStrip.ResumeLayout(false);
            this.cToolStrip.PerformLayout();
            this.bToolStrip.ResumeLayout(false);
            this.bToolStrip.PerformLayout();
            this._2ToolStrip.ResumeLayout(false);
            this._2ToolStrip.PerformLayout();
            this._4ggToolStrip.ResumeLayout(false);
            this._4ggToolStrip.PerformLayout();
            this.consonantsToolStrip.ResumeLayout(false);
            this.consonantsToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDBDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private StudentsDBDataSet studentsDBDataSet;
        private System.Windows.Forms.BindingSource usersBindingSource;
        private StudentsDBDataSetTableAdapters.usersTableAdapter usersTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn middleNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn programDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStrip refreshToolStrip;
        private System.Windows.Forms.ToolStripButton refreshToolStripButton;
        private System.Windows.Forms.PictureBox pictureBox2;
        private ToolStrip lastName_AToolStrip;
        private ToolStripButton lastName_AToolStripButton;
        private ToolStrip bSCSToolStrip;
        private ToolStripButton bSCSToolStripButton;
        private ToolStrip bSITToolStrip;
        private ToolStripButton bSITToolStripButton;
        private ToolStrip sect_2BToolStrip;
        private ToolStripButton sect_2BToolStripButton;
        private ToolStrip residence_Samal1ToolStrip;
        private ToolStripButton residence_Samal1ToolStripButton;
        private Label label1;
        private Label label2;
        private Label label3;
        private ToolStrip newYorkToolStrip;
        private ToolStripButton newYorkToolStripButton;
        private Label label4;
        private ToolStrip sec2DToolStrip;
        private ToolStripButton sec2DToolStripButton;
        private ToolStrip dsadToolStrip;
        private ToolStripButton dsadToolStripButton;
        private ToolStrip cToolStrip;
        private ToolStripButton cToolStripButton;
        private ToolStrip bToolStrip;
        private ToolStripButton bToolStripButton;
        private Label label5;
        private ToolStrip _2ToolStrip;
        private ToolStripButton _2ToolStripButton;
        private ToolStrip _4ggToolStrip;
        private ToolStripButton _4ggToolStripButton;
        private Label label6;
        private ToolStrip consonantsToolStrip;
        private ToolStripButton consonantsToolStripButton;
    }
}

