﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Medina
{
    class Quotient
    {
        public void ComputeQuotient()
        {
            DeclareVar.quotient = DeclareVar.num1 / DeclareVar.num2; //computes the quotient of two input values
        }
    }
}
